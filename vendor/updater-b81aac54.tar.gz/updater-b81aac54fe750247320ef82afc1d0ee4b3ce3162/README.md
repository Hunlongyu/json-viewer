# winautoupdate

[![CI](https://github.com/Hunlongyu/updater/actions/workflows/ci.yml/badge.svg?branch=main)](https://github.com/Hunlongyu/updater/actions/workflows/ci.yml) ![C / C++](https://img.shields.io/badge/C17%20%2F%20C%2B%2B-00599C?style=flat-square) ![Windows](https://img.shields.io/badge/Windows-10%20%2F%2011-0078D4?style=flat-square) [![MIT License](https://img.shields.io/badge/License-MIT-green?style=flat-square)](LICENSE)

**English** | [简体中文](README.zh-CN.md)

**GitHub Release updates for Windows C and C++ applications.**

A small C17 static library with a C API. Uses WinHTTP and Windows CNG; cJSON is bundled. Your application controls the UI and when to update.

- **Three update modes** — replace a single EXE, update from a ZIP, or launch an installer.
- **Release selection** — stable / prerelease channels, version comparison, and asset matching.
- **Download control** — progress and log callbacks, cancellation, mirrors, retries, and SHA-256 verification when a digest is available.

## Integration

Requires Windows 10 (1803+) / 11, CMake 3.20+, and MSVC or MinGW-w64 with C17 support. ZIP updates use the system `tar.exe`.

```sh
git clone https://github.com/Hunlongyu/updater.git third_party/updater
```

Add to your application's `CMakeLists.txt` after creating its target:

```cmake
add_subdirectory(third_party/updater EXCLUDE_FROM_ALL)
target_link_libraries(your_app PRIVATE winautoupdate)
```

The target provides the include path and links the bundled libraries, `winhttp`, and `bcrypt`. `EXCLUDE_FROM_ALL` keeps the library's demo and tests out of your default build.

## Quick start

A minimal C++ example for a single-EXE application. Replace the repository, current version, and asset name with your own values. This example uses GitHub directly and requires a SHA-256 digest before downloading.

```cpp
#include "win_autoupdate.h"
#include <cstdio>

int main(int argc, char** argv) {
    // Run before creating your application's single-instance mutex.
    au_wait_for_predecessor(argc, argv, 10000);
    au_cleanup_after_restart();

    const char* mirrors[] = { "{url}" };
    au_config_t cfg{};
    cfg.owner           = "YOUR_GITHUB_OWNER";
    cfg.repo            = "YOUR_REPOSITORY";
    cfg.current_version = "1.0.0";
    cfg.asset_pattern   = "myapp-x64.exe";
    cfg.mode            = AU_MODE_EXE;
    cfg.mirrors         = mirrors;
    cfg.mirror_count    = 1;

    auto* ctx = au_create(&cfg);
    if (!ctx) return 1;

    au_release_t* release = nullptr;
    auto error = au_fetch_latest(ctx, &release);
    if (error == AU_OK && au_compare_current(ctx, release) > 0) {
        const auto* asset = au_pick_asset(release, cfg.asset_pattern);
        if (!asset) {
            error = AU_ERR_NO_ASSET;
        } else if (!asset->sha256 || !asset->sha256[0]) {
            error = AU_ERR_HASH;
        } else {
            std::printf("Install %s? [y/N] ", release->ver.raw);
            if (std::getchar() == 'y') {
                char path[4096];
                error = au_download(ctx, asset, path, sizeof path);
                // Save app state and finish cleanup before applying the update.
                if (error == AU_OK) error = au_apply(ctx, path);
            }
        }
    }

    if (error != AU_OK) std::fprintf(stderr, "%s\n", au_strerror(error));
    au_release_free(release);
    au_destroy(ctx);
    return error == AU_OK ? 0 : 1;
}
```

`au_apply()` terminates the process on success, bypassing C++ destructors. APIs are synchronous; use a worker thread in GUI applications. The executable directory must be writable.

## Reference

| Mode | Package | Behavior |
| --- | --- | --- |
| `AU_MODE_EXE` | Single `.exe` | Replace the running executable and restart. |
| `AU_MODE_ZIP` | `.zip` | Extract, overwrite files, and restart; optionally preserve existing configuration files. |
| `AU_MODE_INSTALLER` | Installer `.exe` | Start the installer and exit; the installer handles installation and relaunch. |

[Public API](include/win_autoupdate.h) · [Console demo](demo/main.c) · [Tray integration (中文)](examples/integrate-tray-app.md) · [Issues](https://github.com/Hunlongyu/updater/issues)

<details>
<summary>Configuration and update behavior</summary>

- **Callbacks and cancellation:** set `on_progress`, `on_log`, and `userdata` in `au_config_t`. Callbacks run on the calling thread. Serialize operations on a context; `au_cancel()` may be called from another thread. Wait for the operation to finish before calling `au_reset_cancel()` or destroying the context.
- **Releases and assets:** REST requests paginate to select the highest valid SemVer version in the selected channel. Stable excludes releases flagged as prereleases; beta includes both. Asset patterns support `*` and `?`, case-insensitively; zero or multiple matches return `NULL`. A missing asset does not trigger selection of an older release.
- **Integrity:** downloads validate the API's `digest`, or `checksums.txt` in the web fallback. A mismatch deletes the download and returns `AU_ERR_HASH`. Malformed hashes are rejected; missing hashes are allowed only over direct HTTPS with a log warning. The example above requires a hash. Publisher signatures / Authenticode are not verified.
- **Networking:** release metadata always uses direct GitHub HTTPS. Assets with a valid digest try GitHub, then `gh-proxy.com` and `ghfast.top`; override `mirrors` to choose trusted sources. Tokens are sent only to direct `api.github.com` API requests over HTTPS port 443 and removed after a cross-origin redirect. Private release asset downloads are not fully supported. The default timeout is 30 seconds with two retries per mirror; setting `retry_max` to zero retains the default.
- **Rate-limit fallback:** a first-page response of HTTP 403 with `X-RateLimit-Remaining: 0` can use GitHub's web endpoint. This requires the stable channel, an exact asset filename, and direct access to `github.com`. It follows GitHub's latest release, without a changelog, and optionally reads `checksums.txt`. Use stable per-architecture asset names such as `myapp-x64.exe`.
- **ZIP packages:** place the main EXE at the archive root, with the same name as the installed EXE. Set `zip_exclude` and `zip_exclude_count` to preserve existing files by case-insensitive basename, including in subdirectories. Removed files are not deleted from the installation.
- **Restart and recovery:** call the two startup helpers before single-instance initialization, as shown above. The predecessor wait can time out; ignore `--au-wait-pid=...` in your argument parser. EXE replacement attempts to restore the old file if replacement or process creation fails; this is best effort. ZIP updates can leave partially overwritten files. Process creation does not confirm successful application startup. Installers do not receive automatic UAC elevation; use `installer_args` for custom arguments.
- **Scope:** scheduling, architecture selection, persistent logs, and update prompts belong to the host. Downloads restart from scratch on retry. Some file operations use `MAX_PATH` buffers; use ordinary asset filenames and avoid layouts that require long paths.

</details>

<details>
<summary>Build and test</summary>

Run from an MSVC developer command prompt with the Windows SDK installed:

```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build --config Release
ctest --test-dir build -C Release --output-on-failure
```

For a static MSVC runtime, set this in the parent project before creating the application and library targets. Keep the CRT setting consistent across them:

```cmake
set(CMAKE_MSVC_RUNTIME_LIBRARY "MultiThreaded$<$<CONFIG:Debug>:Debug>")
```

[CI](.github/workflows/ci.yml) configures MSVC and MinGW-w64 builds. Tests use offline data, transport fixtures, and local executables for replacement checks; they do not verify live GitHub access or installer behavior.

</details>

## License

[MIT](LICENSE). Bundled dependency: [cJSON](src/third_party/cJSON-LICENSE.txt), also MIT.
