# winautoupdate

[![CI](https://github.com/Hunlongyu/updater/actions/workflows/ci.yml/badge.svg?branch=main)](https://github.com/Hunlongyu/updater/actions/workflows/ci.yml) ![C / C++](https://img.shields.io/badge/C17%20%2F%20C%2B%2B-00599C?style=flat-square) ![Windows](https://img.shields.io/badge/Windows-10%20%2F%2011-0078D4?style=flat-square) [![MIT License](https://img.shields.io/badge/License-MIT-green?style=flat-square)](LICENSE)

[English](README.md) | **简体中文**

**为 Windows C / C++ 应用接入 GitHub Release 自动更新。**

小型 C17 静态库，提供 C 接口，使用 WinHTTP 与 Windows CNG，随源码附带 cJSON。更新界面和更新时机由宿主应用控制。

- **三种更新模式**：单 EXE 替换、ZIP 文件覆盖、启动安装器。
- **版本与资产选择**：正式版 / 预发布通道、版本比较、资产名称匹配。
- **下载控制**：进度与日志回调、取消、镜像、重试，以及有摘要时的 SHA-256 校验。

## 集成

需要 Windows 10（1803+）/ 11、CMake 3.20+，以及支持 C17 的 MSVC 或 MinGW-w64。ZIP 更新使用系统 `tar.exe`。

```sh
git clone https://github.com/Hunlongyu/updater.git third_party/updater
```

在宿主的 `CMakeLists.txt` 中创建应用目标后添加：

```cmake
add_subdirectory(third_party/updater EXCLUDE_FROM_ALL)
target_link_libraries(your_app PRIVATE winautoupdate)
```

目标会传递头文件目录，并链接随库附带的依赖、`winhttp` 和 `bcrypt`。`EXCLUDE_FROM_ALL` 避免默认构建库自身的 demo 与测试。

## 快速开始

以下 C++ 示例适用于单 EXE 应用。替换仓库、当前版本和资产名称即可接入。示例使用 GitHub 官方直连，并要求资产提供 SHA-256 摘要后才下载。

```cpp
#include "win_autoupdate.h"
#include <cstdio>

int main(int argc, char** argv) {
    // 在创建宿主应用的单实例互斥量之前调用。
    au_wait_for_predecessor(argc, argv, 10000);
    au_cleanup_after_restart();

    const char* mirrors[] = { "{url}" };
    au_config_t cfg{};
    cfg.owner           = "YOUR_GITHUB_OWNER";
    cfg.repo            = "YOUR_REPOSITORY";
    cfg.current_version = "1.0.0";
    cfg.asset_pattern   = "myapp-x64.exe";
    cfg.mode            = AU_MODE_EXE;
    cfg.mirrors         = mirrors;
    cfg.mirror_count    = 1;

    auto* ctx = au_create(&cfg);
    if (!ctx) return 1;

    au_release_t* release = nullptr;
    auto error = au_fetch_latest(ctx, &release);
    if (error == AU_OK && au_compare_current(ctx, release) > 0) {
        const auto* asset = au_pick_asset(release, cfg.asset_pattern);
        if (!asset) {
            error = AU_ERR_NO_ASSET;
        } else if (!asset->sha256 || !asset->sha256[0]) {
            error = AU_ERR_HASH;
        } else {
            std::printf("Install %s? [y/N] ", release->ver.raw);
            if (std::getchar() == 'y') {
                char path[4096];
                error = au_download(ctx, asset, path, sizeof path);
                // 应用更新前，先保存宿主状态并完成退出清理。
                if (error == AU_OK) error = au_apply(ctx, path);
            }
        }
    }

    if (error != AU_OK) std::fprintf(stderr, "%s\n", au_strerror(error));
    au_release_free(release);
    au_destroy(ctx);
    return error == AU_OK ? 0 : 1;
}
```

`au_apply()` 成功后会直接终止进程，不执行 C++ 析构。API 均为同步调用，GUI 应用应放到工作线程执行。EXE 所在目录必须可写。

## 参考

| 模式 | 更新包 | 行为 |
| --- | --- | --- |
| `AU_MODE_EXE` | 单个 `.exe` | 替换当前程序并重启。 |
| `AU_MODE_ZIP` | `.zip` | 解压、覆盖文件并重启，可保留已有配置文件。 |
| `AU_MODE_INSTALLER` | 安装器 `.exe` | 启动安装器后退出，安装与重新启动由安装器负责。 |

[公开 API](include/win_autoupdate.h) · [控制台示例](demo/main.c) · [托盘接入](examples/integrate-tray-app.md) · [问题反馈](https://github.com/Hunlongyu/updater/issues)

<details>
<summary>配置与更新行为</summary>

- **回调与取消**：在 `au_config_t` 中设置 `on_progress`、`on_log` 和 `userdata`。回调在调用线程执行，同一上下文的操作需串行执行。`au_cancel()` 可跨线程调用；操作结束后才可调用 `au_reset_cancel()` 或销毁上下文。
- **版本与资产**：REST 请求会分页选择通道中符合严格 SemVer 规范的最高版本。stable 排除标记为预发布的 Release，beta 同时包含正式版和预发布版。资产名支持大小写不敏感的 `*` / `?` 匹配，无匹配或多重匹配均返回 `NULL`；缺少匹配资产时不会自动改选旧版本。
- **完整性校验**：使用 API 的 `digest`，或网页兜底时的 `checksums.txt`。哈希不符会删除下载文件并返回 `AU_ERR_HASH`。库拒绝格式错误的哈希；缺少哈希时仅允许 HTTPS 直连并记录警告，上面的示例会拒绝此类资产。库不验证发布者签名或 Authenticode。
- **网络**：Release 元数据始终通过 HTTPS 直连 GitHub。有合法摘要的资产默认依次尝试 GitHub、`gh-proxy.com` 和 `ghfast.top`，可通过 `mirrors` 指定受信任的来源。令牌仅发送到直连 `api.github.com` 的 HTTPS 443 API 请求，跨源重定向后不再携带。私有 Release 资产下载尚未完整支持。默认超时 30 秒，每个镜像重试两次；`retry_max` 为零时仍使用默认值。
- **限流兜底**：第一页返回 HTTP 403 且 `X-RateLimit-Remaining: 0` 时，可改用 GitHub 网页端点。要求 stable 通道、固定资产文件名且可直连 `github.com`。结果遵循 GitHub 的 latest 选择，不包含更新日志，并尝试读取 `checksums.txt`。建议各架构使用固定资产名，例如 `myapp-x64.exe`。
- **ZIP 包**：包根目录需直接包含与当前程序同名的主 EXE。使用 `zip_exclude` 和 `zip_exclude_count` 保留已有文件，按 basename 大小写不敏感匹配，也作用于子目录。新包中移除的旧文件不会从安装目录删除。
- **重启与恢复**：像示例一样，在单实例初始化之前调用两个启动辅助函数。等待旧进程可能超时，宿主参数解析需忽略 `--au-wait-pid=...`。EXE 替换或创建新进程失败时会尽力恢复旧文件；ZIP 更新可能留下部分覆盖状态。成功创建进程不代表新版初始化成功。安装器不会自动请求 UAC 提权，可通过 `installer_args` 设置自定义参数。
- **使用范围**：定时检查、架构选择、日志持久化和更新提示由宿主实现。重试会重新下载整个文件。部分文件操作使用 `MAX_PATH` 缓冲，应使用普通资产文件名，避免依赖长路径的目录结构。

</details>

<details>
<summary>构建与测试</summary>

在已安装 Windows SDK 的 MSVC 开发者命令提示符中运行：

```sh
cmake -S . -B build -DCMAKE_BUILD_TYPE=Release
cmake --build build --config Release
ctest --test-dir build -C Release --output-on-failure
```

如需静态链接 MSVC 运行库，在父项目创建应用和库目标前设置，并保持各目标的 CRT 配置一致：

```cmake
set(CMAKE_MSVC_RUNTIME_LIBRARY "MultiThreaded$<$<CONFIG:Debug>:Debug>")
```

[CI](.github/workflows/ci.yml) 配置了 MSVC 与 MinGW-w64 构建。测试使用离线数据、模拟传输及用于替换检查的本地程序，不验证在线 GitHub 访问或安装器行为。

</details>

## 许可证

[MIT](LICENSE)。随库分发的 [cJSON](src/third_party/cJSON-LICENSE.txt) 同样采用 MIT 许可证。
