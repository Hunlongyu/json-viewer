/*
 * demo/main.c — 控制台演示：检测→显示更新日志→确认→带进度下载→替换重启。
 * 用法：demo <owner> <repo> <current_version> <asset_glob> [beta]
 * 例：  demo Hunlongyu hua v1.0.0 "hua-*-x64.exe" beta
 */
#include "win_autoupdate.h"
#include <stdio.h>
#include <string.h>

static int on_progress(uint64_t total, uint64_t done, void* ud) {
    (void)ud;
    if (total) printf("\r下载中 %3d%%  %llu/%llu 字节   ",
                      (int)(done * 100 / total),
                      (unsigned long long)done, (unsigned long long)total);
    else       printf("\r已下载 %llu 字节   ", (unsigned long long)done);
    fflush(stdout);
    return 0;
}

static void on_log(au_log_level_t lv, const char* msg, void* ud) {
    (void)ud;
    const char* tag = lv==AU_LOG_ERROR?"ERROR":lv==AU_LOG_WARN?"WARN":lv==AU_LOG_INFO?"INFO":"DEBUG";
    fprintf(stderr, "[%s] %s\n", tag, msg);
}

int main(int argc, char** argv) {
    /* 更新重启后，第一时间清理残留。 */
    au_wait_for_predecessor(argc, argv, 10000);
    au_cleanup_after_restart();

    if (argc < 5) {
        printf("用法: %s <owner> <repo> <current_version> <asset_glob> [beta]\n", argv[0]);
        return 2;
    }

    au_config_t cfg;
    memset(&cfg, 0, sizeof cfg);
    cfg.owner           = argv[1];
    cfg.repo            = argv[2];
    cfg.current_version = argv[3];
    cfg.asset_pattern   = argv[4];
    cfg.mode            = AU_MODE_EXE;
    cfg.channel         = (argc >= 6 && strcmp(argv[5], "beta") == 0) ? AU_CHANNEL_BETA : AU_CHANNEL_STABLE;
    cfg.on_progress     = on_progress;
    cfg.on_log          = on_log;

    au_ctx_t* ctx = au_create(&cfg);
    if (!ctx) { fprintf(stderr, "au_create 失败\n"); return 1; }

    printf("当前版本 %s，正在检测 %s/%s（%s 通道）...\n",
           cfg.current_version, cfg.owner, cfg.repo,
           cfg.channel == AU_CHANNEL_BETA ? "beta" : "stable");

    au_release_t* rel = NULL;
    au_err_t e = au_fetch_latest(ctx, &rel);
    if (e != AU_OK) { fprintf(stderr, "检测失败: %s\n", au_strerror(e)); au_destroy(ctx); return 0; }

    int cmp = au_compare_current(ctx, rel);
    printf("最新版本 %s（方向 %s）\n", rel->ver.raw,
           cmp > 0 ? "更新" : cmp < 0 ? "更旧" : "相同");
    if (rel->changelog) printf("--- 更新日志 ---\n%s\n----------------\n", rel->changelog);

    if (cmp > 0) {
        const au_asset_t* a = au_pick_asset(rel, cfg.asset_pattern);
        if (!a) { fprintf(stderr, "无匹配资产: %s\n", cfg.asset_pattern); au_release_free(rel); au_destroy(ctx); return 1; }
        printf("将下载 %s (%llu 字节)。回车继续，Ctrl+C 取消...", a->name, (unsigned long long)a->size);
        int input = getchar();
        (void)input;

        char path[512];
        e = au_download(ctx, a, path, sizeof path);
        printf("\n");
        if (e != AU_OK) { fprintf(stderr, "下载失败: %s\n", au_strerror(e)); au_release_free(rel); au_destroy(ctx); return 1; }
        printf("已下载到 %s，正在应用更新...\n", path);
        e = au_apply(ctx, path);   /* 成功则不返回 */
        fprintf(stderr, "应用更新失败: %s\n", au_strerror(e));
    } else {
        printf("无需更新。\n");
    }

    au_release_free(rel);
    au_destroy(ctx);
    return 0;
}
