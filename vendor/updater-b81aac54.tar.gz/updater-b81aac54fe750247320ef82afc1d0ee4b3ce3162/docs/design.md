# WinAutoUpdate 设计文档

Windows 平台纯 C 静态库，为**任意 Windows 程序**（控制台 / GUI / 托盘常驻）提供基于 GitHub Release 的自动更新能力。

- **状态**：已实现并双工具链（MSVC + MinGW-w64）测试通过
- **日期**：2026-07-17 定稿设计，2026-07-18 完成实现
- **实现计划**：见 [plan.md](plan.md)
- **实现期变更**：见文末 [§14 实现补遗](#14-实现补遗)——安装器模式、单实例握手、依赖收缩等对本文原设计的修订都记录在那里。

---

## 1. 目标与范围

### 1.1 要解决的问题

一个开源的 Windows 控制台工具（下称 `tools.exe`），源码托管在 GitHub，由 Actions 打包并发布 Release。需要让它能自己检测新版本、下载、替换、重启，全程无 GUI。

### 1.2 明确不做的事

| 不做 | 原因 |
|---|---|
| 跨平台（Linux / macOS） | 全部实现依赖 Win32 API，跨平台需要完全不同的第二套实现 |
| GUI | 库只提供 C 函数与回调，任何 UI 都由调用方实现 |
| 异步 API | 见 §5.1 |
| 断点续传 | 见 §5.2 |
| 后台静默更新 | 更新必然要重启进程，静默重启对控制台工具是有害行为 |
| ZIP 更新的事务性回滚 | 见 §9.2，这是**已知限制**，不是待办事项 |

### 1.3 依赖约束

这条约束常被粗糙地表述为「零第三方依赖」，但那不是真正的诉求。真正的诉求是两句话：

**禁止**引入带独立构建系统或运行时 DLL 的依赖。OpenSSL、BoringSSL、libcurl、zlib 都在此列——它们会让「clone 下来直接编译」变成「先配三个子项目」，并让产物从一个 exe 变成一个 exe 加几个 dll。

**允许**将单文件/双文件源码 vendor 进仓库，与自有 `.c` 一起编译。这不破坏上述任何一点：不需要包管理器、不需要额外 DLL、`cl.exe` 一条命令仍然编得过。

据此只引入一个 vendored 依赖：

| 库 | 文件 | 协议 | 为什么值得引 |
|---|---|---|---|
| [cJSON](https://github.com/DaveGamble/cJSON) | `cJSON.c` `cJSON.h` | MIT | JSON 字符串反转义要处理 `\uXXXX` 转 UTF-8 及 UTF-16 代理对（emoji 走这条路），而 `body` 字段是维护者随手写的任意文本，内容不受我们控制。写错就是静默乱码或越界 |
cJSON 源码置于 `src/third_party/`，LICENSE 随仓库分发。SemVer 比较由 `au_version.c` 严格实现，避免宽松解析和数字预发布标识符溢出。

### 1.4 系统库依赖

```
winhttp.lib   HTTPS 请求（TLS 与证书链校验由 WinHTTP 内部完成）
bcrypt.lib    SHA-256（CNG API）
```

仅此两个，均属 Windows SDK。

值得说明的是不需要什么：

- **不需要 `crypt32.lib`**——它是管证书的，不是管哈希的。WinHTTP 内部已完成 TLS 证书链校验，无需显式链接。SHA-256 的现代 API 是 CNG（`bcrypt.lib`），而非 `crypt32` 中的老式 `CryptAcquireContext`。
- **不需要 `shell32.lib`**——ZIP 解压改用 `tar.exe`（§7.2），COM 方案连同它一起消失。
- **不需要 `advapi32.lib`**——无实际调用点。

### 1.5 运行环境

Windows 10 1803 及以上、Windows 11。1803 是 `tar.exe` 随系统分发的起点（§7.2），构成硬性下限。

工具链：MSVC (`cl.exe`) 或 MinGW-w64，通过 CMake 组织。

---

## 2. 架构

自底向上分层，箭头表示依赖方向：

```
                       win_autoupdate.h        ← tools.exe 只看到这个
                              │
                        au_update.c             编排：检测 → 下载 → 应用
                              │
      ┌───────────────┬───────┴───────┬────────────────┐
      │               │               │                │
   au_gh.c       au_download.c    au_apply.c      au_version.c
   GitHub API    下载与校验        替换与重启       版本解析比较
      │               │               │                │
      │        ┌──────┴──────┐        │                │
      │        │             │        │                │
   au_http.c   │         au_hash.c  au_fs.c            │
   WinHTTP     │         BCrypt     文件与 tar.exe      │
      │        │                        │              │
      └────────┴────────┬───────────────┘              │
                        │                              │
                     au_str.c                    au_version.c
                  UTF-8↔UTF-16、glob

   third_party/cJSON ← au_gh.c
```

`au_str.c` 被 `au_http.c` / `au_fs.c` / `au_gh.c` 共用（Win32 全套是 wide char，任何碰系统 API 的地方都要转码）。两个 vendored 依赖各自只被一个模块引用，且都不出现在公开头文件里。

每个模块的职责与边界：

| 模块 | 职责 | 依赖 |
|---|---|---|
| `au_str.c` | UTF-8 ↔ UTF-16 转换、glob 匹配 | 无（纯函数） |
| `au_version.c` | 严格 SemVer 2.0 解析与比较 | 无（纯函数、无堆） |
| `au_hash.c` | 文件 SHA-256 | bcrypt |
| `au_http.c` | HTTPS GET 到内存 / 到文件，进度，取消 | winhttp, au_str |
| `au_fs.c` | 临时路径、可写性探测、原子替换、tar.exe 解压 | kernel32, au_str |
| `au_gh.c` | GitHub API 请求与响应解析 | au_http, cJSON, au_version |
| `au_download.c` | 资产下载与哈希校验 | au_http, au_hash, au_fs |
| `au_apply.c` | 自替换与重启 | au_fs |
| `au_update.c` | 上层编排，持有 `au_ctx_t` | 以上全部 |

`au_str.c` 与 `au_version.c` 是纯函数，无 IO、无 Win32 句柄，可完全离线单测。这是测试策略的支点（§10）。

---

## 3. 公开 API

```c
/* ============ win_autoupdate.h ============ */
#ifndef WIN_AUTOUPDATE_H
#define WIN_AUTOUPDATE_H

#include <stdint.h>
#include <stddef.h>

#ifdef __cplusplus
extern "C" {
#endif

/* ---------- 错误码 ---------- */
typedef enum {
    AU_OK = 0,
    AU_ERR_ARG,           /* 参数非法 */
    AU_ERR_NOMEM,
    AU_ERR_NET,           /* 连接 / DNS / 超时 */
    AU_ERR_HTTP,          /* 非 2xx 响应 */
    AU_ERR_RATELIMIT,     /* 403 且 X-RateLimit-Remaining: 0，见 §4.4 */
    AU_ERR_PARSE,         /* JSON 结构不符预期 */
    AU_ERR_NO_ASSET,      /* asset_pattern 无匹配项 */
    AU_ERR_IO,            /* 文件读写失败 */
    AU_ERR_HASH,          /* SHA-256 与 API 提供的 digest 不符 */
    AU_ERR_EXTRACT,       /* tar.exe 解压失败 */
    AU_ERR_NOT_WRITABLE,  /* 安装目录不可写，需管理员权限，见 §7.1 */
    AU_ERR_REPLACE,       /* 文件替换失败（已回滚） */
    AU_ERR_CANCELED,
} au_err_t;

const char* au_strerror(au_err_t e);

/* ---------- 版本 ----------
 * POD：可自由拷贝、按值传递，无需释放。
 * 实现无堆分配，原因见 §4.3 */
typedef struct {
    int  major, minor, patch;
    char prerelease[32];   /* "beta.2"；空串表示正式版 */
    char raw[64];          /* 原始 tag，如 "v1.2.0-beta.2" */
} au_version_t;

au_err_t au_version_parse(const char* tag, au_version_t* out);

/* <0: a 旧于 b   0: 等价   >0: a 新于 b
 * 遵循 semver 2.0 优先级规则，忽略 +build 元数据 */
int au_version_cmp(const au_version_t* a, const au_version_t* b);

/* ---------- 资产与发布 ---------- */
typedef struct {
    char*    name;      /* "tools-v1.2.3-x64.exe" */
    char*    url;       /* browser_download_url */
    char*    sha256;    /* 来自 API digest 字段；老 release 可能为 NULL */
    uint64_t size;
} au_asset_t;

typedef struct {
    au_version_t ver;
    char*        changelog;      /* 已反转义的 UTF-8 文本 */
    int          is_prerelease;
    au_asset_t*  assets;
    size_t       asset_count;
} au_release_t;

void au_release_free(au_release_t* rel);

/* ---------- 回调 ---------- */

/* 在 au_download() 内部、调用方线程上被反复调用。见 §6
 * total    总字节数；服务端未返回 Content-Length 时为 0
 * done     已下载字节数
 * 返回值   0 = 继续，非 0 = 请求取消 */
typedef int (*au_progress_cb)(uint64_t total, uint64_t done, void* userdata);

typedef enum { AU_LOG_DEBUG, AU_LOG_INFO, AU_LOG_WARN, AU_LOG_ERROR } au_log_level_t;
typedef void (*au_log_cb)(au_log_level_t lv, const char* msg, void* userdata);

/* ---------- 配置 ---------- */
typedef enum { AU_MODE_EXE = 1, AU_MODE_ZIP = 2 } au_mode_t;
typedef enum { AU_CHANNEL_STABLE = 0, AU_CHANNEL_BETA = 1 } au_channel_t;

typedef struct {
    /* 必填 */
    const char*  owner;             /* "Hunlongyu" */
    const char*  repo;              /* "tools" */
    const char*  current_version;   /* "v1.2.3" 或 "1.2.3" */
    const char*  asset_pattern;     /* glob，如 "tools-*-x64.exe" */
    au_mode_t    mode;

    /* 可选，0/NULL 取默认值 */
    au_channel_t channel;           /* 默认 AU_CHANNEL_STABLE */
    const char*  user_agent;        /* 默认 "WinAutoUpdate/1.0"，见 §4.4 */
    const char*  token;             /* 默认匿名（60 次/小时/IP） */

    const char* const* mirrors;     /* URL 模板数组，见 §4.5。NULL 用内置默认 */
    size_t       mirror_count;

    int          timeout_ms;        /* 默认 30000 */
    int          retry_max;         /* 默认 2 */

    au_progress_cb on_progress;
    au_log_cb      on_log;
    void*          userdata;        /* 原样透传给两个回调 */
} au_config_t;

/* ---------- 上下文 ---------- */
typedef struct au_ctx au_ctx_t;    /* 不透明 */

au_ctx_t* au_create(const au_config_t* cfg);
void      au_destroy(au_ctx_t* ctx);

/* 线程安全，可从其他线程调用（如 Ctrl+C 处理函数）。见 §6.2 */
void      au_cancel(au_ctx_t* ctx);

/* ---------- 检测 ---------- */

/* 拉取 channel 内【版本号最高】的 release。
 * 注意不是列表第一项——GitHub 按 created_at 排序，原因见 §4.1 */
au_err_t au_fetch_latest(au_ctx_t* ctx, au_release_t** out);

/* <0: 候选比当前旧   0: 相同   >0: 候选更新
 * 库只报告方向，要不要动由调用方决定。见 §4.6 */
int au_compare_current(au_ctx_t* ctx, const au_release_t* rel);

/* 按 glob 在 rel->assets 中匹配。无匹配或多重匹配均返回 NULL */
const au_asset_t* au_pick_asset(const au_release_t* rel, const char* pattern);

/* ---------- 下载与应用 ---------- */

/* 阻塞。落地路径写入 out_path。期间反复触发 on_progress */
au_err_t au_download(au_ctx_t* ctx, const au_asset_t* a, char* out_path, size_t cap);

/* 替换并重启。成功时【本函数不返回】——进程已被 ExitProcess 终止 */
au_err_t au_apply(au_ctx_t* ctx, const char* pkg_path);

/* ---------- 重启后清理 ----------
 * 新版启动时尽早调用，清理上一次更新残留的 .old 文件与临时目录。
 * 幂等，无残留时是空操作，无需判断是否刚更新过。见 §7.1 */
void au_cleanup_after_restart(void);

#ifdef __cplusplus
}
#endif
#endif /* WIN_AUTOUPDATE_H */
```

### 3.1 调用方完整示例

```c
#include "win_autoupdate.h"
#include <stdio.h>

static int on_progress(uint64_t total, uint64_t done, void* ud) {
    if (total) printf("\r下载 %3d%%  %llu/%llu", (int)(done * 100 / total), done, total);
    else       printf("\r已下载 %llu 字节", done);   /* total 可能为 0，见 §6.1 */
    fflush(stdout);
    return 0;
}

int main(void) {
    au_cleanup_after_restart();          /* 第一件事：清理上次更新残留 */

    au_config_t cfg = {0};
    cfg.owner           = "Hunlongyu";
    cfg.repo            = "tools";
    cfg.current_version = "v1.2.3";
    cfg.asset_pattern   = "tools-*-x64.exe";
    cfg.mode            = AU_MODE_EXE;
    cfg.channel         = AU_CHANNEL_STABLE;
    cfg.on_progress     = on_progress;

    au_ctx_t* ctx = au_create(&cfg);
    if (!ctx) return 1;

    au_release_t* rel = NULL;
    au_err_t e = au_fetch_latest(ctx, &rel);
    if (e != AU_OK) {
        fprintf(stderr, "检测失败：%s\n", au_strerror(e));
        au_destroy(ctx);
        return 0;                         /* 检测失败不应阻塞工具本体启动 */
    }

    if (au_compare_current(ctx, rel) > 0) {
        printf("发现新版本 %s\n\n%s\n\n是否更新？[y/N] ", rel->ver.raw, rel->changelog);
        if (getchar() == 'y') {
            const au_asset_t* a = au_pick_asset(rel, cfg.asset_pattern);
            char path[260];
            if (a && (e = au_download(ctx, a, path, sizeof path)) == AU_OK)
                e = au_apply(ctx, path);  /* 成功则不返回 */
            if (e != AU_OK) fprintf(stderr, "\n更新失败：%s\n", au_strerror(e));
        }
    }

    au_release_free(rel);
    au_destroy(ctx);
    return 0;
}
```

---

## 4. GitHub API 层

### 4.1 端点选择：为什么不用 `releases/latest`

因为 beta 通道在范围内，而 `/releases/latest` **按定义排除预发布版与草稿**。所以统一使用列表端点：

```
GET https://api.github.com/repos/{owner}/{repo}/releases?per_page=100
```

`per_page` 默认仅 30，必须显式指定。

**关键陷阱：GitHub 按 `created_at` 排序，不是按版本号排序。** `/releases` 与 `/releases/latest` 都是如此——官方文档对 latest 的定义就是「最近的非预发布、非草稿版本，按 `created_at` 排序」。

这会导致降级：先发布 `v1.1.0`，之后为老用户补一个 `v1.0.1` 热修，则列表顺序为 `[v1.0.1, v1.1.0]`，**取第一项即降级**。

因此必须对筛选后的候选**全部用 `au_version_cmp` 排序取最大值**，绝不能取列表首项。这也要求比较器严格处理所有预发布标识符边界。

筛选规则：

1. `draft == true` → **无条件剔除**（草稿仅对有 push 权限的认证请求可见，但仍须防御）
2. `channel == AU_CHANNEL_STABLE` 且 `prerelease == true` → 剔除
3. 剩余候选按 `au_version_cmp` 取最大

### 4.2 版本比较规则

SemVer 2.0 优先级规则：

```
1.0.0-alpha < 1.0.0-alpha.1 < 1.0.0-alpha.beta < 1.0.0-beta
            < 1.0.0-beta.2 < 1.0.0-beta.11 < 1.0.0-rc.1 < 1.0.0
```

规则细节：点分标识符逐段比较；纯数字段按数值比较；含字母段按 ASCII 字典序比较；数字段优先级恒低于字母段；前置段全等时段数多者更大；`+build` 元数据完全不参与比较。

此排序序列取自 semver 2.0 规范第 11 节，直接用作单测的黄金向量（§10.1）。

### 4.3 严格、无堆的 SemVer 实现

`au_version.c` 要求完整的 `major.minor.patch`，拒绝负数、核心版本前导零、空标识符、数字预发布标识符前导零及尾随垃圾。核心版本受公开 `int` 字段范围限制，prerelease 受公开 32 字节字段限制。

比较预发布的纯数字段时不转换为整数，而是先比有效十进制长度、再逐字节比较，因此任意长度（字段容量内）的数字都不会溢出。`au_version_t` 始终保持可按值复制、无需释放的 POD。

### 4.4 请求头与限流

| 头 | 值 | 必要性 |
|---|---|---|
| `User-Agent` | `cfg.user_agent` | **强制**。缺失时 GitHub 直接返回 403 |
| `Accept` | `application/vnd.github+json` | 推荐 |
| `X-GitHub-Api-Version` | `2022-11-28` | 推荐，避免默认版本漂移 |
| `Authorization` | `Bearer <token>` | 仅 `cfg.token` 非 NULL 且目标为直连 `api.github.com` 时 |

限流：匿名 **60 次/小时/IP**，带 token 5000 次/小时。国内共享出口 IP 很容易撞上。

**必须区分限流 403 与普通 403**：GitHub 限流返回 403 而非 429。靠响应头 `X-RateLimit-Remaining: 0` 判定，映射到 `AU_ERR_RATELIMIT`。否则会把限流误报成「仓库不存在」，让用户去查一个根本没问题的配置。

`browser_download_url` 可能重定向到 GitHub 的资产 CDN。自定义 `Authorization` 头不能依赖 WinHTTP 自动剥离；当前实现禁用自动重定向，逐跳检查目标，在跨源后移除认证头且不重新添加。初始认证头也仅允许发送到 HTTPS、443 端口的 `api.github.com` API 请求，不发往镜像或资产下载端点。

### 4.5 镜像源

**jsdelivr 不可用。** `cdn.jsdelivr.net/gh/` 只服务仓库内的源码文件（且单文件 20MB 上限）。Release 附件存放在 `objects.githubusercontent.com`，jsdelivr 不代理该类资产。

改用 URL 模板机制，`{url}` 为完整原始 URL 的占位符：

```c
static const char* AU_DEFAULT_MIRRORS[] = {
    "{url}",                        /* 官方直连优先 */
    "https://gh-proxy.com/{url}",
    "https://ghfast.top/{url}",
};
```

设计要点：

- **默认值可被完全覆盖。** 公共加速站生命周期短、时有跑路，硬编码会随版本腐烂。`cfg.mirrors` 让用户指向自建反代。
- **API 元数据只走直连 HTTPS。** 它同时决定资产 URL 与摘要，不能让公共代理自签一套“URL + 恶意文件 + 摘要”。
- **镜像只用于有合法 SHA-256 的资产。** 无摘要资产告警后仅走原始 HTTPS URL；有摘要资产可轮换镜像，但落盘后必须校验。
- **token 不进入镜像。** `Authorization` 仅发给直连 `api.github.com`。
- **逐个尝试。** 当前源返回超时 / 连接失败 / 5xx / 404 时切下一个。全部失败返回 `AU_ERR_NET`。
- **`AU_ERR_RATELIMIT` 不触发换源**，因为限流是账号/IP 维度的，换代理反而可能让不同源看到不同的限流状态，产生难以理解的间歇性失败。

### 4.6 方向由调用方决定

`channel` 与「方向」是正交的两件事：

- **channel 决定哪些 release 算候选**（过滤）——归库。
- **方向决定要不要动**（策略）——归调用方。

所以没有 `au_is_newer()`，只有 `au_compare_current()` 返回 -1/0/1。

这个区分在通道回退时才显出必要性：用户从 beta 切回 stable，手里是 `v1.2.0-beta.3`，而最新正式版是 `v1.1.0`。此时 `au_compare_current()` 返回负值，是降级还是停在原地等 `v1.2.0` 正式发布，库不做决定——因为这取决于 `tools.exe` 的配置/数据格式能否被旧版读懂，只有它自己知道。

---

## 5. 被砍掉的设计及其理由

### 5.1 异步 API 与状态机

**砍掉** `au_check_release_async()`、`au_get_state()`、`au_state_t`。

异步接口原本的形态是 `au_check_release_async(out_info)`，但它没有完成通知机制——调用方无从得知何时可以安全读取 `out_info`。

更根本的问题是它解决的不是真问题。异步唯一提供的价值是「下载期间调用方线程能干别的」，而进度上报并不需要异步（见 §6）。对控制台工具而言，下载期间本来也没有别的事要做。真需要后台化时，调用方自己 `CreateThread` 包一层即可——它比库更清楚自己的线程模型。

状态机随之一并砍掉。同步 API 下，状态就是调用序列本身；一个 `au_get_state()` 只会与真实控制流不同步，成为 bug 来源。可见性交给 `au_log_cb`。

### 5.2 断点续传

**砍掉。** 工具 exe 通常几 MB，重下成本极低。而续传要处理 Range 请求、服务端 206 支持探测、切换镜像源后字节偏移失效、断点文件跨版本过期——一堆边界，换不来相称的收益。

原方案中「基于文件大小判断断点」与「校验文件长度确认完整」本身就直接矛盾：同一个「文件大小等于预期」的事实，无法同时用来判定「已下完」和「该续传」。

失败即整包重下。校验改为 SHA-256（§8），比长度校验强得多。

### 5.3 bat 更新脚本

**砍掉。** Windows 只禁止**删除**正在运行的 exe，**重命名是允许的**。这让 bat 完全没有必要，详见 §7.1。

bat 方案的代价是真实的：路径含空格与中文需处理、bat 是 ANSI 编码而路径可能是 Unicode、轮询等待进程退出存在竞态、生成并执行临时脚本极易被杀软拦截。

### 5.4 IShellDispatch 解压

**砍掉。** `IShellDispatch::CopyHere` 是**异步**的——调用后立即返回，必须轮询探测解压是否完成，且无可靠的完成信号；还可能弹出确认对话框，控制台程序无从拦截。改用 `tar.exe`（§7.2）。

---

## 6. 进度与取消模型

这是本库最容易被想当然搞错的地方，故单列一节。

**「同步」与「有进度」是正交的两件事。** 进度需要的是回调，不是异步。

### 6.1 进度

回调在 `au_download()` **内部**触发，运行在调用方自己的线程上——因为 `au_download()` 内部本就是一个循环：

```c
/* au_download.c 内部 */
for (;;) {
    WinHttpQueryDataAvailable(hReq, &avail);
    if (avail == 0) break;                       /* 下完 */
    WinHttpReadData(hReq, buf, avail, &nread);
    fwrite(buf, 1, nread, fp);
    done += nread;

    if (ctx->on_progress && ctx->on_progress(total, done, ctx->userdata) != 0)
        return AU_ERR_CANCELED;                  /* 同线程取消 */
    if (au_ctx_is_canceled(ctx))
        return AU_ERR_CANCELED;                  /* 跨线程取消 */
}
```

`WinHttpReadData` 每次返回数 KB 到数十 KB，回调触发频率足够驱动控制台进度条。

调用方写的是普通的阻塞调用，进度自动刷新——库自己不打印任何东西，只把数字递出去，显示形式（进度条、日志、转发给 GUI）完全由调用方决定。这也是「无 GUI」与「上层可做任意 UI」能同时成立的原因。

**`total` 可能为 0。** GitHub CDN 在某些情况下使用 chunked 编码，不返回 `Content-Length`，此时无法计算百分比。

因此回调签名中**不提供 `pct` 参数**。给出 `pct` 会迫使库在拿不到总长时编造一个假百分比，把「不知道总大小」这个事实藏起来。原样给出 `total` 与 `done`，由调用方决定显示百分比还是仅显示字节数。

**不提供轮询式 `au_get_progress()`。** 同步模型下调用方线程正阻塞在 `au_download()` 内，没有机会调用它：

```c
au_download(ctx, a, path, sizeof path);   /* 阻塞在此 */
au_get_progress(ctx, &total, &done);      /* 执行到这里时永远是 100% —— 毫无意义 */
```

### 6.2 取消

两条路径，覆盖不同场景：

| 路径 | 触发线程 | 场景 |
|---|---|---|
| `on_progress` 返回非 0 | 阻塞中的那个线程 | 调用方在回调里自行判断不下了 |
| `au_cancel(ctx)` | 其他线程 | Ctrl+C、UI 事件 |

`au_cancel()` 通过 `InterlockedExchange` 设置原子标志，下载循环每轮检查。这与同步 API 不冲突——发起取消的线程本来就不是阻塞在 `au_download()` 里的那个。

典型用法是 `SetConsoleCtrlHandler`：Ctrl+C 处理函数由系统在**另一个线程**上调用，在其中调 `au_cancel(ctx)`，主线程的 `au_download()` 会在下一轮循环返回 `AU_ERR_CANCELED`。

---

## 7. 更新执行

### 7.1 模式 A：单文件替换（`AU_MODE_EXE`）

**自重命名法，无需外部脚本。**

Windows 允许重命名正在运行的 exe（只是不允许删除）。Chrome、Firefox 用的都是这一类机制。

```
1. 探测可写性        安装目录不可写 → AU_ERR_NOT_WRITABLE（提前失败）
2. GetModuleFileNameW 取自身完整路径，如 C:\tools\tools.exe
3. 下载到同目录       C:\tools\tools.exe.new     ← 必须同目录，见下
4. 校验 SHA-256      不符 → 删除 .new，返回 AU_ERR_HASH
5. MoveFileExW       tools.exe     → tools.exe.old
6. MoveFileExW       tools.exe.new → tools.exe   ← 失败则把 .old 改回，返回 AU_ERR_REPLACE
7. CreateProcessW    启动新的 tools.exe，透传原始命令行参数
8. ExitProcess(0)    本进程退出，释放对 .old 的占用
9. 新版启动          au_cleanup_after_restart() 删除 .old
```

**为什么临时文件必须落在 exe 同目录，而不是 `%TEMP%`：**

`MoveFileExW` 跨卷时对文件会退化为 copy + delete，原子性消失——中途失败会留下一个残缺的 `tools.exe`。而 `%TEMP%` 很可能位于另一个盘。落在同目录可保证 rename 是同卷操作，因而是原子的。

若 exe 所在目录不可写（典型如安装在 `Program Files`），整个更新在没有管理员权限时无法完成。**必须在第 1 步就探测并返回 `AU_ERR_NOT_WRITABLE`**，而不是走到第 5 步才失败——那时已经下载完毕，白费用户的带宽和时间。

探测方式：在目标目录尝试创建并立即删除一个临时文件。

**`au_cleanup_after_restart()` 是必需接口，不是可选项。** 不调用则 `.old` 文件永久残留。它必须幂等：无残留时是空操作，因此调用方无需判断自己是否刚更新过，无脑放在 `main()` 开头即可。

### 7.2 模式 B：完整包替换（`AU_MODE_ZIP`）

解压使用 **`tar.exe`**：Windows 10 1803 起随系统分发的 bsdtar，原生支持 zip。

```c
tar.exe -xf "C:\tools\_au_tmp\pkg.zip" -C "C:\tools\_au_tmp\extract"
```

相比 `IShellDispatch` 的优势：同步执行、有明确退出码、无 UI、无需 COM 初始化、不需要 `shell32.lib`。代价是把系统下限钉在 1803（§1.5）。

通过 `CreateProcessW` 调用，`CREATE_NO_WINDOW` 抑制窗口，`WaitForSingleObject` 等待，`GetExitCodeProcess` 取结果。非 0 → `AU_ERR_EXTRACT`。

流程：

```
1. 探测安装目录可写性     不可写 → AU_ERR_NOT_WRITABLE
2. 下载 zip 到           <安装目录>\_au_tmp\pkg.zip
3. 校验 SHA-256
4. tar -xf 解压到        <安装目录>\_au_tmp\extract\
5. 校验解压产物中存在主 exe   否则 AU_ERR_EXTRACT（防止发错包）
6. 重命名当前 exe →       tools.exe.old
7. 覆盖复制 extract\* →   安装目录
8. CreateProcessW 启动新 exe，ExitProcess(0)
9. 新版 au_cleanup_after_restart() 清理 .old 与 _au_tmp\
```

第 3 至 5 步的顺序是刻意的：**先把全部校验做完，再动安装目录**。这样绝大多数失败（网络、损坏、发错包）都发生在覆盖开始之前，此时安装目录还完全没被碰过。

---

## 8. 完整性校验

**SHA-256 进核心，不是扩展项。**

GitHub Release Asset 的 API 响应包含 `digest` 字段，格式为 `"sha256:abc123..."`。直接取用，无需自行上传 `checksums.txt`。

```c
/* au_hash.c，CNG API */
BCryptOpenAlgorithmProvider(&hAlg, BCRYPT_SHA256_ALGORITHM, NULL, 0);
/* 流式喂入文件内容 → BCryptHashData */
BCryptFinishHash(...);
```

`digest` 为 `null`（较早的 release 没有该字段）时跳过校验，并通过 `au_log_cb` 发出 `AU_LOG_WARN`——**跳过校验必须留下痕迹**。此时禁用全部镜像，只允许原始 HTTPS URL，避免无信任锚的第三方代理替换资产。

---

## 9. 错误处理与已知限制

### 9.1 错误分类与处理

| 情况 | 返回 | 处理 |
|---|---|---|
| 无网络 / DNS 失败 | `AU_ERR_NET` | 调用方应忽略并正常启动旧版工具；更新失败绝不该阻塞工具本体 |
| 所有镜像均失败 | `AU_ERR_NET` | 同上 |
| API 限流 | `AU_ERR_RATELIMIT` | 提示用户稍后再试或配置 token。**不换源重试**（§4.5） |
| 仓库/Release 不存在 | `AU_ERR_HTTP` | 配置错误，应显式报错而非静默 |
| `asset_pattern` 无匹配 | `AU_ERR_NO_ASSET` | 发版流程出了问题，应显式报错 |
| SHA-256 不符 | `AU_ERR_HASH` | 删除临时文件，不重试（重试大概率同样结果） |
| 目录不可写 | `AU_ERR_NOT_WRITABLE` | 提示需管理员权限。**在下载前探测** |
| 替换失败 | `AU_ERR_REPLACE` | 已回滚 `.old`，安装保持原状 |
| 用户取消 | `AU_ERR_CANCELED` | 清理临时文件 |

### 9.2 已知限制：ZIP 模式无事务性

**这是设计取舍，不是待修的缺陷。**

§7.2 第 7 步（覆盖复制）中途失败——磁盘写满、某个文件被另一进程占用、断电——会让安装目录停在半更新状态：部分文件是新版，部分是旧版。

真正的事务性回滚需要在覆盖前完整备份整个安装目录，并在失败时逐一还原。这需要双倍磁盘空间和一套崩溃恢复日志，超出本库范围。

缓解措施只做到「先全部下载、校验、解压完毕，再开始覆盖」（§7.2 的步骤顺序），使绝大多数失败落在覆盖开始之前。覆盖窗口本身仍不受保护。

`AU_MODE_EXE` 使用两次同卷重命名，不具备整体事务性。安装新文件或创建新版进程失败时会尽力恢复 `.old`；恢复失败返回 `AU_ERR_REPLACE`。断电以及新版进程创建成功后自身崩溃仍需宿主设计恢复方案。

### 9.3 其他边界

- **解析失败按等价处理**（§4.3）：`au_version_cmp` 遇到无法解析的 tag 返回 0，即「不更新」。对一个自动替换用户 exe 的库，无法判断时的安全默认值是「什么都不做」。
- **多重匹配返回 NULL**：`au_pick_asset` 在 glob 匹配到多个资产时返回 NULL 而非任选其一。这通常意味着 `asset_pattern` 写得不够精确（例如同时匹配到 x64 与 arm64），猜错的代价是给用户装上跑不了的架构。
- **`raw[64]` 截断**：超长 tag 会被截断。GitHub tag 长度上限远超 64，但正常语义化版本 tag 不可能接近该值。解析时若发现超长直接返回 `AU_ERR_ARG`，不静默截断。

---

## 10. 测试策略

网络 + Win32 + 自替换的组合让端到端测试很难做全，因此测试重心放在能做扎实的地方。

### 10.1 纯函数单测（无网络、无 IO）

`au_str.c` 与 `au_version.c` 是全库唯二的纯函数模块，也是最好测的：

- **`au_version_cmp`**：§4.2 的排序序列取自 semver 2.0 规范第 11 节，直接作为黄金向量逐对断言。
- **`au_version_parse`**：`v1.2.3` / `1.2.3` / `v1.2.3-beta.1` / `v1.2.3+build.5` / 畸形输入。
- **glob 匹配**：`tools-*-x64.exe` 对各种资产名，含无匹配与多重匹配。
- **UTF-8 ↔ UTF-16**：ASCII、中文、emoji（走 UTF-16 代理对）、空串、截断的多字节序列。

### 10.2 离线解析测试

把真实的 GitHub API 响应存为 `tests/fixtures/*.json`，离线喂给 `au_gh.c`。这样能测到在线测试几乎覆盖不到的路径：

- `digest` 为 null 的老 release
- `body` 含 `\n` `\"` `\uXXXX` 与 emoji
- **`body` 内含字面文本 `"tag_name":`**（这正是 strstr 截取方案会被骗的场景）
- 列表按 `created_at` 排序但版本号乱序（§4.1 的降级陷阱）
- 含 draft 与 prerelease 的混合列表，验证两个通道的筛选

### 10.3 在线集成测试

打一个真实仓库的已知 release，验证 HTTP 层与端到端解析。**这类测试会被 API 限流影响**（匿名 60 次/小时），故与单测分离，不进默认 `ctest` 目标。

### 10.4 自替换测试

需要真实进程。做法是构建一个 fixture exe，让它打印自己的版本号并调用 `au_apply()` 替换成另一个版本的 fixture，由测试脚本断言重启后打印的版本号已改变，且 `.old` 已被清理。

不引入测试框架，用最简 assert 宏。测试代码本身也不该带依赖。

---

## 11. 构建

```
c_update/
├── docs/
│   ├── design.md              本文档
│   └── plan.md                分阶段实现计划
├── include/
│   └── win_autoupdate.h       唯一的公开头文件
├── src/
│   ├── au_update.c            编排
│   ├── au_gh.c                GitHub API
│   ├── au_download.c          下载与校验
│   ├── au_apply.c             替换与重启
│   ├── au_version.c           版本
│   ├── au_http.c              WinHTTP
│   ├── au_hash.c              BCrypt SHA-256
│   ├── au_fs.c                文件与 tar.exe 解压
│   ├── au_str.c               UTF-8↔UTF-16、glob
│   ├── au_internal.h          内部共享声明
│   └── third_party/
│       └── cJSON.c / cJSON.h / cJSON-LICENSE.txt
├── demo/
│   └── main.c                 控制台演示
├── tests/
│   ├── fixtures/*.json
│   └── test_*.c
├── .github/workflows/release.yml
└── CMakeLists.txt
```

产物：静态库 `winautoupdate.lib`（MinGW 下 `libwinautoupdate.a`）。

CMake 组织，MSVC 与 MinGW-w64 均可。仍保持「一条命令编得过」：

```
cl /I include /I src/third_party demo/main.c src/*.c src/third_party/*.c ^
   winhttp.lib bcrypt.lib
```

---

## 12. GitHub Actions 发布规范

打 `v*` tag 触发：

1. MSVC 构建 `tools.exe`（x64）
2. 打包完整包 `tools-v{VERSION}-win-x64.zip`
3. 创建 Release，上传两个资产：
   - `tools-v{VERSION}-x64.exe`
   - `tools-v{VERSION}-win-x64.zip`
4. changelog 写入 Release body

约定：

- tag 格式 `v{major}.{minor}.{patch}[-prerelease]`，如 `v1.0.0`、`v1.1.0-beta.2`
- 预发布版必须勾选 Release 的 `prerelease` 标志——**筛选依据是这个标志，不是 tag 里的 `-beta` 字样**（§4.1）
- 资产名含架构标识，避免 `asset_pattern` 多重匹配（§9.3）
- 公开仓库无需 token

---

## 13. 后续可扩展项

明确不在当前范围，但 API 已为其留出位置：

| 项 | 现状 |
|---|---|
| arm64 支持 | 改 `asset_pattern` 即可，库无需改动 |
| 强制更新标记 | 需在 Release body 约定字段，或改用 tag 约定 |
| 自定义代理 | 当前走 `WINHTTP_ACCESS_TYPE_AUTOMATIC_PROXY`（系统代理）。显式代理需扩 `au_config_t` |
| 私有仓库 | `cfg.token` 已预留，但 asset 下载走 `api.github.com` 的另一套 URL，需额外实现 |
| 增量/差分更新 | 范围外。需要服务端配合生成补丁 |

---

## 14. 实现补遗

本节记录实现阶段相对前 13 节原设计的修订，以及为对接真实项目 hua 而增加的设计点。原设计的结论若被推翻，这里说明为什么。

### 14.1 依赖收缩：5 个系统库 → 2 个

原 §1.4 列了 `winhttp / bcrypt / crypt32 / shell32 / advapi32`。实测只需 **`winhttp` + `bcrypt`**：

- `crypt32` 管证书不管哈希，WinHTTP 内部已完成 TLS 证书链校验；SHA-256 用 CNG（`bcrypt`）。
- `shell32` 随 COM 解压方案一起被 `tar.exe` 取代（原 §5.4 已定），无残留调用。
- `advapi32` 无实际调用点。

### 14.2 新增模式 C：安装器（`AU_MODE_INSTALLER`）

原设计只有 EXE 与 ZIP。新增安装器模式对接 NSIS / Inno 等既有安装包：下载安装器 exe，按 `installer_silent`（默认追加 NSIS `/S`）或 `installer_args`（完全自定义，如 Inno 的 `/VERYSILENT`）启动，本进程 `ExitProcess` 退出，由安装器完成替换与拉起新版。

替换语义与前两种根本不同：**替换由安装器负责，不由库负责**。因此本模式没有原子性保证也没有回滚，一切取决于安装器脚本本身。

### 14.3 单实例握手（对接 hua 的必需项）

hua 是 `WIN32` 子系统 + `requireAdministrator` + 命名互斥量单实例的托盘常驻程序。自替换"启动新进程→旧进程退出"的时序会踩一个陷阱：旧进程尚未退出，新进程已启动并发现互斥量存在 → 误判"已在运行"→ 退出 → 一个实例都不剩。

**任何用互斥量做单实例的常驻程序都会踩**，故由库出面解决，而非改每个调用方的单实例逻辑：

- `au_apply` 启动新进程时追加 `--au-wait-pid=<旧PID>`。
- `au_wait_for_predecessor(argc, argv, timeout)`（及宽字符版 `_w`）解析该参数，`OpenProcess(SYNCHRONIZE)` + `WaitForSingleObject` 阻塞等旧进程真正退出。
- 约定：调用方在 `main()` 最前面、**创建互斥量之前**调用它。

端到端测试（fixture v1→v2）已验证握手时序正确：新进程启动时观察到 `.old` 存在（旧进程刚退出），随后 `au_cleanup_after_restart` 清掉它。

### 14.4 ZIP 覆盖保护用户配置（对接 hua 的必需项）

hua 便携模式下 exe 同目录的 `hua.ini` 优先级最高，而发布包里也打了一份默认 `hua.ini`。原 §7.2 的"覆盖 extract\* 到安装目录"会把用户改过的配置冲掉——实打实的数据丢失。

新增 `cfg.zip_exclude` / `zip_exclude_count`：覆盖时，命中排除表**且目标已存在**的文件跳过（basename 大小写不敏感）。目标不存在时仍写入默认配置。已用真实 `tar.exe` 往返测试验证。

### 14.5 定位从"控制台工具"改为"任意 Windows 程序"

原文档多处以"控制台工具"自我定位，§3.1 的示例是 `printf` 进度条。hua 无 stdout（GUI 子系统），该示例对它无意义。库本身无需改动——回调机制正好让 hua 用托盘气泡 / overlay 显示进度——但定位应为"任意 Windows 程序"。`au_wait_for_predecessor_w` 即为 WinMain/`GetCommandLineW` 场景提供的宽字符入口。

### 14.6 模块拆分的落地形态

实际源码比原 §2 略细：下载编排独立为 `au_download.c`（镜像轮换 + 落盘 + SHA-256 校验），与 `au_http.c`（纯 WinHTTP 传输）分离。`au_str.c` 承载 UTF-8↔UTF-16 与 glob。其余与原设计一致。

### 14.7 一个真实 bug 及其教训：缺 `<stdlib.h>` 的指针截断

`au_hash.c` / `au_apply.c` / `au_download.c` / `au_fs.c` 用了 `malloc`/`free` 却漏包含 `<stdlib.h>`。在 C 里这会让 `malloc` 被隐式声明为**返回 `int`**，x64 下 64 位指针被截断成 32 位 → 垃圾指针 → 写入即崩。

MinGW（gcc）靠传递包含侥幸带进了声明，测试全绿；**MSVC 下 `test_hash` 稳定段错误**。正是"每阶段都跑两条工具链"（plan.md 的风险应对）逮到了它。教训固化为一条：凡用堆分配的翻译单元显式包含 `<stdlib.h>`，不依赖传递包含。

### 14.8 测试实现与验收对照

plan.md 各阶段验收项均已落为可执行测试（`ctest`，MSVC + MinGW 双绿）：

- `test_version`：严格 SemVer 2.0 §11 黄金序列、非法语法、超大数字预发布标识符。
- `test_str`：glob、严格 UTF-8/UTF-16 往返与日志格式错误兜底。
- `test_gh`：降级陷阱、draft/prerelease 筛选、digest 与非法/越界 size。
- `test_http` / `test_config` / `test_hash`：HTTPS、query、凭据隔离、配置边界与摘要策略。
- `test_zip`：真实 ZIP、新鲜解压目录、排除规则、重解析点拒绝和删除错误传播。
- 端到端：真实 v1→v2 更新，以及 EXE 移动失败、EXE/ZIP 启动失败、目录型主程序的回滚/拒绝。
