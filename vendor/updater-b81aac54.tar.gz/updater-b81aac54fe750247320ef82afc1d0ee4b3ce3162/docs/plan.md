# WinAutoUpdate 实现计划

配套文档：[design.md](design.md)。本文件只讲**做的顺序**与**每步怎么算做完**，设计决策及其理由一律不重复。

## 排序原则

阶段顺序由**验证成本**决定，不是由架构分层决定：

- **能离线验证的先做。** 阶段 1 的纯函数模块无网络、无 Win32 句柄，测试反馈以毫秒计。把它们放在最前，是因为 `au_version_cmp` 一旦有错，后面每个阶段都会踩到它，而那时候排查成本已经翻了几倍。
- **不可逆的操作最后做。** 自替换（阶段 5）会真的动 exe 文件，调试时容易把工作副本搞坏。它必须建立在「下载出来的东西一定是对的」之上——所以 SHA-256 校验（阶段 4）必须先于它完成。
- **每个阶段结束时仓库是可编译、可运行的**，不留半截状态。

---

## 阶段 0：骨架与构建

**目标**：一个编得过、跑得起来、什么也不做的空壳。

- [ ] 建立 §11 的目录结构
- [ ] vendor cJSON（`cJSON.c` / `cJSON.h` / `LICENSE`）到 `src/third_party/`
- [x] 严格、无堆实现 SemVer 2.0；不引入 semver.c
- [ ] 写完整的 `include/win_autoupdate.h`（design.md §3 已给出全文，直接落盘）
- [ ] 各 `src/au_*.c` 建空文件，函数返回 `AU_ERR_ARG` 占位
- [ ] `demo/main.c` 抄 design.md §3.1
- [ ] `CMakeLists.txt`：静态库 target + demo target + tests target
- [ ] 最简 assert 宏（`tests/test_util.h`），不引测试框架

**验收**

```
cmake -B build && cmake --build build     # MSVC 与 MinGW 各过一次
build\demo.exe                            # 运行不崩，打印占位错误
cl /I include /I src/third_party demo/main.c src/*.c src/third_party/*.c winhttp.lib bcrypt.lib
```

最后一条是「一条命令编得过」这个约束的实际检验，不是装饰——每个阶段结束都要重跑。

---

## 阶段 1：纯函数层

**目标**：`au_str.c` + `au_version.c` 完成并测透。全程无网络、无 IO。

- [ ] `au_utf8_to_wide()` / `au_wide_to_utf8()`——`MultiByteToWideChar` / `WideCharToMultiByte` with `CP_UTF8`
- [ ] `au_match_glob()`——只需支持 `*` 与 `?`
- [ ] `au_version_parse()`——填充 POD `au_version_t`，超长 tag 返回 `AU_ERR_ARG` 而非截断
- [x] `au_version_cmp()`——按 design.md §4.3 严格实现，超大数字标识符不做整数转换
- [ ] `au_strerror()`

**验收**（`tests/test_version.c`、`tests/test_str.c`）

- [ ] semver 2.0 规范第 11 节的排序序列作为黄金向量逐对断言：
      `1.0.0-alpha < 1.0.0-alpha.1 < 1.0.0-alpha.beta < 1.0.0-beta < 1.0.0-beta.2 < 1.0.0-beta.11 < 1.0.0-rc.1 < 1.0.0`
- [ ] 解析：`v1.2.3` / `1.2.3` / `v1.2.3-beta.1` / `v1.2.3+build.5` / `v1.2.3-beta.1+exp.sha.5114f85`
- [ ] 畸形输入：空串、`vv1.2.3`、`1.2`、`abc`、65 字符长 tag → 全部返回错误且**不崩溃**
- [ ] `+build` 元数据不参与比较：`v1.0.0+a` 与 `v1.0.0+b` 判定为等价
- [ ] glob：`tools-*-x64.exe` 匹配 `tools-v1.2.3-x64.exe`，不匹配 `tools-v1.2.3-arm64.exe`
- [ ] UTF-8 往返：ASCII、中文、emoji（走 UTF-16 代理对）、空串、被截断的多字节序列不越界

**为什么先做这个**：这两个模块是全库唯一能在毫秒级反馈里测透的部分，且被后面每个阶段依赖。

---

## 阶段 2：HTTP 层

**目标**：`au_http.c` 能拉到字节。

- [ ] `WinHttpOpen` 用 `WINHTTP_ACCESS_TYPE_AUTOMATIC_PROXY`（系统代理）
- [ ] 显式 `WinHttpSetOption(WINHTTP_OPTION_SECURE_PROTOCOLS, TLS1.2 | TLS1.3)`
- [ ] `WinHttpSetTimeouts`，四个超时值均取自 `cfg.timeout_ms`
- [ ] 请求头：`User-Agent`（**缺失即 403**）、`Accept`、`X-GitHub-Api-Version`、可选 `Authorization`
- [ ] `au_http_get_mem()`——拉到内存，供 API 用
- [ ] `au_http_get_file()`——流式落盘，`WinHttpQueryDataAvailable` + `WinHttpReadData` 循环
- [ ] 从 `WINHTTP_QUERY_CONTENT_LENGTH` 取 total，**取不到时 total = 0，不得编造**
- [ ] 进度回调 + 双路径取消（回调返回值 / `InterlockedExchange` 原子标志）
- [ ] 镜像模板 `{url}` 替换与逐源轮换
- [ ] 重试：超时 / 连接失败 / 5xx / 404 换下一源；**403 限流不换源**
- [ ] 响应头 `X-RateLimit-Remaining: 0` → `AU_ERR_RATELIMIT`

**验收**

- [ ] 拉 `https://api.github.com/repos/DaveGamble/cJSON/releases?per_page=100` 拿到非空 JSON
- [ ] **故意去掉 User-Agent，确认收到 403**——亲手验证一次这个坑，比读文档记得牢
- [ ] 下载一个已知 asset，落盘文件大小与 API 报告的 `size` 一致
- [ ] 进度回调被调用次数 > 1（证明是流式而非一次性读完）
- [ ] 把 `cfg.mirrors` 首项设成不存在的域名，确认自动切到下一源并成功
- [ ] 在回调里返回 1，确认下载中止且返回 `AU_ERR_CANCELED`
- [ ] 另开线程调 `au_cancel()`，确认阻塞中的下载返回 `AU_ERR_CANCELED`

---

## 阶段 3：GitHub API 层

**目标**：`au_gh.c` 把 JSON 变成 `au_release_t`。

- [ ] `GET /repos/{owner}/{repo}/releases?per_page=100`（**不是** `/releases/latest`）
- [ ] cJSON 解析 → `au_release_t`：`tag_name` / `body` / `prerelease` / `draft` / `assets[]`
- [ ] asset 字段：`name` / `browser_download_url` / `size` / `digest`（可能为 null）
- [ ] `digest` 格式 `"sha256:..."`，剥掉前缀存入 `au_asset_t.sha256`
- [ ] 筛选：`draft` 无条件剔除；stable 通道额外剔除 `prerelease`
- [ ] **按 `au_version_cmp` 排序取最大**，绝不取列表首项
- [ ] `au_compare_current()` 返回 -1/0/1
- [ ] `au_pick_asset()`：无匹配或多重匹配均返回 NULL
- [ ] `au_release_free()`

**验收**（离线优先，`tests/fixtures/*.json`）

- [ ] `digest` 为 null 的老 release → 解析成功，`sha256` 为 NULL
- [ ] `body` 含 `\n` `\"` `\uXXXX` 与 emoji → 反转义后文本正确
- [ ] **`body` 内含字面文本 `"tag_name":`** → 仍取到正确的版本号（这正是 strstr 截取方案会被骗的场景，必须有这条）
- [ ] **列表按 `created_at` 排序但版本号乱序**（如 `[v1.0.1, v1.1.0]`）→ 取到 `v1.1.0` 而非 `v1.0.1`。**这条是防降级的核心断言**
- [ ] draft + prerelease 混合列表 → 两个通道各自筛选正确
- [ ] `assets` 为空数组 → `AU_ERR_NO_ASSET`，不崩溃
- [ ] 在线：打真实仓库跑通端到端解析（与单测分离，不进默认 `ctest` 目标，因会被限流）

---

## 阶段 4：哈希与下载编排

**目标**：`au_hash.c` + `au_download.c`。下载出来的东西一定是对的。

- [ ] `BCryptOpenAlgorithmProvider(BCRYPT_SHA256_ALGORITHM)`，流式喂入，`BCryptFinishHash`
- [ ] `au_download()`：落地到 **exe 所在目录**（不是 `%TEMP%`——跨卷会毁掉阶段 5 的原子性）
- [ ] 下载后校验 SHA-256，不符则删除临时文件返回 `AU_ERR_HASH`，**不重试**
- [ ] `digest` 为 NULL 时跳过校验，但**必须发 `AU_LOG_WARN`**——跳过校验不能静默

**验收**

- [ ] 对已知内容的文件算 SHA-256，与 `certutil -hashfile <f> SHA256` 的输出一致
- [ ] 正常下载 → 校验通过
- [ ] **下载后手工改坏文件再校验 → `AU_ERR_HASH`，且临时文件被删除**
- [ ] `digest` 为 NULL 的 asset → 下载成功且收到一条 WARN 日志
- [ ] 落地路径与 `GetModuleFileNameW` 同盘

---

## 阶段 5：单文件替换

**目标**：`au_apply.c` 的 `AU_MODE_EXE` 路径。第一个不可逆阶段。

- [ ] 安装目录可写性探测（建临时文件再删）→ `AU_ERR_NOT_WRITABLE`。**必须在下载前**
- [ ] `GetModuleFileNameW` 取自身路径
- [ ] `MoveFileExW` 现役 exe → `.old`
- [ ] `MoveFileExW` `.new` → 原路径；**失败则把 `.old` 改回**，返回 `AU_ERR_REPLACE`
- [ ] `CreateProcessW` 启动新版，透传原始命令行参数
- [ ] `ExitProcess(0)`
- [ ] `au_cleanup_after_restart()`：删 `.old`，**幂等**，无残留时是空操作

**验收**（`tests/fixture_v1.c` / `fixture_v2.c`）

- [ ] fixture v1 打印 `v1.0.0`，执行自更新后**新进程打印 `v2.0.0`**
- [ ] 更新后 `.old` 文件已消失
- [ ] `au_cleanup_after_restart()` 连调三次不报错（幂等）
- [ ] 未更新过的全新进程调用它 → 空操作，无副作用
- [ ] 把 fixture 放进不可写目录 → 返回 `AU_ERR_NOT_WRITABLE`，**且未产生任何下载**
- [ ] 命令行参数透传：带参启动 fixture，确认新进程收到同样的参数

**注意**：这个阶段会真的动 exe。在 build 目录的副本上测，别在源码树里跑。

---

## 阶段 6：ZIP 模式

**目标**：`au_apply.c` 的 `AU_MODE_ZIP` 路径。

- [ ] `au_fs.c` 里封装 `tar.exe` 调用：`CreateProcessW` + `CREATE_NO_WINDOW` + `WaitForSingleObject` + `GetExitCodeProcess`
- [ ] 解压到 `<安装目录>\_au_tmp\extract\`
- [ ] **解压产物中校验主 exe 存在**，否则 `AU_ERR_EXTRACT`（防止发错包）
- [ ] 按 design.md §7.2 的步骤顺序覆盖：**全部校验完再动安装目录**
- [ ] `au_cleanup_after_restart()` 扩展为同时清理 `_au_tmp\`

**验收**

- [ ] `tar.exe` 存在性检查（Win10 1803+ 才有，是系统下限的实际约束）
- [ ] 正常 zip → 解压 + 覆盖 + 重启，新版本号正确
- [ ] 损坏的 zip → `AU_ERR_EXTRACT`，**且安装目录未被触碰**
- [ ] 不含主 exe 的 zip → `AU_ERR_EXTRACT`，**且安装目录未被触碰**
- [ ] 含中文文件名的 zip → 解压正确
- [ ] 更新后 `_au_tmp\` 已清理

上面两条「安装目录未被触碰」是这个阶段的重点——它们验证的正是 design.md §7.2 那个刻意的步骤顺序。ZIP 模式无事务性（§9.2）是已接受的限制，但至少要保证**校验期失败不伤及安装目录**。

---

## 阶段 7：GitHub Actions

**目标**：`.github/workflows/release.yml`，打 tag 出包。

- [ ] `on: push: tags: ['v*']`
- [ ] MSVC 构建 `tools.exe` (x64)
- [ ] 打包 `tools-v{VERSION}-win-x64.zip`
- [ ] 创建 Release，上传 `tools-v{VERSION}-x64.exe` 与 `tools-v{VERSION}-win-x64.zip`
- [ ] changelog 写入 Release body
- [ ] **预发布版勾选 Release 的 `prerelease` 标志**——筛选依据是这个标志，不是 tag 里的 `-beta` 字样

**验收**

- [ ] 打 `v0.0.1-test` tag → Release 生成，两个资产都在，`prerelease` 已勾选
- [ ] 用 demo 指向该仓库，stable 通道**看不到**它；beta 通道**能看到**
- [ ] 打 `v0.0.2-test` 正式版 → 两个通道都能看到
- [ ] **降级陷阱实测**：先发 `v0.1.0`，再发 `v0.0.3`，确认检测结果是 `v0.1.0`。这是把阶段 3 的离线断言拿到真实 API 上再验一次

---

## 阶段 8：集成到 tools

- [ ] `tools.exe` 的 `main()` 开头调 `au_cleanup_after_restart()`
- [ ] 启动时检测（失败静默，**绝不阻塞工具本体启动**）
- [ ] `tools.exe update` 子命令走手动更新流程
- [ ] `cfg.current_version` 从构建期宏注入，与 Actions 的 tag 对齐

**验收**

- [ ] 断网启动 → 工具正常可用，无报错噪音
- [ ] 全流程：老版 → 检测 → 显示 changelog → 确认 → 下载带进度 → 替换 → 重启 → 新版本号正确
- [ ] 下载中 Ctrl+C → 干净退出，临时文件已清理

---

## 阶段依赖

```
0 骨架
└─ 1 纯函数 ────────────────┐
   └─ 2 HTTP                │
      └─ 3 GitHub API ──────┤
         └─ 4 哈希与下载    │   （3 依赖 1 的 au_version_cmp）
            └─ 5 单文件替换 │
               ├─ 6 ZIP 模式
               └─ 7 Actions ─── 8 集成
```

阶段 6 与 7 相互独立，可并行。阶段 5 必须在 4 之后——在校验没建立之前做自替换，等于拿工作副本赌下载没出错。

---

## 风险与应对

| 风险 | 应对 |
|---|---|
| SemVer 边界错误 | 严格解析，数字预发布标识符按长度/字节比较，并用规范黄金序列与畸形输入回归 |
| API 限流打断开发 | 在线测试与单测分离。阶段 3 起主要靠 fixture 离线跑；本地开发配一个 PAT |
| 公共加速站跑路 | `cfg.mirrors` 可完全覆盖内置默认值。文档写明这是预期中的腐烂 |
| 自替换测试搞坏工作副本 | fixture 只在 build 目录的副本上跑 |
| MinGW 与 MSVC 行为差异 | 每阶段验收都跑两条工具链，别攒到最后 |
