# 集成示例：托盘常驻程序（含单实例互斥量）

以一个 GUI/托盘常驻、`requireAdministrator`、用命名互斥量做单实例的程序为例，
演示如何接入 winautoupdate。这类程序有两个容易踩的坑，本示例都覆盖：

1. **单实例握手**：自替换是「启动新进程 → 旧进程退出」。若不处理，新进程会在旧进程
   退出前发现互斥量已存在，误判「已在运行」而退出，结果一个实例都不剩。
2. **无 stdout**：进度不能 `printf`，改用托盘气泡 / 日志回调。

选 `AU_MODE_EXE`：便携单文件程序用原子 rename 替换最干净，无半更新状态。

---

## 1. 启动最早期：握手 + 清理（务必早于 CreateMutex）

```c
#include "win_autoupdate.h"
#include <shellapi.h>   /* CommandLineToArgvW */

int WINAPI WinMain(HINSTANCE hInst, HINSTANCE hPrev, LPSTR lpCmd, int nShow) {
    /* WinMain 的 lpCmdLine 是 ANSI，取不到 --au-wait-pid 的宽字符；用 GetCommandLineW。 */
    int argc = 0;
    wchar_t **wargv = CommandLineToArgvW(GetCommandLineW(), &argc);
    if (wargv) {
        au_wait_for_predecessor_w(argc, wargv, 10000);  /* 等旧进程退出，最长 10s */
        LocalFree(wargv);
    }
    au_cleanup_after_restart();  /* 清理上次更新残留的 .old */

    /* ↓↓↓ 现在才创建单实例互斥量：此刻旧进程已退出，不会误判 ↓↓↓ */
    HANDLE mutex = CreateMutexW(NULL, TRUE, L"Local\\myapp_singleton");
    if (GetLastError() == ERROR_ALREADY_EXISTS) { CloseHandle(mutex); return 0; }

    /* ... 正常初始化、消息循环 ... */
}
```

顺序是关键：`au_wait_for_predecessor_w` → `au_cleanup_after_restart` → `CreateMutexW`。

---

## 2. 后台检查（不阻塞消息循环）

GUI 程序不能在主线程同步等网络。开一个工作线程做检查，发现新版只 `PostMessage`
回主线程弹托盘气泡（不打扰）。手动更新（菜单项）才走下载+替换。

```c
typedef struct { HWND hwnd; int manual; au_channel_t channel; } Job;

static void on_log(au_log_level_t lv, const char *msg, void *ud) {
    (void)ud; my_log("[update] %s", msg);   /* 转接到你的日志系统 */
}
static int on_progress(uint64_t total, uint64_t done, void *ud) {
    int *last = ud, pct = total ? (int)(done*100/total) : -1;
    if (pct >= 0 && (pct >= *last + 25 || pct == 100)) { *last = pct; my_log("下载 %d%%", pct); }
    return 0;   /* 返回非 0 可取消 */
}

static DWORD WINAPI worker(void *param) {
    Job *job = param;
    int last = 0;
    au_config_t cfg = {0};
    cfg.owner = "YourName"; cfg.repo = "yourapp";
    cfg.current_version = APP_VERSION_STR;      /* 编译期版本，如 "1.0.8" */
    cfg.asset_pattern = "yourapp-*-x64.exe";
    cfg.mode = AU_MODE_EXE;
    cfg.channel = job->channel;                 /* stable / beta，来自你的配置 */
    cfg.on_log = on_log; cfg.on_progress = on_progress; cfg.userdata = &last;

    au_ctx_t *ctx = au_create(&cfg);
    au_release_t *rel = NULL;
    if (ctx && au_fetch_latest(ctx, &rel) == AU_OK && au_compare_current(ctx, rel) > 0) {
        if (!job->manual) {
            /* 静默检查：只提示，请主线程弹气泡 */
            PostMessageW(job->hwnd, WM_APP_UPDATE_FOUND, 0, 0);
        } else if (confirm_dialog(rel->ver.raw, rel->changelog)) {
            const au_asset_t *a = au_pick_asset(rel, cfg.asset_pattern);
            char path[512];
            if (a && au_download(ctx, a, path, sizeof path) == AU_OK)
                au_apply(ctx, path);            /* 成功不返回：进程已重启 */
        }
    }
    au_release_free(rel);
    au_destroy(ctx);
    free(job);
    return 0;
}

/* 启动时静默检查 / 菜单手动检查，都只是起个线程： */
void spawn_check(HWND hwnd, int manual, au_channel_t ch) {
    Job *job = malloc(sizeof *job);
    *job = (Job){ hwnd, manual, ch };
    HANDLE t = CreateThread(NULL, 0, worker, job, 0, NULL);
    if (t) CloseHandle(t); else free(job);
}
```

---

## 3. 保护用户配置（若用 ZIP 模式）

便携程序的 exe 同目录常有用户改过的配置文件，而发布包里也打了默认配置。用 EXE 模式
只替换 exe 不涉及此问题；若必须用 ZIP 模式，加排除表：

```c
static const char *keep[] = { "config.ini" };
cfg.mode = AU_MODE_ZIP;
cfg.zip_exclude = keep;
cfg.zip_exclude_count = 1;   /* 已存在的 config.ini 不被覆盖 */
```

---

## 4. CMake 接入

vendored 源码方式（把本仓库的 include/ 与 src/ 放进 `third_party/updater/`）：

```cmake
file(GLOB UPD_SRC third_party/updater/src/*.c third_party/updater/src/third_party/*.c)
add_library(updater STATIC ${UPD_SRC})
target_include_directories(updater
  PUBLIC third_party/updater/include PRIVATE third_party/updater/src)
target_link_libraries(updater PUBLIC winhttp bcrypt)

target_link_libraries(yourapp PRIVATE updater)
```

vendored 库会继承你项目的编译设置（静态 CRT、UNICODE 等），保持与主程序一致。

---

## 5. 发布端（GitHub Actions）

打 tag 时产出匹配 `asset_pattern` 的单文件 exe，含连字符的 tag 标记为预发布
（只有 beta 通道用户可见）：

```yaml
- name: Package
  shell: pwsh
  run: |
    $ver = "${{ github.ref_name }}"      # 如 v1.0.9 或 v1.0.9-beta.1
    Copy-Item build/Release/yourapp.exe "yourapp-$ver-x64.exe"
- name: Release
  if: startsWith(github.ref, 'refs/tags/')
  uses: softprops/action-gh-release@v2
  with:
    prerelease: ${{ contains(github.ref_name, '-') }}
    files: yourapp-${{ github.ref_name }}-x64.exe
```
