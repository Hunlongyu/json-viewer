/*
 * au_apply.c — 替换与重启，三种模式；单实例握手；重启后清理。
 *
 * 通过重命名正在运行的 exe 完成替换。两次重命名不构成整体事务。
 * 临时文件必须与 exe 同卷（au_download 已保证）。
 */
#include "au_internal.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <wchar.h>

/* 取本进程的命令行参数（去掉 argv[0]），供重启时透传。返回宽字符串，调用方 free。 */
static wchar_t* forward_args(void) {
    const wchar_t* full = GetCommandLineW();
    /* 跳过 argv[0]：处理带引号的可执行路径。 */
    const wchar_t* p = full;
    if (*p == L'"') { p++; while (*p && *p != L'"') p++; if (*p == L'"') p++; }
    else            { while (*p && *p != L' ' && *p != L'\t') p++; }
    while (*p == L' ' || *p == L'\t') p++;
    return _wcsdup(p);
}

/* 组装带 --au-wait-pid 的命令行并启动 exe。 */
static au_err_t launch_new(au_ctx_t* ctx, const wchar_t* exe_path) {
    wchar_t* args = forward_args();
    if (!args) return AU_ERR_NOMEM;
    DWORD pid = GetCurrentProcessId();

    size_t exe_len = wcslen(exe_path), args_len = wcslen(args);
    if (exe_len > SIZE_MAX - args_len || exe_len + args_len > SIZE_MAX - 64 ||
        exe_len + args_len + 64 > SIZE_MAX / sizeof(wchar_t)) {
        free(args);
        return AU_ERR_NOMEM;
    }
    size_t need = exe_len + args_len + 64;
    wchar_t* cmd = (wchar_t*)malloc(need * sizeof(wchar_t));
    if (!cmd) { free(args); return AU_ERR_NOMEM; }
    /* "exe" --au-wait-pid=<pid> <原参数> */
    swprintf(cmd, need, L"\"%s\" --au-wait-pid=%lu %s", exe_path, pid, args ? args : L"");
    free(args);

    STARTUPINFOW si; memset(&si, 0, sizeof si); si.cb = sizeof si;
    PROCESS_INFORMATION pi; memset(&pi, 0, sizeof pi);
    wchar_t* dir = au_dir_of(exe_path);
    BOOL ok = CreateProcessW(exe_path, cmd, NULL, NULL, FALSE, 0, NULL, dir, &si, &pi);
    DWORD create_err = ok ? ERROR_SUCCESS : GetLastError();
    free(dir); free(cmd);
    if (!ok) { au_logf(ctx, AU_LOG_ERROR, "launch new exe failed: %lu", create_err); return AU_ERR_LAUNCH; }
    CloseHandle(pi.hProcess); CloseHandle(pi.hThread);
    return AU_OK;
}

/* 把 .old 恢复到现役路径。现役路径可能是无法启动的文件、目录或重解析点。 */
static au_err_t rollback_self(au_ctx_t* ctx, const wchar_t* oldp, const wchar_t* self) {
    DWORD attrs = GetFileAttributesW(self);
    if (attrs != INVALID_FILE_ATTRIBUTES) {
        if (au_rmtree(self) != AU_OK) {
            au_logf(ctx, AU_LOG_ERROR, "rollback could not remove invalid active path: %ls", self);
            return AU_ERR_REPLACE;
        }
    }
    if (!MoveFileExW(oldp, self, MOVEFILE_REPLACE_EXISTING)) {
        au_logf(ctx, AU_LOG_ERROR, "rollback .old->self failed: %lu", GetLastError());
        return AU_ERR_REPLACE;
    }
    au_logf(ctx, AU_LOG_WARN, "restored previous executable");
    return AU_OK;
}

static void cleanup_temp(au_ctx_t* ctx, const wchar_t* path) {
    if (au_rmtree(path) != AU_OK)
        au_logf(ctx, AU_LOG_WARN, "temporary directory cleanup failed: %ls", path);
}

/* ---------- 模式 A：单文件替换 ---------- */
static au_err_t apply_exe(au_ctx_t* ctx, const wchar_t* pkg) {
    wchar_t* self = au_self_path();
    if (!self) return AU_ERR_STATE;
    wchar_t* dir = au_dir_of(self);
    if (!dir || !au_dir_writable(dir)) {
        au_logf(ctx, AU_LOG_ERROR, "install dir not writable");
        free(self); free(dir); return AU_ERR_NOT_WRITABLE;
    }

    wchar_t oldp[MAX_PATH];
    int oldn = _snwprintf(oldp, MAX_PATH, L"%s.old", self); oldp[MAX_PATH-1]=L'\0';
    if (oldn < 0 || oldn >= MAX_PATH || au_rmtree(oldp) != AU_OK) {
        free(self); free(dir); return AU_ERR_REPLACE;
    }

    /* 现役 exe → .old */
    if (!MoveFileExW(self, oldp, MOVEFILE_REPLACE_EXISTING)) {
        au_logf(ctx, AU_LOG_ERROR, "rename self→.old failed: %lu", GetLastError());
        free(self); free(dir); return AU_ERR_REPLACE;
    }
    /* 新版 → 原路径 */
    if (!MoveFileExW(pkg, self, MOVEFILE_REPLACE_EXISTING)) {
        DWORD move_err = GetLastError();
        au_logf(ctx, AU_LOG_ERROR, "rename new→self failed: %lu; rolling back", move_err);
        au_err_t rollback = rollback_self(ctx, oldp, self);
        free(self); free(dir);
        return rollback == AU_OK ? AU_ERR_REPLACE : rollback;
    }
    if (!au_regular_file_exists(self)) {
        au_logf(ctx, AU_LOG_ERROR, "replacement package is not a regular file; rolling back");
        au_err_t rollback = rollback_self(ctx, oldp, self);
        free(self); free(dir);
        return rollback == AU_OK ? AU_ERR_REPLACE : rollback;
    }

    au_err_t rc = launch_new(ctx, self);
    if (rc != AU_OK) {
        /* 新版占据了原路径但无法启动时，必须把正在运行的 .old 恢复回去；否则本次
         * 调用虽然报告失败，用户下次启动却只会得到一个不可执行的新版文件。 */
        if (rollback_self(ctx, oldp, self) != AU_OK) rc = AU_ERR_REPLACE;
    }
    free(self); free(dir);
    if (rc != AU_OK) return rc;
    ExitProcess(0);
}

/* ---------- 模式 B：ZIP 完整包 ---------- */
static au_err_t apply_zip(au_ctx_t* ctx, const wchar_t* pkg) {
    wchar_t* self = au_self_path();
    if (!self) return AU_ERR_STATE;
    wchar_t* dir = au_dir_of(self);
    if (!dir || !au_dir_writable(dir)) { free(self); free(dir); return AU_ERR_NOT_WRITABLE; }

    wchar_t tmp[MAX_PATH], extract[MAX_PATH];
    int tn = _snwprintf(tmp, MAX_PATH, L"%s\\_au_tmp", dir); tmp[MAX_PATH-1]=L'\0';
    int en = _snwprintf(extract, MAX_PATH, L"%s\\extract", tmp); extract[MAX_PATH-1]=L'\0';
    if (tn < 0 || tn >= MAX_PATH || en < 0 || en >= MAX_PATH ||
        au_rmtree(tmp) != AU_OK || !CreateDirectoryW(tmp, NULL)) {
        au_logf(ctx, AU_LOG_ERROR, "cannot create clean ZIP staging directory");
        free(self); free(dir); return AU_ERR_EXTRACT;
    }

    /* 先全部解压 + 校验，再动安装目录。 */
    au_err_t rc = au_extract_zip(ctx, pkg, extract);
    if (rc != AU_OK) { cleanup_temp(ctx, tmp); free(self); free(dir); return rc; }

    /* 校验解压产物里有主 exe（basename 与自身一致），防止发错包。 */
    wchar_t* selfname = wcsrchr(self, L'\\');
    selfname = selfname ? selfname + 1 : self;
    wchar_t mainexe[MAX_PATH];
    int mn = _snwprintf(mainexe, MAX_PATH, L"%s\\%s", extract, selfname); mainexe[MAX_PATH-1]=L'\0';
    if (mn < 0 || mn >= MAX_PATH || !au_regular_file_exists(mainexe)) {
        au_logf(ctx, AU_LOG_ERROR, "extracted package missing main exe %ls", selfname);
        cleanup_temp(ctx, tmp); free(self); free(dir); return AU_ERR_EXTRACT;
    }

    /* 现役 exe → .old（释放占用，供覆盖）。 */
    wchar_t oldp[MAX_PATH];
    int oldn = _snwprintf(oldp, MAX_PATH, L"%s.old", self); oldp[MAX_PATH-1]=L'\0';
    if (oldn < 0 || oldn >= MAX_PATH || au_rmtree(oldp) != AU_OK) {
        cleanup_temp(ctx, tmp); free(self); free(dir); return AU_ERR_REPLACE;
    }
    if (!MoveFileExW(self, oldp, MOVEFILE_REPLACE_EXISTING)) {
        cleanup_temp(ctx, tmp); free(self); free(dir); return AU_ERR_REPLACE;
    }

    /* 覆盖复制（zip_exclude 保护的已存在文件跳过）。 */
    rc = au_copy_tree(ctx, extract, dir);
    if (rc != AU_OK) {
        if (rollback_self(ctx, oldp, self) != AU_OK) rc = AU_ERR_REPLACE;
        cleanup_temp(ctx, tmp); free(self); free(dir); return rc;
    }

    rc = launch_new(ctx, self);
    if (rc != AU_OK && rollback_self(ctx, oldp, self) != AU_OK) rc = AU_ERR_REPLACE;
    cleanup_temp(ctx, tmp);
    free(self); free(dir);
    if (rc != AU_OK) return rc;
    ExitProcess(0);
}

/* ---------- 模式 C：安装器 ---------- */
static au_err_t apply_installer(au_ctx_t* ctx, const wchar_t* pkg) {
    if (!au_regular_file_exists(pkg)) return AU_ERR_LAUNCH;
    /* 组装安装器命令行：优先 installer_args，其次按 silent 推断 NSIS "/S"。 */
    const wchar_t* extra = L"";
    wchar_t* extra_owned = NULL;
    if (ctx->installer_args && ctx->installer_args[0]) {
        extra_owned = au_utf8_to_wide(ctx->installer_args);
        if (!extra_owned) return AU_ERR_NOMEM;
        extra = extra_owned;
    } else if (ctx->installer_silent) {
        extra = L"/S";   /* NSIS 静默 */
    }

    size_t pkg_len = wcslen(pkg), extra_len = wcslen(extra);
    if (pkg_len > SIZE_MAX - extra_len || pkg_len + extra_len > SIZE_MAX - 8 ||
        pkg_len + extra_len + 8 > SIZE_MAX / sizeof(wchar_t)) {
        free(extra_owned);
        return AU_ERR_NOMEM;
    }
    size_t need = pkg_len + extra_len + 8;
    wchar_t* cmd = (wchar_t*)malloc(need * sizeof(wchar_t));
    if (!cmd) { free(extra_owned); return AU_ERR_NOMEM; }
    swprintf(cmd, need, L"\"%s\" %s", pkg, extra);

    STARTUPINFOW si; memset(&si, 0, sizeof si); si.cb = sizeof si;
    PROCESS_INFORMATION pi; memset(&pi, 0, sizeof pi);
    /* 安装器通常需要 UAC 提权；用 ShellExecute 语义更稳，但 CreateProcess 在已提权
     * 进程（如 hua）下继承令牌即可。这里用 CreateProcess，失败再由调用方决定。 */
    BOOL ok = CreateProcessW(pkg, cmd, NULL, NULL, FALSE, 0, NULL, NULL, &si, &pi);
    DWORD create_err = ok ? ERROR_SUCCESS : GetLastError();
    free(cmd); free(extra_owned);
    if (!ok) { au_logf(ctx, AU_LOG_ERROR, "launch installer failed: %lu", create_err); return AU_ERR_LAUNCH; }
    CloseHandle(pi.hProcess); CloseHandle(pi.hThread);

    /* 安装器自行完成替换与拉起新版；本进程退出以释放文件占用。 */
    ExitProcess(0);
}

au_err_t au_apply(au_ctx_t* ctx, const char* pkg_path) {
    if (!ctx || !pkg_path || !pkg_path[0]) return AU_ERR_ARG;
    wchar_t* pkg = au_utf8_to_wide(pkg_path);
    if (!pkg) return AU_ERR_NOMEM;
    au_err_t rc;
    switch (ctx->mode) {
        case AU_MODE_EXE:       rc = apply_exe(ctx, pkg); break;
        case AU_MODE_ZIP:       rc = apply_zip(ctx, pkg); break;
        case AU_MODE_INSTALLER: rc = apply_installer(ctx, pkg); break;
        default:                rc = AU_ERR_ARG; break;
    }
    free(pkg);
    return rc;
}

/* ---------- 进程握手 ---------- */

/* 从一个 --au-wait-pid=<n> 参数取 PID，非该参数返回 0。 */
static DWORD parse_wait_pid_w(const wchar_t* arg) {
    const wchar_t* pfx = L"--au-wait-pid=";
    size_t plen = wcslen(pfx);
    const wchar_t* p;
    uint64_t value = 0;
    if (!arg || wcsncmp(arg, pfx, plen) != 0) return 0;
    p = arg + plen;
    if (*p < L'0' || *p > L'9') return 0;
    while (*p >= L'0' && *p <= L'9') {
        unsigned int digit = (unsigned int)(*p - L'0');
        if (value > (UINT32_MAX - digit) / 10U) return 0;
        value = value * 10U + digit;
        p++;
    }
    return *p == L'\0' && value != 0 ? (DWORD)value : 0;
}

static void wait_pid(DWORD pid, int timeout_ms) {
    if (pid == 0) return;
    HANDLE h = OpenProcess(SYNCHRONIZE, FALSE, pid);
    if (!h) return;   /* 已退出或无权限 */
    WaitForSingleObject(h, timeout_ms > 0 ? (DWORD)timeout_ms : 10000);
    CloseHandle(h);
}

void au_wait_for_predecessor_w(int argc, wchar_t** wargv, int timeout_ms) {
    if (!wargv) return;
    for (int i = 1; i < argc; i++) {
        DWORD pid = parse_wait_pid_w(wargv[i]);
        if (pid) { wait_pid(pid, timeout_ms); return; }
    }
}

void au_wait_for_predecessor(int argc, char** argv, int timeout_ms) {
    if (!argv) return;
    for (int i = 1; i < argc; i++) {
        wchar_t* w = au_utf8_to_wide(argv[i]);
        if (!w) continue;
        DWORD pid = parse_wait_pid_w(w);
        free(w);
        if (pid) { wait_pid(pid, timeout_ms); return; }
    }
}

/* ---------- 重启后清理 ---------- */
void au_cleanup_after_restart(void) {
    wchar_t* self = au_self_path();
    if (!self) return;
    wchar_t oldp[MAX_PATH];
    int oldn = _snwprintf(oldp, MAX_PATH, L"%s.old", self); oldp[MAX_PATH-1]=L'\0';
    if (oldn >= 0 && oldn < MAX_PATH && au_file_exists(oldp)) {
        SetFileAttributesW(oldp, FILE_ATTRIBUTE_NORMAL);
        DeleteFileW(oldp);   /* 可能因旧进程尚未完全退出而暂失败；下次启动再试，无害 */
    }
    wchar_t* dir = au_dir_of(self);
    if (dir) {
        wchar_t tmp[MAX_PATH];
        int tmpn = _snwprintf(tmp, MAX_PATH, L"%s\\_au_tmp", dir); tmp[MAX_PATH-1]=L'\0';
        if (tmpn >= 0 && tmpn < MAX_PATH && au_file_exists(tmp)) au_rmtree(tmp);
        free(dir);
    }
    free(self);
}
