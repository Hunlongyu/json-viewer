/*
 * au_download.c — 资产下载编排：镜像轮换、落到 exe 同目录（保证同卷）、SHA-256 校验。
 */
#include "au_internal.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

/* 固定落到现役 exe 旁的 <self>.autmp，避免资产名参与本地路径。 */
static wchar_t* temp_target_path(au_ctx_t* ctx, const au_asset_t* a) {
    (void)ctx; (void)a;
    wchar_t* self = au_self_path();
    if (!self) return NULL;
    size_t need = wcslen(self) + 8;
    wchar_t* path = (wchar_t*)malloc(need * sizeof(wchar_t));
    if (path) swprintf(path, need, L"%s.autmp", self);
    free(self);
    return path;
}

au_err_t au_download(au_ctx_t* ctx, const au_asset_t* a, char* out_path, size_t cap) {
    if (!out_path || cap == 0) return AU_ERR_ARG;
    out_path[0] = '\0';
    if (!ctx || !a || !a->url || !a->url[0]) return AU_ERR_ARG;

    int has_digest = a->sha256 != NULL;
    int verified = has_digest && au_sha256_hex_valid(a->sha256);
    if (has_digest && !verified) {
        au_logf(ctx, AU_LOG_ERROR, "asset has malformed SHA-256 digest");
        return AU_ERR_HASH;
    }

    wchar_t* target = temp_target_path(ctx, a);
    if (!target) return AU_ERR_NOMEM;
    if (au_rmtree(target) != AU_OK) { free(target); return AU_ERR_IO; }

    size_t nmir = 0;
    wchar_t** urls;
    if (verified) {
        urls = au_build_mirror_urls(ctx, a->url, &nmir);
    } else {
        urls = (wchar_t**)calloc(1, sizeof *urls);
        if (urls) {
            urls[0] = au_utf8_to_wide(a->url);
            if (urls[0]) nmir = 1;
        }
        au_logf(ctx, AU_LOG_WARN,
                "asset has no digest; using direct HTTPS only and skipping SHA-256 verification");
    }
    if (!urls || nmir == 0) { free(urls); free(target); return AU_ERR_NOMEM; }

    au_err_t rc = AU_ERR_NET;
    for (size_t i = 0; i < nmir && rc != AU_OK && rc != AU_ERR_CANCELED &&
         rc != AU_ERR_ARG && rc != AU_ERR_NOMEM; i++) {
        if (!urls[i]) continue;
        for (int attempt = 0; attempt <= ctx->retry_max; attempt++) {
            if (au_is_canceled(ctx)) { rc = AU_ERR_CANCELED; break; }

            HANDLE hFile = CreateFileW(target, GENERIC_WRITE, 0, NULL,
                                       CREATE_NEW, FILE_ATTRIBUTE_NORMAL, NULL);
            if (hFile == INVALID_HANDLE_VALUE) { rc = AU_ERR_IO; break; }

            au_http_meta meta;
            rc = au_http_get_file(ctx, urls[i], hFile, &meta);
            CloseHandle(hFile);

            if (rc == AU_OK) break;
            if (rc == AU_ERR_CANCELED || rc == AU_ERR_ARG || rc == AU_ERR_NOMEM) break;
            au_rmtree(target);   /* 失败即清残片，下一轮重下 */
            au_logf(ctx, AU_LOG_WARN, "download attempt failed (mirror %zu, try %d): %s",
                    i, attempt, au_strerror(rc));
        }
    }

    if (rc != AU_OK) {
        au_rmtree(target);
        free(target);
        for (size_t i = 0; i < nmir; i++) free(urls[i]);
        free(urls);
        return rc;
    }

    if (!au_regular_file_exists(target)) {
        au_rmtree(target);
        free(target);
        for (size_t i = 0; i < nmir; i++) free(urls[i]);
        free(urls);
        return AU_ERR_IO;
    }

    /* SHA-256 校验。 */
    if (verified) {
        char got[65];
        au_err_t hr = au_sha256_file(target, got);
        if (hr != AU_OK) { rc = hr; }
        else if (_stricmp(got, a->sha256) != 0) {
            au_logf(ctx, AU_LOG_ERROR, "SHA-256 mismatch: got %s want %s", got, a->sha256);
            rc = AU_ERR_HASH;
        }
        if (rc != AU_OK) {
            au_rmtree(target);
            free(target);
            for (size_t i = 0; i < nmir; i++) free(urls[i]);
            free(urls);
            return rc;
        }
    }

    /* 回填 UTF-8 路径。 */
    char* u8 = au_wide_to_utf8(target);
    if (!u8 || strlen(u8) + 1 > cap) {
        free(u8); au_rmtree(target); free(target);
        for (size_t i = 0; i < nmir; i++) free(urls[i]);
        free(urls);
        return AU_ERR_ARG;   /* 缓冲不够 */
    }
    memcpy(out_path, u8, strlen(u8) + 1);
    free(u8);

    free(target);
    for (size_t i = 0; i < nmir; i++) free(urls[i]);
    free(urls);
    return AU_OK;
}
