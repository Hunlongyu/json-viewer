/*
 * au_fs.c — 文件系统操作：自身路径、目录可写探测、tar.exe 解压、
 * 带排除表的目录树复制、递归删除。
 */
#include "au_internal.h"
#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <wchar.h>

wchar_t* au_self_path(void) {
    DWORD cap = 512;
    for (;;) {
        wchar_t* buf = (wchar_t*)malloc(cap * sizeof(wchar_t));
        if (!buf) return NULL;
        DWORD n = GetModuleFileNameW(NULL, buf, cap);
        if (n == 0) { free(buf); return NULL; }
        if (n < cap) return buf;           /* 完整写入 */
        free(buf); cap *= 2;               /* 截断，扩容重试 */
        if (cap > 1u << 16) return NULL;
    }
}

wchar_t* au_dir_of(const wchar_t* path) {
    if (!path) return NULL;
    wchar_t* copy = _wcsdup(path);
    if (!copy) return NULL;
    wchar_t* slash = wcsrchr(copy, L'\\');
    wchar_t* fslash = wcsrchr(copy, L'/');
    if (fslash && (!slash || fslash > slash)) slash = fslash;
    if (slash) *slash = L'\0';
    else { free(copy); return _wcsdup(L"."); }
    return copy;
}

int au_file_exists(const wchar_t* path) {
    if (!path) return 0;
    DWORD a = GetFileAttributesW(path);
    return a != INVALID_FILE_ATTRIBUTES;
}

int au_regular_file_exists(const wchar_t* path) {
    if (!path) return 0;
    DWORD a = GetFileAttributesW(path);
    return a != INVALID_FILE_ATTRIBUTES &&
           !(a & FILE_ATTRIBUTE_DIRECTORY) &&
           !(a & FILE_ATTRIBUTE_REPARSE_POINT);
}

int au_dir_writable(const wchar_t* dir) {
    if (!dir || !dir[0]) return 0;
    wchar_t probe[MAX_PATH];
    /* PID + tick 降低残留探针碰撞；CREATE_NEW 保证不跟随预置重解析点。 */
    int n = _snwprintf(probe, MAX_PATH, L"%s\\.au_wtest_%lu_%llu", dir,
                       GetCurrentProcessId(), (unsigned long long)GetTickCount64());
    probe[MAX_PATH-1] = L'\0';
    if (n < 0 || n >= MAX_PATH) return 0;
    HANDLE h = CreateFileW(probe, GENERIC_WRITE, 0, NULL,
                           CREATE_NEW, FILE_ATTRIBUTE_TEMPORARY | FILE_FLAG_DELETE_ON_CLOSE, NULL);
    if (h == INVALID_HANDLE_VALUE) return 0;
    CloseHandle(h);   /* DELETE_ON_CLOSE 自动清理 */
    return 1;
}

/* 找系统 tar.exe 全路径（%SystemRoot%\System32\tar.exe），避免 PATH 劫持。 */
static int system_tar_path(wchar_t* out, size_t cap) {
    UINT n = GetSystemDirectoryW(out, (UINT)cap);
    if (n == 0 || n >= cap) return 0;
    if (wcscat_s(out, cap, L"\\tar.exe") != 0) return 0;
    return au_regular_file_exists(out);
}

au_err_t au_extract_zip(au_ctx_t* ctx, const wchar_t* zip, const wchar_t* dest_dir) {
    wchar_t tar[MAX_PATH];
    if (!ctx || !zip || !dest_dir || !au_regular_file_exists(zip)) return AU_ERR_EXTRACT;
    if (!system_tar_path(tar, MAX_PATH)) {
        au_logf(ctx, AU_LOG_ERROR, "system tar.exe not found (need Win10 1803+)");
        return AU_ERR_EXTRACT;
    }
    if (!CreateDirectoryW(dest_dir, NULL)) {
        au_logf(ctx, AU_LOG_ERROR, "create fresh extract directory failed: %ls (%lu)",
                dest_dir, GetLastError());
        return AU_ERR_EXTRACT;
    }

    /* 命令行：tar.exe -xf "zip" -C "dest"。手工加引号防空格。 */
    size_t tar_len = wcslen(tar), zip_len = wcslen(zip), dest_len = wcslen(dest_dir);
    if (tar_len > SIZE_MAX - zip_len) {
        au_rmtree(dest_dir);
        return AU_ERR_NOMEM;
    }
    size_t cmd_chars = tar_len + zip_len;
    if (cmd_chars > SIZE_MAX - dest_len) { au_rmtree(dest_dir); return AU_ERR_NOMEM; }
    cmd_chars += dest_len;
    if (cmd_chars > SIZE_MAX - 32) { au_rmtree(dest_dir); return AU_ERR_NOMEM; }
    cmd_chars += 32;
    if (cmd_chars > SIZE_MAX / sizeof(wchar_t)) {
        au_rmtree(dest_dir);
        return AU_ERR_NOMEM;
    }
    wchar_t* cmd = (wchar_t*)malloc(cmd_chars * sizeof(wchar_t));
    if (!cmd) { au_rmtree(dest_dir); return AU_ERR_NOMEM; }
    if (swprintf(cmd, cmd_chars, L"\"%s\" -xf \"%s\" -C \"%s\"",
                 tar, zip, dest_dir) < 0) {
        free(cmd); au_rmtree(dest_dir); return AU_ERR_EXTRACT;
    }

    STARTUPINFOW si; memset(&si, 0, sizeof si); si.cb = sizeof si;
    PROCESS_INFORMATION pi; memset(&pi, 0, sizeof pi);
    BOOL ok = CreateProcessW(NULL, cmd, NULL, NULL, FALSE,
                             CREATE_NO_WINDOW, NULL, NULL, &si, &pi);
    DWORD create_err = ok ? ERROR_SUCCESS : GetLastError();
    free(cmd);
    if (!ok) {
        au_logf(ctx, AU_LOG_ERROR, "CreateProcess tar failed: %lu", create_err);
        au_rmtree(dest_dir);
        return AU_ERR_EXTRACT;
    }

    DWORD wait_rc = WaitForSingleObject(pi.hProcess,
                                        ctx->timeout_ms > 0 ? (DWORD)ctx->timeout_ms : 30000);
    if (wait_rc == WAIT_TIMEOUT) {
        TerminateProcess(pi.hProcess, 1);
        WaitForSingleObject(pi.hProcess, 5000);
    }
    DWORD code = 1;
    BOOL got_code = wait_rc == WAIT_OBJECT_0 && GetExitCodeProcess(pi.hProcess, &code);
    CloseHandle(pi.hProcess); CloseHandle(pi.hThread);
    if (!got_code || code != 0) {
        au_logf(ctx, AU_LOG_ERROR, "tar failed (wait=%lu, exit=%lu)", wait_rc, code);
        au_rmtree(dest_dir);
        return AU_ERR_EXTRACT;
    }
    return AU_OK;
}

/* basename 是否命中排除表（大小写不敏感）。 */
static int is_excluded(au_ctx_t* ctx, const wchar_t* name) {
    for (size_t i = 0; i < ctx->zip_exclude_count; i++)
        if (_wcsicmp(name, ctx->zip_exclude[i]) == 0) return 1;
    return 0;
}

au_err_t au_copy_tree(au_ctx_t* ctx, const wchar_t* src_dir, const wchar_t* dst_dir) {
    if (!ctx || !src_dir || !dst_dir) return AU_ERR_ARG;
    DWORD src_attrs = GetFileAttributesW(src_dir);
    if (src_attrs == INVALID_FILE_ATTRIBUTES || !(src_attrs & FILE_ATTRIBUTE_DIRECTORY) ||
        (src_attrs & FILE_ATTRIBUTE_REPARSE_POINT)) {
        au_logf(ctx, AU_LOG_ERROR, "invalid source directory: %ls", src_dir);
        return AU_ERR_REPLACE;
    }

    if (!CreateDirectoryW(dst_dir, NULL)) {
        DWORD err = GetLastError();
        DWORD attrs = GetFileAttributesW(dst_dir);
        if (err != ERROR_ALREADY_EXISTS || attrs == INVALID_FILE_ATTRIBUTES ||
            !(attrs & FILE_ATTRIBUTE_DIRECTORY) || (attrs & FILE_ATTRIBUTE_REPARSE_POINT)) {
            au_logf(ctx, AU_LOG_ERROR, "create destination directory failed: %ls (%lu)", dst_dir, err);
            return AU_ERR_REPLACE;
        }
    }

    wchar_t pattern[MAX_PATH];
    int pn = _snwprintf(pattern, MAX_PATH, L"%s\\*", src_dir);
    pattern[MAX_PATH-1] = L'\0';
    if (pn < 0 || pn >= MAX_PATH) {
        au_logf(ctx, AU_LOG_ERROR, "source path too long: %ls", src_dir);
        return AU_ERR_REPLACE;
    }

    WIN32_FIND_DATAW fd;
    HANDLE h = FindFirstFileW(pattern, &fd);
    if (h == INVALID_HANDLE_VALUE) {
        DWORD err = GetLastError();
        if (err == ERROR_FILE_NOT_FOUND) return AU_OK;   /* 已存在但为空的目录 */
        au_logf(ctx, AU_LOG_ERROR, "enumerate source directory failed: %ls (%lu)", src_dir, err);
        return AU_ERR_REPLACE;
    }

    au_err_t rc = AU_OK;
    for (;;) {
        if (wcscmp(fd.cFileName, L".") != 0 && wcscmp(fd.cFileName, L"..") != 0) {
            wchar_t sp[MAX_PATH], dp[MAX_PATH];
            int sn = _snwprintf(sp, MAX_PATH, L"%s\\%s", src_dir, fd.cFileName);
            int dn = _snwprintf(dp, MAX_PATH, L"%s\\%s", dst_dir, fd.cFileName);
            sp[MAX_PATH-1]=L'\0'; dp[MAX_PATH-1]=L'\0';
            if (sn < 0 || sn >= MAX_PATH || dn < 0 || dn >= MAX_PATH) {
                au_logf(ctx, AU_LOG_ERROR, "copy path too long under: %ls", src_dir);
                rc = AU_ERR_REPLACE;
                break;
            }

            if (fd.dwFileAttributes & FILE_ATTRIBUTE_REPARSE_POINT) {
                au_logf(ctx, AU_LOG_ERROR, "reparse point rejected in package: %ls", sp);
                rc = AU_ERR_REPLACE;
            } else if (fd.dwFileAttributes & FILE_ATTRIBUTE_DIRECTORY) {
                rc = au_copy_tree(ctx, sp, dp);
            } else {
                /* 排除表：仅当目标已存在时跳过（保护用户配置）。 */
                DWORD dst_attrs = GetFileAttributesW(dp);
                if (dst_attrs != INVALID_FILE_ATTRIBUTES &&
                    (dst_attrs & FILE_ATTRIBUTE_REPARSE_POINT)) {
                    au_logf(ctx, AU_LOG_ERROR, "destination reparse point rejected: %ls", dp);
                    rc = AU_ERR_REPLACE;
                } else if (is_excluded(ctx, fd.cFileName) && dst_attrs != INVALID_FILE_ATTRIBUTES) {
                    au_logf(ctx, AU_LOG_INFO, "skip existing (excluded): %ls", fd.cFileName);
                } else if (!CopyFileW(sp, dp, FALSE)) {
                    au_logf(ctx, AU_LOG_ERROR, "copy failed: %ls (%lu)", fd.cFileName, GetLastError());
                    rc = AU_ERR_REPLACE;
                }
            }
            if (rc != AU_OK) break;
        }

        if (!FindNextFileW(h, &fd)) {
            DWORD err = GetLastError();
            if (err != ERROR_NO_MORE_FILES) {
                au_logf(ctx, AU_LOG_ERROR, "continue directory enumeration failed: %ls (%lu)", src_dir, err);
                rc = AU_ERR_REPLACE;
            }
            break;
        }
    }
    FindClose(h);
    return rc;
}

au_err_t au_rmtree(const wchar_t* dir) {
    if (!dir || !dir[0]) return AU_ERR_ARG;
    DWORD root_attrs = GetFileAttributesW(dir);
    if (root_attrs == INVALID_FILE_ATTRIBUTES) {
        DWORD err = GetLastError();
        return (err == ERROR_FILE_NOT_FOUND || err == ERROR_PATH_NOT_FOUND) ? AU_OK : AU_ERR_IO;
    }
    /* junction / 目录符号链接只删除链接本身，绝不遍历其目标。 */
    if (root_attrs & FILE_ATTRIBUTE_REPARSE_POINT) {
        BOOL ok = (root_attrs & FILE_ATTRIBUTE_DIRECTORY) ? RemoveDirectoryW(dir) : DeleteFileW(dir);
        return ok ? AU_OK : AU_ERR_IO;
    }
    if (!(root_attrs & FILE_ATTRIBUTE_DIRECTORY)) {
        if ((root_attrs & FILE_ATTRIBUTE_READONLY) &&
            !SetFileAttributesW(dir, root_attrs & ~FILE_ATTRIBUTE_READONLY))
            return AU_ERR_IO;
        return DeleteFileW(dir) ? AU_OK : AU_ERR_IO;
    }

    wchar_t pattern[MAX_PATH];
    int pn = _snwprintf(pattern, MAX_PATH, L"%s\\*", dir); pattern[MAX_PATH-1]=L'\0';
    if (pn < 0 || pn >= MAX_PATH) return AU_ERR_IO;
    WIN32_FIND_DATAW fd;
    HANDLE h = FindFirstFileW(pattern, &fd);
    if (h == INVALID_HANDLE_VALUE) {
        DWORD err = GetLastError();
        if (err != ERROR_FILE_NOT_FOUND) return AU_ERR_IO;
    } else {
        au_err_t rc = AU_OK;
        do {
            if (wcscmp(fd.cFileName, L".") == 0 || wcscmp(fd.cFileName, L"..") == 0) continue;
            wchar_t p[MAX_PATH];
            int n = _snwprintf(p, MAX_PATH, L"%s\\%s", dir, fd.cFileName); p[MAX_PATH-1]=L'\0';
            if (n < 0 || n >= MAX_PATH || au_rmtree(p) != AU_OK) { rc = AU_ERR_IO; break; }
        } while (FindNextFileW(h, &fd));
        if (rc == AU_OK && GetLastError() != ERROR_NO_MORE_FILES) rc = AU_ERR_IO;
        FindClose(h);
        if (rc != AU_OK) return rc;
    }
    if ((root_attrs & FILE_ATTRIBUTE_READONLY) &&
        !SetFileAttributesW(dir, root_attrs & ~FILE_ATTRIBUTE_READONLY))
        return AU_ERR_IO;
    return RemoveDirectoryW(dir) ? AU_OK : AU_ERR_IO;
}
