/*
 * au_gh.c — GitHub API 层。拉 /releases，cJSON 解析，通道筛选，
 * 按版本号排序取最大（防 created_at 排序导致的降级）。
 */
#include "au_internal.h"
#include "third_party/cJSON.h"
#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <limits.h>

/* 返回 1=成功，0=记录非法，-1=内存不足。 */
static int parse_release(const cJSON* jr, au_release_t* out) {
    memset(out, 0, sizeof *out);

    const cJSON* tag = cJSON_GetObjectItemCaseSensitive(jr, "tag_name");
    if (!cJSON_IsString(tag) || !tag->valuestring) return 0;
    if (au_version_parse(tag->valuestring, &out->ver) != AU_OK) return 0;  /* 非法 tag 跳过 */

    const cJSON* pre = cJSON_GetObjectItemCaseSensitive(jr, "prerelease");
    out->is_prerelease = cJSON_IsTrue(pre) ? 1 : 0;

    const cJSON* body = cJSON_GetObjectItemCaseSensitive(jr, "body");
    if (cJSON_IsString(body) && body->valuestring) {
        out->changelog = au_strdup(body->valuestring);   /* cJSON 已反转义 */
        if (!out->changelog) return -1;
    }

    const cJSON* assets = cJSON_GetObjectItemCaseSensitive(jr, "assets");
    int acount = cJSON_IsArray(assets) ? cJSON_GetArraySize(assets) : 0;
    if (acount > 0) {
        out->assets = (au_asset_t*)calloc((size_t)acount, sizeof(au_asset_t));
        if (!out->assets) return -1;
        int idx = 0;
        const cJSON* ja;
        cJSON_ArrayForEach(ja, assets) {
            const cJSON* an = cJSON_GetObjectItemCaseSensitive(ja, "name");
            const cJSON* au = cJSON_GetObjectItemCaseSensitive(ja, "browser_download_url");
            const cJSON* asz = cJSON_GetObjectItemCaseSensitive(ja, "size");
            const cJSON* adg = cJSON_GetObjectItemCaseSensitive(ja, "digest");
            if (!cJSON_IsString(an) || !an->valuestring ||
                !cJSON_IsString(au) || !au->valuestring) continue;
            au_asset_t* a = &out->assets[idx];
            memset(a, 0, sizeof *a);
            /* 先纳入释放范围，后续任一分配失败都不会泄漏半构造资产。 */
            out->asset_count = (size_t)idx + 1;
            a->name = au_strdup(an->valuestring);
            a->url  = au_strdup(au->valuestring);
            if (!a->name || !a->url) return -1;
            if (cJSON_IsNumber(asz) && isfinite(asz->valuedouble) &&
                asz->valuedouble >= 0.0 &&
                asz->valuedouble < 18446744073709551616.0 &&
                floor(asz->valuedouble) == asz->valuedouble)
                a->size = (uint64_t)asz->valuedouble;
            if (cJSON_IsString(adg) && adg->valuestring) {
                /* 形如 "sha256:abc..."，剥前缀。 */
                const char* p = strchr(adg->valuestring, ':');
                a->sha256 = au_strdup(p ? p + 1 : adg->valuestring);
                if (!a->sha256) return -1;
            }
            idx++;
        }
        out->asset_count = (size_t)idx;
    }
    return 1;
}

/* 单个 release 的深释放（内部用；顶层 au_release_free 复用）。 */
static void free_release_contents(au_release_t* r) {
    if (!r) return;
    free(r->changelog);
#ifdef _MSC_VER
#pragma warning(push)
    /* 公开释放函数的契约要求传入本库返回的对象；这些字段均由 calloc/memset 初始化。
     * /analyze 无法跨该所有权边界证明此不变量。 */
#pragma warning(disable: 6001)
#endif
    for (size_t i = 0; i < r->asset_count; i++) {
        free(r->assets[i].name);
        free(r->assets[i].url);
        free(r->assets[i].sha256);
    }
#ifdef _MSC_VER
#pragma warning(pop)
#endif
    free(r->assets);
    memset(r, 0, sizeof *r);
}

void au_release_free(au_release_t* rel) {
    if (!rel) return;
    free_release_contents(rel);
    free(rel);
}

/* 元数据只从 GitHub HTTPS 直连获取；页码由本地推进，不访问 Link 中的任意 URL。 */
static au_err_t fetch_api_json(au_ctx_t* ctx, unsigned page, char** out, size_t* len,
                                int* has_next_page) {
    *out = NULL; *len = 0; *has_next_page = 0;
    static const char prefix[] = "https://api.github.com/repos/";
    char suffix[64];
    int suffix_len = snprintf(suffix, sizeof suffix, "/releases?per_page=100&page=%u", page);
    if (suffix_len < 0 || (size_t)suffix_len >= sizeof suffix) return AU_ERR_ARG;
    size_t owner_len = strlen(ctx->owner), repo_len = strlen(ctx->repo);
    if (owner_len > SIZE_MAX - repo_len) return AU_ERR_NOMEM;
    size_t need = owner_len + repo_len;
    if (need > SIZE_MAX - sizeof prefix) return AU_ERR_NOMEM;
    need += sizeof prefix;
    if (need > SIZE_MAX - sizeof suffix - 1) return AU_ERR_NOMEM;
    need += sizeof suffix + 1;
    char* raw = (char*)malloc(need);
    if (!raw) return AU_ERR_NOMEM;
    int written = snprintf(raw, need, "%s%s/%s%s", prefix, ctx->owner, ctx->repo, suffix);
    if (written < 0 || (size_t)written >= need) { free(raw); return AU_ERR_ARG; }
    wchar_t* url = au_utf8_to_wide(raw);
    free(raw);
    if (!url) return AU_ERR_NOMEM;

    au_err_t rc = AU_ERR_NET;
    for (int attempt = 0; attempt <= ctx->retry_max; attempt++) {
        if (au_is_canceled(ctx)) { rc = AU_ERR_CANCELED; break; }
        au_http_meta meta;
        rc = au_http_get_mem(ctx, url, out, len, &meta);
        if (rc == AU_OK) { *has_next_page = meta.has_next_page; break; }
        if (rc == AU_ERR_CANCELED || rc == AU_ERR_ARG || rc == AU_ERR_NOMEM) break;
        if (rc == AU_ERR_RATELIMIT) {
            au_logf(ctx, AU_LOG_ERROR, "GitHub API rate limited");
            break;
        }
        au_logf(ctx, AU_LOG_WARN, "direct API attempt failed (try %d): %s",
                attempt, au_strerror(rc));
    }
    free(url);
    return rc;
}

/* 空页、全为草稿/预发布的页也是有效页面；跨页选择时必须继续。 */
static au_err_t select_page(au_ctx_t* ctx, const char* json, size_t len,
                            au_release_t** out, int* count) {
    if (!ctx || !json || !out) return AU_ERR_ARG;
    *out = NULL;

    cJSON* root = cJSON_ParseWithLength(json, len);
    if (!root || !cJSON_IsArray(root)) { cJSON_Delete(root); return AU_ERR_PARSE; }
    if (count) *count = cJSON_GetArraySize(root);

    au_release_t best; int have_best = 0;
    memset(&best, 0, sizeof best);

    const cJSON* jr;
    cJSON_ArrayForEach(jr, root) {
        /* draft 无条件剔除。 */
        const cJSON* draft = cJSON_GetObjectItemCaseSensitive(jr, "draft");
        if (cJSON_IsTrue(draft)) continue;

        au_release_t cand;
        int parsed = parse_release(jr, &cand);
        if (parsed < 0) {
            free_release_contents(&cand);
            free_release_contents(&best);
            cJSON_Delete(root);
            return AU_ERR_NOMEM;
        }
        if (!parsed) { free_release_contents(&cand); continue; }

        /* stable 通道剔除预发布版。 */
        if (ctx->channel == AU_CHANNEL_STABLE && cand.is_prerelease) {
            free_release_contents(&cand);
            continue;
        }

        /* 按版本号取最大（不能取列表首项——GitHub 按 created_at 排序）。 */
        if (!have_best || au_version_cmp(&cand.ver, &best.ver) > 0) {
            free_release_contents(&best);
            best = cand;          /* 移交所有权 */
            have_best = 1;
        } else {
            free_release_contents(&cand);
        }
    }
    cJSON_Delete(root);

    if (!have_best) return AU_OK;

    au_release_t* heap = (au_release_t*)malloc(sizeof *heap);
    if (!heap) { free_release_contents(&best); return AU_ERR_NOMEM; }
    *heap = best;
    *out = heap;
    return AU_OK;
}

au_err_t au_select_best_from_json(au_ctx_t* ctx, const char* json, size_t len,
                                  au_release_t** out) {
    au_err_t rc = select_page(ctx, json, len, out, NULL);
    return rc == AU_OK && !*out ? AU_ERR_PARSE : rc;
}

au_err_t au_fetch_latest(au_ctx_t* ctx, au_release_t** out) {
    if (!ctx || !out) return AU_ERR_ARG;
    *out = NULL;

    au_release_t* best = NULL;
    for (unsigned page = 1; ; page++) {
        char* json = NULL; size_t jlen = 0;
        int has_next = 0, count = 0;
        au_release_t* candidate = NULL;
        au_err_t rc = fetch_api_json(ctx, page, &json, &jlen, &has_next);
        /* 只有首次请求限流才允许切换语义；后续分页失败不能伪装成完整结果。 */
        if (rc == AU_ERR_RATELIMIT && page == 1) {
            au_logf(ctx, AU_LOG_WARN, "REST API rate limited; falling back to web endpoint");
            free(json);
            rc = au_fetch_web_fallback(ctx, out);
            if (rc == AU_OK && au_is_canceled(ctx)) {
                au_release_free(*out); *out = NULL;
                return AU_ERR_CANCELED;
            }
            return rc;
        }
        if (rc == AU_OK) rc = select_page(ctx, json, jlen, &candidate, &count);
        free(json);
        if (rc == AU_OK && au_is_canceled(ctx)) rc = AU_ERR_CANCELED;
        if (rc != AU_OK) {
            au_release_free(candidate); au_release_free(best);
            return rc;
        }
        if (candidate && (!best || au_version_cmp(&candidate->ver, &best->ver) > 0)) {
            au_release_free(best);
            best = candidate;
        } else {
            au_release_free(candidate);
        }
        /* 满页时额外读取下一页，即使 Link 缺失也不遗漏后续版本。 */
        if (!has_next && count < 100) break;
        if (page == UINT_MAX) { au_release_free(best); return AU_ERR_PARSE; }
    }
    if (!best) {
        au_logf(ctx, AU_LOG_WARN, "no usable release in channel");
        return AU_ERR_PARSE;
    }
    *out = best;
    return AU_OK;
}

int au_compare_current(au_ctx_t* ctx, const au_release_t* rel) {
    if (!ctx || !rel) return 0;
    return au_version_cmp(&rel->ver, &ctx->current);
}

const au_asset_t* au_pick_asset(const au_release_t* rel, const char* pattern) {
    if (!rel || !pattern) return NULL;
    const au_asset_t* hit = NULL;
    for (size_t i = 0; i < rel->asset_count; i++) {
        if (rel->assets[i].name && au_glob_match(pattern, rel->assets[i].name)) {
            if (hit) return NULL;      /* 多重匹配：宁可返回 NULL 也不猜 */
            hit = &rel->assets[i];
        }
    }
    return hit;
}
