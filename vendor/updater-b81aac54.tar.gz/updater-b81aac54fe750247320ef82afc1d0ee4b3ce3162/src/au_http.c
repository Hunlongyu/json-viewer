/*
 * au_http.c — WinHTTP 封装。HTTPS GET 到内存或文件，进度回调，取消，
 * 请求头，限流头解析。TLS 与证书链校验由 WinHTTP 内部完成。
 */
#include "au_internal.h"
#include <winhttp.h>
#include <stdio.h>
#include <string.h>
#include <wchar.h>
#include <stdlib.h>

/* 认证边界按实际 URL 判断，不因请求来自 API 层就信任镜像。 */
static int crack_origin(const wchar_t* url, URL_COMPONENTS* uc, wchar_t host[256]) {
    memset(uc, 0, sizeof *uc);
    uc->dwStructSize = sizeof *uc;
    uc->lpszHostName = host;
    uc->dwHostNameLength = 256;
    uc->dwUserNameLength = (DWORD)-1;
    uc->dwPasswordLength = (DWORD)-1;
    return url && WinHttpCrackUrl(url, 0, 0, uc) &&
           (uc->nScheme == INTERNET_SCHEME_HTTP || uc->nScheme == INTERNET_SCHEME_HTTPS) &&
           uc->dwUserNameLength == 0 && uc->dwPasswordLength == 0;
}

int au_http_auth_allowed(const wchar_t* url) {
    URL_COMPONENTS uc;
    wchar_t host[256] = {0};
    return crack_origin(url, &uc, host) && uc.nScheme == INTERNET_SCHEME_HTTPS &&
           uc.nPort == INTERNET_DEFAULT_HTTPS_PORT &&
           _wcsicmp(host, L"api.github.com") == 0;
}

/* size_t 加法溢出保护。 */
static int add_size(size_t* total, size_t amount) {
    if (amount > SIZE_MAX - *total) return 0;
    *total += amount;
    return 1;
}

static void append_piece(char** dst, const char* src) {
    size_t n = strlen(src);
    memcpy(*dst, src, n);
    *dst += n;
}

/* 把 UTF-8 headers 拼进请求。GitHub 强制要求 User-Agent。
 * token 只发给直连 api.github.com：镜像模板可能指向任意第三方，不能把凭据交给它。 */
au_err_t au_http_build_headers(au_ctx_t* ctx, const wchar_t* url, int is_api,
                               int allow_auth, wchar_t** out) {
    if (!ctx || !url || !out) return AU_ERR_ARG;
    *out = NULL;

    static const char UA_PREFIX[] = "User-Agent: ";
    static const char API_HEADERS[] =
        "Accept: application/vnd.github+json\r\n"
        "X-GitHub-Api-Version: 2022-11-28\r\n";
    static const char AUTH_PREFIX[] = "Authorization: Bearer ";
    static const char CRLF[] = "\r\n";

    const char* ua = ctx->user_agent ? ctx->user_agent : "WinAutoUpdate/1.0";
    if (strpbrk(ua, "\r\n") || (ctx->token && strpbrk(ctx->token, "\r\n")))
        return AU_ERR_ARG;
    int send_token = is_api && allow_auth && ctx->token && ctx->token[0] &&
                     au_http_auth_allowed(url);

    size_t need = 1; /* NUL */
    if (!add_size(&need, strlen(UA_PREFIX)) ||
        !add_size(&need, strlen(ua)) ||
        !add_size(&need, strlen(CRLF)) ||
        (is_api && !add_size(&need, strlen(API_HEADERS))) ||
        (send_token && (!add_size(&need, strlen(AUTH_PREFIX)) ||
                        !add_size(&need, strlen(ctx->token)) ||
                        !add_size(&need, strlen(CRLF)))))
        return AU_ERR_NOMEM;

    char* tmp = (char*)malloc(need);
    if (!tmp) return AU_ERR_NOMEM;
    char* p = tmp;
    append_piece(&p, UA_PREFIX);
    append_piece(&p, ua);
    append_piece(&p, CRLF);
    if (is_api) append_piece(&p, API_HEADERS);
    if (send_token) {
        append_piece(&p, AUTH_PREFIX);
        append_piece(&p, ctx->token);
        append_piece(&p, CRLF);
    }
    *p = '\0';

    wchar_t* result = au_utf8_to_wide(tmp);
    free(tmp);
    *out = result;
    return result ? AU_OK : AU_ERR_NOMEM;
}

/* 只规范化路径中的 . / .. 段，查询字符串与百分号编码保持原样。 */
static void normalize_redirect_path(wchar_t* url) {
    wchar_t* scheme = wcsstr(url, L"://");
    if (!scheme) return;
    wchar_t* path = scheme + 3;
    path += wcscspn(path, L"/?");
    if (*path != L'/') return;
    wchar_t* end = path + wcscspn(path, L"?");
    wchar_t *input = path, *output = path;
    while (input < end) {
        size_t left = (size_t)(end - input);
        if (left >= 3 && wcsncmp(input, L"../", 3) == 0) { input += 3; continue; }
        if (left >= 2 && wcsncmp(input, L"./", 2) == 0) { input += 2; continue; }
        if (left >= 3 && wcsncmp(input, L"/./", 3) == 0) { input += 2; continue; }
        if (left == 2 && wcsncmp(input, L"/.", 2) == 0) { *output++ = L'/'; break; }
        if ((left >= 4 && wcsncmp(input, L"/../", 4) == 0) ||
            (left == 3 && wcsncmp(input, L"/..", 3) == 0)) {
            while (output > path && output[-1] != L'/') output--;
            if (output > path) output--;
            input += 3;
            if (input == end) *output++ = L'/';
            continue;
        }
        if ((left == 1 && input[0] == L'.') || (left == 2 && wcsncmp(input, L"..", 2) == 0)) break;
        if (*input == L'/') *output++ = *input++;
        while (input < end && *input != L'/') *output++ = *input++;
    }
    memmove(output, end, (wcslen(end) + 1) * sizeof(wchar_t));
}

/* 解析绝对、协议相对、根相对与路径相对 Location；不允许 HTTPS 降级。 */
au_err_t au_http_redirect_url(const wchar_t* base, const wchar_t* location,
                              wchar_t** out, int* keep_auth) {
    if (!base || !location || !location[0] || !out || !keep_auth) return AU_ERR_ARG;
    *out = NULL;
    *keep_auth = 0;
    if (wcspbrk(location, L"\r\n\\")) return AU_ERR_HTTP;
    URL_COMPONENTS from, to;
    wchar_t from_host[256] = {0}, to_host[256] = {0};
    if (!crack_origin(base, &from, from_host)) return AU_ERR_ARG;
    const wchar_t* scheme_end = wcschr(base, L':');
    if (!scheme_end || wcsncmp(scheme_end, L"://", 3) != 0) return AU_ERR_ARG;
    const wchar_t* authority = scheme_end + 3;
    const wchar_t* authority_end = authority + wcscspn(authority, L"/?#");
    size_t prefix = 0;
    int slash = 0;
    const wchar_t* colon = wcschr(location, L':');
    if (colon && colon < location + wcscspn(location, L"/?#")) {
        /* 带 scheme 的绝对地址，稍后统一检查 scheme/凭据。 */
    } else if (wcsncmp(location, L"//", 2) == 0) {
        prefix = (size_t)(scheme_end - base) + 1;
    } else if (location[0] == L'/') {
        prefix = (size_t)(authority_end - base);
    } else {
        const wchar_t* path_end = authority_end + wcscspn(authority_end, L"?#");
        if (location[0] != L'?' && location[0] != L'#') {
            while (path_end > authority_end && path_end[-1] != L'/') path_end--;
        } else if (location[0] == L'#') {
            path_end = base + wcscspn(base, L"#");
        }
        prefix = (size_t)(path_end - base);
        slash = path_end == authority_end;
    }
    size_t tail = wcslen(location);
    if (prefix > SIZE_MAX / sizeof(wchar_t) - 2 ||
        tail > SIZE_MAX / sizeof(wchar_t) - prefix - 2) return AU_ERR_NOMEM;
    wchar_t* next = (wchar_t*)malloc((prefix + tail + 2) * sizeof(wchar_t));
    if (!next) return AU_ERR_NOMEM;
    wmemcpy(next, base, prefix);
    if (slash) next[prefix++] = L'/';
    wcscpy(next + prefix, location);
    wchar_t* fragment = wcschr(next, L'#');
    if (fragment) *fragment = L'\0';
    normalize_redirect_path(next);
    if (!crack_origin(next, &to, to_host) ||
        (from.nScheme == INTERNET_SCHEME_HTTPS && to.nScheme != INTERNET_SCHEME_HTTPS)) {
        free(next);
        return AU_ERR_HTTP;
    }
    *keep_auth = from.nScheme == to.nScheme && from.nPort == to.nPort &&
                 _wcsicmp(from_host, to_host) == 0;
    *out = next;
    return AU_OK;
}

static au_err_t read_header(HINTERNET request, DWORD query, const wchar_t* name,
                             int optional, wchar_t** out) {
    *out = NULL;
    DWORD bytes = 0;
    WinHttpQueryHeaders(request, query, name, NULL, &bytes, WINHTTP_NO_HEADER_INDEX);
    DWORD error = GetLastError();
    if (error == ERROR_WINHTTP_HEADER_NOT_FOUND && optional) return AU_OK;
    if (error != ERROR_INSUFFICIENT_BUFFER) return AU_ERR_HTTP;
    wchar_t* value = (wchar_t*)calloc((size_t)bytes / sizeof(wchar_t) + 1, sizeof(wchar_t));
    if (!value) return AU_ERR_NOMEM;
    if (!WinHttpQueryHeaders(request, query, name, value, &bytes, WINHTTP_NO_HEADER_INDEX)) {
        free(value);
        return AU_ERR_HTTP;
    }
    *out = value;
    return AU_OK;
}

/* 读取限流头 X-RateLimit-Remaining。缺失置 -1。 */
static int read_ratelimit(HINTERNET hReq) {
    wchar_t buf[32] = {0}; DWORD len = sizeof buf;
    if (WinHttpQueryHeaders(hReq, WINHTTP_QUERY_CUSTOM,
                            L"X-RateLimit-Remaining", buf, &len, WINHTTP_NO_HEADER_INDEX)) {
        buf[(sizeof buf / sizeof buf[0]) - 1] = L'\0';
        return (int)_wtoi(buf);
    }
    return -1;
}

static wchar_t* copy_url_part(const wchar_t* p, DWORD len) {
    if (!p || (size_t)len > SIZE_MAX / sizeof(wchar_t) - 1) return NULL;
    wchar_t* result = (wchar_t*)malloc(((size_t)len + 1) * sizeof(wchar_t));
    if (!result) return NULL;
    if (len) wmemcpy(result, p, len);
    result[len] = L'\0';
    return result;
}

static wchar_t* build_request_target(const URL_COMPONENTS* uc) {
    size_t path_len = (size_t)uc->dwUrlPathLength;
    size_t extra_len = (size_t)uc->dwExtraInfoLength;
    if (extra_len > SIZE_MAX - 2 || path_len > SIZE_MAX - extra_len - 2 ||
        path_len + extra_len + 2 > SIZE_MAX / sizeof(wchar_t))
        return NULL;
    size_t prefix = path_len ? path_len : 1;
    wchar_t* result = (wchar_t*)malloc((prefix + extra_len + 1) * sizeof(wchar_t));
    if (!result) return NULL;
    if (path_len) wmemcpy(result, uc->lpszUrlPath, path_len);
    else result[0] = L'/';
    if (extra_len) wmemcpy(result + prefix, uc->lpszExtraInfo, extra_len);
    result[prefix + extra_len] = L'\0';
    return result;
}

wchar_t* au_http_request_target(const wchar_t* url) {
    URL_COMPONENTS uc;
    if (!url) return NULL;
    memset(&uc, 0, sizeof uc);
    uc.dwStructSize = sizeof uc;
    uc.dwUrlPathLength = (DWORD)-1;
    uc.dwExtraInfoLength = (DWORD)-1;
    if (!WinHttpCrackUrl(url, 0, 0, &uc)) return NULL;
    return build_request_target(&uc);
}

static au_err_t read_location_utf8(HINTERNET hReq, char** out) {
    DWORD bytes = 0;
    WinHttpQueryHeaders(hReq, WINHTTP_QUERY_LOCATION, WINHTTP_HEADER_NAME_BY_INDEX,
                        WINHTTP_NO_OUTPUT_BUFFER, &bytes, WINHTTP_NO_HEADER_INDEX);
    if (GetLastError() != ERROR_INSUFFICIENT_BUFFER || bytes == 0 ||
        (size_t)bytes > SIZE_MAX - sizeof(wchar_t))
        return AU_ERR_HTTP;
    wchar_t* loc = (wchar_t*)calloc(1, (size_t)bytes + sizeof(wchar_t));
    if (!loc) return AU_ERR_NOMEM;
    DWORD capacity = bytes;
    if (!WinHttpQueryHeaders(hReq, WINHTTP_QUERY_LOCATION, WINHTTP_HEADER_NAME_BY_INDEX,
                             loc, &capacity, WINHTTP_NO_HEADER_INDEX)) {
        free(loc);
        return AU_ERR_HTTP;
    }
    *out = au_wide_to_utf8(loc);
    free(loc);
    return *out ? AU_OK : AU_ERR_NOMEM;
}

/* 核心请求。
 *  - out_mem 非 NULL：响应体写入新分配的内存缓冲。
 *  - 否则 hSink 为文件句柄，流式落盘。
 *  - out_location 非 NULL：**不跟随重定向**，遇 3xx 时把 Location 头（UTF-8）写入
 *    *out_location 并即刻返回 AU_OK（不读响应体）。用于读取 github.com 网页端点
 *    releases/latest 的 302 目标以取回最新 tag（限流兜底路径）。 */
static au_err_t do_request(au_ctx_t* ctx, const wchar_t* url, int is_api,
                           char** out_mem, size_t* out_len,
                           HANDLE hSink, char** out_location, au_http_meta* meta) {
    au_err_t rc = AU_ERR_NET;
    HINTERNET hSession = NULL, hConnect = NULL, hRequest = NULL;
    wchar_t* host = NULL;
    wchar_t* request_target = NULL;
    wchar_t* headers = NULL;
    char* mem = NULL; size_t cap = 0, len = 0;
    char* io_buf = NULL;
    wchar_t* current_url = _wcsdup(url);
    int allow_auth = 1, redirects = 0;

    if (meta) { meta->status = 0; meta->ratelimit_remaining = -1; meta->has_next_page = 0; }
    if (!current_url) return AU_ERR_NOMEM;

request:
    if (au_is_canceled(ctx)) { rc = AU_ERR_CANCELED; goto done; }
    URL_COMPONENTS uc; memset(&uc, 0, sizeof uc);
    uc.dwStructSize = sizeof uc;
    uc.dwHostNameLength = (DWORD)-1;
    uc.dwUrlPathLength = (DWORD)-1;
    uc.dwExtraInfoLength = (DWORD)-1;
    uc.dwUserNameLength = (DWORD)-1;
    uc.dwPasswordLength = (DWORD)-1;
    if (!WinHttpCrackUrl(current_url, 0, 0, &uc) || uc.dwUserNameLength ||
        uc.dwPasswordLength || uc.nScheme != INTERNET_SCHEME_HTTPS) {
        rc = AU_ERR_ARG; goto done;
    }
    host = copy_url_part(uc.lpszHostName, uc.dwHostNameLength);
    request_target = build_request_target(&uc);
    if (!host || !request_target) { rc = AU_ERR_NOMEM; goto done; }

    if (!hSession) hSession = WinHttpOpen(L"WinAutoUpdate/1.0",
                           WINHTTP_ACCESS_TYPE_AUTOMATIC_PROXY,
                           WINHTTP_NO_PROXY_NAME, WINHTTP_NO_PROXY_BYPASS, 0);
    if (!hSession) goto done;

    DWORD tmo = (DWORD)(ctx->timeout_ms > 0 ? ctx->timeout_ms : 30000);
    if (!WinHttpSetTimeouts(hSession, (int)tmo, (int)tmo, (int)tmo, (int)tmo)) goto done;
    /* 强制 TLS1.2/1.3。 */
    DWORD secure = WINHTTP_FLAG_SECURE_PROTOCOL_TLS1_2 | 0x00002000 /* TLS1_3 */;
    if (!WinHttpSetOption(hSession, WINHTTP_OPTION_SECURE_PROTOCOLS, &secure, sizeof secure)) {
        secure = WINHTTP_FLAG_SECURE_PROTOCOL_TLS1_2;
        if (!WinHttpSetOption(hSession, WINHTTP_OPTION_SECURE_PROTOCOLS, &secure, sizeof secure)) goto done;
    }

    hConnect = WinHttpConnect(hSession, host, uc.nPort, 0);
    if (!hConnect) goto done;

    hRequest = WinHttpOpenRequest(hConnect, L"GET", request_target, NULL,
                                  WINHTTP_NO_REFERER, WINHTTP_DEFAULT_ACCEPT_TYPES,
                                  WINHTTP_FLAG_SECURE);
    if (!hRequest) goto done;

    /* 逐跳检查地址与认证边界，不依赖 WinHTTP 自动剥离自定义认证头。 */
    DWORD redirect = WINHTTP_OPTION_REDIRECT_POLICY_NEVER;
    if (!WinHttpSetOption(hRequest, WINHTTP_OPTION_REDIRECT_POLICY, &redirect, sizeof redirect)) goto done;

    rc = au_http_build_headers(ctx, current_url, is_api, allow_auth, &headers);
    if (rc != AU_OK) goto done;
    rc = AU_ERR_NET;
    if (!WinHttpSendRequest(hRequest, headers, (DWORD)-1L,
                             WINHTTP_NO_REQUEST_DATA, 0, 0, 0)) goto done;
    if (!WinHttpReceiveResponse(hRequest, NULL)) goto done;
    if (au_is_canceled(ctx)) { rc = AU_ERR_CANCELED; goto done; }

    /* 状态码 */
    DWORD status = 0, slen = sizeof status;
    if (!WinHttpQueryHeaders(hRequest, WINHTTP_QUERY_STATUS_CODE | WINHTTP_QUERY_FLAG_NUMBER,
                             WINHTTP_HEADER_NAME_BY_INDEX, &status, &slen, WINHTTP_NO_HEADER_INDEX))
        goto done;
    int ratelimit = read_ratelimit(hRequest);
    if (meta) { meta->status = (int)status; meta->ratelimit_remaining = ratelimit; }

    if (status == 403 && ratelimit == 0) { rc = AU_ERR_RATELIMIT; goto done; }

    /* 读取 Location 模式：只要 302 的目标，不读体。 */
    if (out_location) {
        if (status >= 300 && status < 400) {
            rc = read_location_utf8(hRequest, out_location);
        } else {
            rc = AU_ERR_HTTP;       /* 期望重定向却非 3xx（如仓库无 release 时 404） */
        }
        goto done;
    }

    if (status == 301 || status == 302 || status == 303 || status == 307 || status == 308) {
        wchar_t *location = NULL, *next = NULL;
        int keep_auth = 0;
        if (redirects++ >= 10) { rc = AU_ERR_HTTP; goto done; }
        rc = read_header(hRequest, WINHTTP_QUERY_LOCATION, WINHTTP_HEADER_NAME_BY_INDEX, 0, &location);
        if (rc == AU_OK) rc = au_http_redirect_url(current_url, location, &next, &keep_auth);
        free(location);
        if (rc != AU_OK) goto done;
        allow_auth = allow_auth && keep_auth; /* 跨源后即使跳回原站也不再携带令牌。 */
        free(current_url); current_url = next;
        free(headers); headers = NULL;
        free(host); host = NULL;
        free(request_target); request_target = NULL;
        WinHttpCloseHandle(hRequest); hRequest = NULL;
        WinHttpCloseHandle(hConnect); hConnect = NULL;
        rc = AU_ERR_NET;
        goto request;
    }

    if (status < 200 || status >= 300)  { rc = AU_ERR_HTTP; goto done; }

    if (is_api && meta) {
        wchar_t* link = NULL;
        rc = read_header(hRequest, WINHTTP_QUERY_CUSTOM, L"Link", 1, &link);
        if (rc != AU_OK) goto done;
        meta->has_next_page = link && (wcsstr(link, L"rel=\"next\"") || wcsstr(link, L"rel=next"));
        free(link);
    }

    /* 总长度（下载进度用；可能缺失）。 */
    uint64_t total = 0;
    {
        wchar_t clen[32] = {0}; DWORD cl = sizeof clen;
        if (WinHttpQueryHeaders(hRequest, WINHTTP_QUERY_CONTENT_LENGTH,
                                WINHTTP_HEADER_NAME_BY_INDEX, clen, &cl, WINHTTP_NO_HEADER_INDEX)) {
            clen[(sizeof clen / sizeof clen[0]) - 1] = L'\0';
            total = _wcstoui64(clen, NULL, 10);
        }
    }

    /* 读循环。done 统计已落地字节，供文件模式的进度回调。 */
    uint64_t done_bytes = 0;
    io_buf = (char*)malloc(16384);
    if (!io_buf) { rc = AU_ERR_NOMEM; goto done; }
    for (;;) {
        if (au_is_canceled(ctx)) { rc = AU_ERR_CANCELED; goto done; }

        DWORD avail = 0;
        if (!WinHttpQueryDataAvailable(hRequest, &avail)) { rc = AU_ERR_NET; goto done; }
        if (avail == 0) break;

        DWORD want = avail > 16384 ? 16384 : avail;
        DWORD got = 0;
        if (!WinHttpReadData(hRequest, io_buf, want, &got)) { rc = AU_ERR_NET; goto done; }
        if (got == 0) break;
        if (done_bytes > UINT64_MAX - got) { rc = AU_ERR_NET; goto done; }
        done_bytes += got;

        if (out_mem) {
            if ((size_t)got > SIZE_MAX - len - 1) { rc = AU_ERR_NOMEM; goto done; }
            size_t required = len + (size_t)got + 1;
            if (required > cap) {
                size_t ncap = cap ? cap * 2 : 65536;
                if (cap > SIZE_MAX / 2) ncap = required;
                while (ncap < required) {
                    if (ncap > SIZE_MAX / 2) { ncap = required; break; }
                    ncap *= 2;
                }
                char* np = (char*)realloc(mem, ncap);
                if (!np) { rc = AU_ERR_NOMEM; goto done; }
                mem = np; cap = ncap;
            }
            if (!mem) { rc = AU_ERR_NOMEM; goto done; }
            memcpy(mem + len, io_buf, got);
            len += got;
        } else {
            DWORD written = 0;
            if (!WriteFile(hSink, io_buf, got, &written, NULL) || written != got) {
                rc = AU_ERR_IO; goto done;
            }
            if (ctx->on_progress) {
                /* total 可能为 0，原样传出，不编造百分比。 */
                if (ctx->on_progress(total, done_bytes, ctx->userdata) != 0) {
                    rc = AU_ERR_CANCELED; goto done;
                }
            }
        }
    }

    if (au_is_canceled(ctx)) { rc = AU_ERR_CANCELED; goto done; }
    if (total != 0 && done_bytes != total) { rc = AU_ERR_NET; goto done; }

    if (out_mem) {
        if (!mem) {
            mem = (char*)malloc(1);
            if (!mem) { rc = AU_ERR_NOMEM; goto done; }
            cap = 1;
        }
        mem[len] = '\0';
        *out_mem = mem; *out_len = len; mem = NULL;
    }
    rc = AU_OK;

done:
    free(current_url);
    free(io_buf);
    free(request_target);
    free(host);
    if (mem) free(mem);
    if (headers) free(headers);
    if (hRequest) WinHttpCloseHandle(hRequest);
    if (hConnect) WinHttpCloseHandle(hConnect);
    if (hSession) WinHttpCloseHandle(hSession);
    return rc;
}

au_err_t au_http_get_mem(au_ctx_t* ctx, const wchar_t* url,
                         char** out, size_t* len, au_http_meta* meta) {
    if (!ctx || !url || !out || !len) return AU_ERR_ARG;
    *out = NULL; *len = 0;
    return do_request(ctx, url, 1, out, len, NULL, NULL, meta);
}

/* 网页端点取内存（非 API：不发 Accept/X-GitHub-Api-Version）。用于抓 checksums.txt。 */
au_err_t au_http_get_mem_web(au_ctx_t* ctx, const wchar_t* url,
                             char** out, size_t* len, au_http_meta* meta) {
    if (!ctx || !url || !out || !len) return AU_ERR_ARG;
    *out = NULL; *len = 0;
    return do_request(ctx, url, 0, out, len, NULL, NULL, meta);
}

au_err_t au_http_get_file(au_ctx_t* ctx, const wchar_t* url, HANDLE hFile,
                          au_http_meta* meta) {
    if (!ctx || !url || !hFile || hFile == INVALID_HANDLE_VALUE) return AU_ERR_ARG;
    return do_request(ctx, url, 0, NULL, NULL, hFile, NULL, meta);
}

/* GET url 但不跟随重定向，取回 3xx 的 Location 头（UTF-8，新分配，调用方 free）。 */
au_err_t au_http_get_location(au_ctx_t* ctx, const wchar_t* url,
                              char** out_location, au_http_meta* meta) {
    if (!ctx || !url || !out_location) return AU_ERR_ARG;
    *out_location = NULL;
    return do_request(ctx, url, 0, NULL, NULL, NULL, out_location, meta);
}

/* {url} 模板替换。 */
static wchar_t* apply_template(const wchar_t* tmpl, const wchar_t* raw) {
    if (!tmpl || !raw) return NULL;
    const wchar_t* marker = wcsstr(tmpl, L"{url}");
    if (!marker) {
        /* 无占位符：整串即最终 URL（第一项 "{url}" 之外的少见配置）。 */
        return _wcsdup(tmpl);
    }
    size_t pre = (size_t)(marker - tmpl);
    size_t rawlen = wcslen(raw);
    size_t taillen = wcslen(marker + 5);
    if (pre > SIZE_MAX - rawlen || pre + rawlen > SIZE_MAX - taillen - 1 ||
        pre + rawlen + taillen + 1 > SIZE_MAX / sizeof(wchar_t))
        return NULL;
    wchar_t* out = (wchar_t*)malloc((pre + rawlen + taillen + 1) * sizeof(wchar_t));
    if (!out) return NULL;
    wmemcpy(out, tmpl, pre);
    wmemcpy(out + pre, raw, rawlen);
    wmemcpy(out + pre + rawlen, marker + 5, taillen);
    out[pre + rawlen + taillen] = L'\0';
    return out;
}

wchar_t** au_build_mirror_urls(au_ctx_t* ctx, const char* raw_url, size_t* count) {
    if (!count) return NULL;
    *count = 0;
    if (!ctx || !raw_url || !ctx->mirrors || ctx->mirror_count == 0) return NULL;
    wchar_t* raw = au_utf8_to_wide(raw_url);
    if (!raw) return NULL;

    size_t n = ctx->mirror_count;
    wchar_t** urls = (wchar_t**)calloc(n, sizeof(wchar_t*));
    if (!urls) { free(raw); return NULL; }
    for (size_t i = 0; i < n; i++) {
        urls[i] = apply_template(ctx->mirrors[i], raw);
        if (!urls[i]) {
            for (size_t j = 0; j < i; j++) free(urls[j]);
            free(urls); free(raw);
            return NULL;
        }
    }
    free(raw);
    *count = n;
    return urls;
}
