/*
 * au_update.c — 上下文生命周期与配置深拷贝。检测/下载/应用的具体实现分散在
 * au_gh.c / au_download.c / au_apply.c，本文件只负责持有状态与释放。
 */
#include "au_internal.h"
#include <stdlib.h>
#include <string.h>

/* 内置资产镜像模板。API 元数据始终从 api.github.com 直连获取；只有已经由
 * 可信元数据提供完整 SHA-256 的资产才允许尝试公共反代。 */
static const wchar_t* DEFAULT_MIRRORS[] = {
    L"{url}",
    L"https://gh-proxy.com/{url}",
    L"https://ghfast.top/{url}",
};

const char* au_strerror(au_err_t e) {
    switch (e) {
        case AU_OK:              return "ok";
        case AU_ERR_ARG:         return "invalid argument";
        case AU_ERR_NOMEM:       return "out of memory";
        case AU_ERR_NET:         return "network error";
        case AU_ERR_HTTP:        return "http error";
        case AU_ERR_RATELIMIT:   return "github api rate limited";
        case AU_ERR_PARSE:       return "response parse error";
        case AU_ERR_NO_ASSET:    return "no matching asset";
        case AU_ERR_IO:          return "file io error";
        case AU_ERR_HASH:        return "sha-256 mismatch";
        case AU_ERR_EXTRACT:     return "zip extract failed";
        case AU_ERR_NOT_WRITABLE:return "install dir not writable";
        case AU_ERR_REPLACE:     return "file replace failed";
        case AU_ERR_LAUNCH:      return "launch process failed";
        case AU_ERR_CANCELED:    return "canceled";
        case AU_ERR_STATE:       return "internal state error";
        default:                 return "unknown error";
    }
}

static int has_crlf(const char* s) {
    return s && (strchr(s, '\r') || strchr(s, '\n'));
}

static int valid_utf8(const char* s) {
    wchar_t* w;
    if (!s) return 1;
    w = au_utf8_to_wide(s);
    if (!w) return 0;
    free(w);
    return 1;
}

au_ctx_t* au_create(const au_config_t* cfg) {
    if (!cfg || !cfg->owner || !cfg->repo || !cfg->current_version ||
        !cfg->asset_pattern || !cfg->owner[0] || !cfg->repo[0] ||
        !cfg->current_version[0] || !cfg->asset_pattern[0] ||
        (cfg->mode != AU_MODE_EXE && cfg->mode != AU_MODE_ZIP &&
         cfg->mode != AU_MODE_INSTALLER) ||
        (cfg->channel != AU_CHANNEL_STABLE && cfg->channel != AU_CHANNEL_BETA) ||
        ((cfg->mirrors == NULL) != (cfg->mirror_count == 0)) ||
        ((cfg->zip_exclude == NULL) != (cfg->zip_exclude_count == 0)) ||
        cfg->timeout_ms < 0 || cfg->retry_max < 0 || cfg->retry_max > 100 ||
        has_crlf(cfg->user_agent) || has_crlf(cfg->token) ||
        !valid_utf8(cfg->owner) || !valid_utf8(cfg->repo) ||
        !valid_utf8(cfg->asset_pattern) || !valid_utf8(cfg->user_agent) ||
        !valid_utf8(cfg->token) || !valid_utf8(cfg->installer_args))
        return NULL;

    for (size_t i = 0; i < cfg->mirror_count; i++)
        if (!cfg->mirrors[i] || !cfg->mirrors[i][0]) return NULL;
    for (size_t i = 0; i < cfg->zip_exclude_count; i++)
        if (!cfg->zip_exclude[i] || !cfg->zip_exclude[i][0]) return NULL;

    au_ctx_t* c = (au_ctx_t*)calloc(1, sizeof *c);
    if (!c) return NULL;

    c->owner         = au_strdup(cfg->owner);
    c->repo          = au_strdup(cfg->repo);
    c->asset_pattern = au_strdup(cfg->asset_pattern);
    c->user_agent    = au_strdup(cfg->user_agent ? cfg->user_agent : "WinAutoUpdate/1.0");
    c->token         = cfg->token ? au_strdup(cfg->token) : NULL;
    c->installer_args= cfg->installer_args ? au_strdup(cfg->installer_args) : NULL;

    if (!c->owner || !c->repo || !c->asset_pattern || !c->user_agent ||
        (cfg->token && !c->token) || (cfg->installer_args && !c->installer_args)) {
        au_destroy(c);
        return NULL;
    }

    if (au_version_parse(cfg->current_version, &c->current) != AU_OK) { au_destroy(c); return NULL; }

    c->mode             = cfg->mode;
    c->channel          = cfg->channel;
    c->timeout_ms       = cfg->timeout_ms > 0 ? cfg->timeout_ms : 30000;
    c->retry_max        = cfg->retry_max > 0 ? cfg->retry_max : 2;
    c->installer_silent = cfg->installer_silent;
    c->on_progress      = cfg->on_progress;
    c->on_log           = cfg->on_log;
    c->userdata         = cfg->userdata;
    c->cancel_flag      = 0;

    /* 镜像：用户提供则用之，否则用内置默认。全部转宽字符深拷贝。 */
    size_t nm;
    if (cfg->mirrors) {
        nm = cfg->mirror_count;
        c->mirrors = (wchar_t**)calloc(nm, sizeof(wchar_t*));
        if (!c->mirrors) { au_destroy(c); return NULL; }
        c->mirror_count = nm;
        for (size_t i = 0; i < nm; i++) {
            c->mirrors[i] = au_utf8_to_wide(cfg->mirrors[i]);
            if (!c->mirrors[i]) { au_destroy(c); return NULL; }
        }
    } else {
        nm = sizeof DEFAULT_MIRRORS / sizeof DEFAULT_MIRRORS[0];
        c->mirrors = (wchar_t**)calloc(nm, sizeof(wchar_t*));
        if (!c->mirrors) { au_destroy(c); return NULL; }
        c->mirror_count = nm;
        for (size_t i = 0; i < nm; i++) {
            c->mirrors[i] = _wcsdup(DEFAULT_MIRRORS[i]);
            if (!c->mirrors[i]) { au_destroy(c); return NULL; }
        }
    }

    /* zip_exclude：转宽字符深拷贝。 */
    if (cfg->zip_exclude) {
        c->zip_exclude = (wchar_t**)calloc(cfg->zip_exclude_count, sizeof(wchar_t*));
        if (!c->zip_exclude) { au_destroy(c); return NULL; }
        c->zip_exclude_count = cfg->zip_exclude_count;
        for (size_t i = 0; i < cfg->zip_exclude_count; i++) {
            c->zip_exclude[i] = au_utf8_to_wide(cfg->zip_exclude[i]);
            if (!c->zip_exclude[i]) { au_destroy(c); return NULL; }
        }
    }
    return c;
}

void au_destroy(au_ctx_t* c) {
    if (!c) return;
    free(c->owner); free(c->repo); free(c->asset_pattern);
    free(c->user_agent); free(c->token); free(c->installer_args);
    if (c->mirrors) { for (size_t i = 0; i < c->mirror_count; i++) free(c->mirrors[i]); free(c->mirrors); }
    if (c->zip_exclude) { for (size_t i = 0; i < c->zip_exclude_count; i++) free(c->zip_exclude[i]); free(c->zip_exclude); }
    free(c);
}

void au_cancel(au_ctx_t* c) {
    if (c) InterlockedExchange(&c->cancel_flag, 1);
}

void au_reset_cancel(au_ctx_t* c) {
    if (c) InterlockedExchange(&c->cancel_flag, 0);
}
