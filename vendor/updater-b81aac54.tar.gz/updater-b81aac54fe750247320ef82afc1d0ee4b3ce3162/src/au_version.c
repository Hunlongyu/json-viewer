/* 严格 SemVer 2.0 解析与比较；au_version_t 保持无堆 POD。 */
#include "au_internal.h"
#include <limits.h>
#include <string.h>

typedef struct {
    int major, minor, patch;
    const char* prerelease;
    size_t prerelease_len;
} parsed_version;

static int ident_char(char c) {
    return (c >= '0' && c <= '9') || (c >= 'A' && c <= 'Z') ||
           (c >= 'a' && c <= 'z') || c == '-';
}

static int parse_number(const char** pp, int* value) {
    const char* p = *pp;
    unsigned int n = 0;
    if (*p < '0' || *p > '9') return 0;
    if (*p == '0' && p[1] >= '0' && p[1] <= '9') return 0;
    do {
        unsigned int digit = (unsigned int)(*p - '0');
        if (n > ((unsigned int)INT_MAX - digit) / 10U) return 0;
        n = n * 10U + digit;
        p++;
    } while (*p >= '0' && *p <= '9');
    *pp = p;
    *value = (int)n;
    return 1;
}

static int validate_identifiers(const char* p, size_t len, int prerelease) {
    size_t start = 0;
    if (len == 0) return 0;
    for (size_t i = 0; i <= len; i++) {
        if (i == len || p[i] == '.') {
            size_t n = i - start;
            if (n == 0) return 0;
            if (prerelease && n > 1 && p[start] == '0') {
                int numeric = 1;
                for (size_t j = start; j < i; j++) {
                    if (p[j] < '0' || p[j] > '9') { numeric = 0; break; }
                }
                if (numeric) return 0;
            }
            start = i + 1;
        } else if (!ident_char(p[i])) {
            return 0;
        }
    }
    return 1;
}

static int parse_semver(const char* tag, parsed_version* out) {
    const char* p;
    const char* pre = NULL;
    size_t pre_len = 0;
    int major, minor, patch;
    if (!tag || !out) return 0;
    p = tag;
    if (*p == 'v' || *p == 'V') p++;
    if (!parse_number(&p, &major) || *p != '.') return 0;
    p++;
    if (!parse_number(&p, &minor) || *p != '.') return 0;
    p++;
    if (!parse_number(&p, &patch)) return 0;

    if (*p == '-') {
        const char* end;
        pre = ++p;
        end = strchr(p, '+');
        if (!end) end = p + strlen(p);
        pre_len = (size_t)(end - p);
        if (!validate_identifiers(p, pre_len, 1)) return 0;
        p = end;
    }
    if (*p == '+') {
        const char* build = ++p;
        size_t build_len = strlen(build);
        if (!validate_identifiers(build, build_len, 0)) return 0;
        p += build_len;
    }
    if (*p != '\0') return 0;

    out->major = major;
    out->minor = minor;
    out->patch = patch;
    out->prerelease = pre;
    out->prerelease_len = pre_len;
    return 1;
}

au_err_t au_version_parse(const char* tag, au_version_t* out) {
    parsed_version p;
    au_version_t result;
    size_t len;
    if (!tag || !out) return AU_ERR_ARG;
    len = strlen(tag);
    if (len == 0 || len >= sizeof result.raw || !parse_semver(tag, &p) ||
        p.prerelease_len >= sizeof result.prerelease)
        return AU_ERR_ARG;

    memset(&result, 0, sizeof result);
    result.major = p.major;
    result.minor = p.minor;
    result.patch = p.patch;
    memcpy(result.raw, tag, len + 1);
    if (p.prerelease_len) {
        memcpy(result.prerelease, p.prerelease, p.prerelease_len);
        result.prerelease[p.prerelease_len] = '\0';
    }
    *out = result;
    return AU_OK;
}

static int numeric_identifier(const char* s, size_t n) {
    if (n == 0) return 0;
    for (size_t i = 0; i < n; i++)
        if (s[i] < '0' || s[i] > '9') return 0;
    return 1;
}

static int compare_identifier(const char* a, size_t an, const char* b, size_t bn) {
    int a_num = numeric_identifier(a, an);
    int b_num = numeric_identifier(b, bn);
    if (a_num && b_num) {
        if (an != bn) return an < bn ? -1 : 1;
    } else if (a_num != b_num) {
        return a_num ? -1 : 1;
    }
    {
        size_t n = an < bn ? an : bn;
        int r = memcmp(a, b, n);
        if (r) return r < 0 ? -1 : 1;
    }
    return an == bn ? 0 : (an < bn ? -1 : 1);
}

static int compare_prerelease(const parsed_version* a, const parsed_version* b) {
    size_t ai = 0, bi = 0;
    if (!a->prerelease_len || !b->prerelease_len) {
        if (a->prerelease_len == b->prerelease_len) return 0;
        return a->prerelease_len ? -1 : 1;
    }
    while (ai < a->prerelease_len && bi < b->prerelease_len) {
        size_t ae = ai, be = bi;
        int r;
        while (ae < a->prerelease_len && a->prerelease[ae] != '.') ae++;
        while (be < b->prerelease_len && b->prerelease[be] != '.') be++;
        r = compare_identifier(a->prerelease + ai, ae - ai,
                               b->prerelease + bi, be - bi);
        if (r) return r;
        ai = ae < a->prerelease_len ? ae + 1 : ae;
        bi = be < b->prerelease_len ? be + 1 : be;
    }
    if (ai == a->prerelease_len && bi == b->prerelease_len) return 0;
    return ai == a->prerelease_len ? -1 : 1;
}

int au_version_cmp(const au_version_t* a, const au_version_t* b) {
    parsed_version pa, pb;
    if (!a || !b || !parse_semver(a->raw, &pa) || !parse_semver(b->raw, &pb)) return 0;
    if (pa.major != pb.major) return pa.major < pb.major ? -1 : 1;
    if (pa.minor != pb.minor) return pa.minor < pb.minor ? -1 : 1;
    if (pa.patch != pb.patch) return pa.patch < pb.patch ? -1 : 1;
    return compare_prerelease(&pa, &pb);
}
