/*
 * fixture_app.c — 自替换端到端测试的被测程序。
 * 编译两次（-DFIXVER=1 / =2）得到 app_v1 / app_v2。
 *
 * 运行时：
 *   1. au_wait_for_predecessor + au_cleanup_after_restart（模拟真实主程序开头）
 *   2. 向 <selfdir>\result.txt 追加一行 "running vN [old_exists=?]"
 *   3. 若 FIXVER<2 且同目录存在 "<selfname>.autmp"（模拟已下载的新版包），
 *      调用 au_apply(EXE) 触发自替换。v2 因版本已达标不再更新。
 */
#include "win_autoupdate.h"
#include <windows.h>
#include <stdio.h>
#include <string.h>

#ifndef FIXVER
#define FIXVER 1
#endif

static void self_dir(wchar_t* out, size_t cap) {
    wchar_t p[MAX_PATH]; GetModuleFileNameW(NULL, p, MAX_PATH);
    wchar_t* s = wcsrchr(p, L'\\'); if (s) *s = 0;
    wcsncpy(out, p, cap); out[cap-1]=0;
}
static void self_name(wchar_t* out, size_t cap) {
    wchar_t p[MAX_PATH]; GetModuleFileNameW(NULL, p, MAX_PATH);
    wchar_t* s = wcsrchr(p, L'\\'); wcsncpy(out, s?s+1:p, cap); out[cap-1]=0;
}

int main(int argc, char** argv) {
    au_wait_for_predecessor(argc, argv, 10000);

    int scenario = 0; /* 0=常规 EXE，1=EXE 移动失败，2=ZIP 启动失败，3=ZIP 主程序为目录 */
    for (int i = 1; i < argc; i++) {
        if (strcmp(argv[i], "--test-move-failure") == 0) scenario = 1;
        else if (strcmp(argv[i], "--test-zip-launch-failure") == 0) scenario = 2;
        else if (strcmp(argv[i], "--test-zip-dir-main") == 0) scenario = 3;
    }

    wchar_t dir[MAX_PATH]; self_dir(dir, MAX_PATH);
    wchar_t name[MAX_PATH]; self_name(name, MAX_PATH);

    /* 记录 .old 在 cleanup 之前是否存在（验证 cleanup 生效）。 */
    wchar_t oldp[MAX_PATH]; _snwprintf(oldp, MAX_PATH, L"%s\\%s.old", dir, name); oldp[MAX_PATH-1]=0;
    int old_before = GetFileAttributesW(oldp) != INVALID_FILE_ATTRIBUTES;

    au_cleanup_after_restart();

    wchar_t resp[MAX_PATH]; _snwprintf(resp, MAX_PATH, L"%s\\result.txt", dir); resp[MAX_PATH-1]=0;
    FILE* f = _wfopen(resp, L"a");
    if (f) { fprintf(f, "running v%d old_before=%d\n", FIXVER, old_before); fclose(f); }

#if FIXVER < 2
    /* 存在下载包则触发更新。 */
    wchar_t pkgw[MAX_PATH]; _snwprintf(pkgw, MAX_PATH, L"%s\\%s.autmp", dir, name); pkgw[MAX_PATH-1]=0;
    if (GetFileAttributesW(pkgw) != INVALID_FILE_ATTRIBUTES || scenario == 1) {
        char pkg[MAX_PATH*2];
        WideCharToMultiByte(CP_UTF8, 0, pkgw, -1, pkg, sizeof pkg, NULL, NULL);

        au_config_t cfg; memset(&cfg, 0, sizeof cfg);
        cfg.owner="o"; cfg.repo="r"; cfg.current_version="v1.0.0";
        cfg.asset_pattern="*";
        cfg.mode = (scenario == 2 || scenario == 3) ? AU_MODE_ZIP : AU_MODE_EXE;
        au_ctx_t* ctx = au_create(&cfg);
        au_err_t e = au_apply(ctx, pkg);   /* 成功不返回 */
        au_destroy(ctx);

        /* 无效新版会让 CreateProcess 失败；库应已把 .old 恢复为现役路径。 */
        wchar_t selfp[MAX_PATH]; _snwprintf(selfp, MAX_PATH, L"%s\\%s", dir, name); selfp[MAX_PATH-1]=0;
        au_err_t expected = scenario == 1 ? AU_ERR_REPLACE :
                            scenario == 3 ? AU_ERR_EXTRACT : AU_ERR_LAUNCH;
        int rollback_ok = e == expected &&
                          GetFileAttributesW(selfp) != INVALID_FILE_ATTRIBUTES &&
                          GetFileAttributesW(oldp) == INVALID_FILE_ATTRIBUTES;
        const char* label = scenario == 1 ? "move rollback" :
                            scenario == 2 ? "zip launch rollback" :
                            scenario == 3 ? "zip dir-main rejection" : "launch rollback";
        f = _wfopen(resp, L"a");
        if (f) {
            fprintf(f, "%s %s rc=%d\n", label, rollback_ok ? "ok" : "failed", (int)e);
            fclose(f);
        }
        return rollback_ok ? 0 : 3;
    }
#endif
    return 0;
}
