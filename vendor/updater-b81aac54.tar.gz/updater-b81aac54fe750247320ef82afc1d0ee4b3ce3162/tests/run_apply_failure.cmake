# 工作目录严格位于本次构建目录，避免接触实际安装目录。
get_filename_component(root "${ROOT}" REALPATH)
set(work "${root}/apply_failure_work")
if(NOT IS_ABSOLUTE "${root}" OR NOT EXISTS "${root}/CMakeCache.txt")
  message(FATAL_ERROR "invalid test build root")
endif()
file(MAKE_DIRECTORY "${work}")
include("${CMAKE_CURRENT_LIST_DIR}/copy_test_runtime.cmake")
copy_test_runtime("${work}")
configure_file("${FIXTURE}" "${work}/app.exe" COPYONLY)
file(WRITE "${work}/invalid.autmp" "fixture: not a PE executable")
file(SHA256 "${work}/app.exe" before)
execute_process(
  COMMAND "${work}/app.exe" "${work}/invalid.autmp"
  WORKING_DIRECTORY "${work}"
  RESULT_VARIABLE result
  OUTPUT_VARIABLE output
  ERROR_VARIABLE error
  TIMEOUT 15
)
if(NOT result EQUAL 0)
  message(FATAL_ERROR "apply rollback failed (${result}): ${output}${error}")
endif()
file(SHA256 "${work}/app.exe" after)
if(NOT before STREQUAL after)
  message(FATAL_ERROR "original executable was not restored")
endif()
message(STATUS "apply rollback: PASS; ${output}")
