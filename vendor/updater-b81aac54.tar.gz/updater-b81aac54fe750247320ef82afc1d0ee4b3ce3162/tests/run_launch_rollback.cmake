# EXE 模式启动失败回滚：无效新版不能留在现役路径，.old 必须恢复。
include("${CMAKE_CURRENT_LIST_DIR}/copy_test_runtime.cmake")
set(work "${CMAKE_CURRENT_LIST_DIR}/../.launch_rollback_work")
file(REMOVE_RECURSE "${work}")
file(MAKE_DIRECTORY "${work}")
copy_test_runtime("${work}")

configure_file("${V1}" "${work}/app.exe" COPYONLY)
file(SHA256 "${V1}" expected_hash)
file(WRITE "${work}/app.exe.autmp" "not a valid Windows executable")

execute_process(
  COMMAND "${work}/app.exe"
  WORKING_DIRECTORY "${work}"
  RESULT_VARIABLE result
  TIMEOUT 30
)

if(NOT result EQUAL 0)
  message(FATAL_ERROR "launch rollback fixture failed with ${result}")
endif()
if(NOT EXISTS "${work}/app.exe")
  message(FATAL_ERROR "launch rollback removed the active executable")
endif()
if(EXISTS "${work}/app.exe.old")
  message(FATAL_ERROR "launch rollback left app.exe.old instead of restoring it")
endif()

file(SHA256 "${work}/app.exe" actual_hash)
if(NOT actual_hash STREQUAL expected_hash)
  message(FATAL_ERROR "launch rollback did not restore the original executable")
endif()

file(READ "${work}/result.txt" content)
if(NOT content MATCHES "launch rollback ok")
  message(FATAL_ERROR "fixture did not observe a successful rollback. result.txt=\n${content}")
endif()

message(STATUS "launch rollback: PASS")
file(REMOVE_RECURSE "${work}")
