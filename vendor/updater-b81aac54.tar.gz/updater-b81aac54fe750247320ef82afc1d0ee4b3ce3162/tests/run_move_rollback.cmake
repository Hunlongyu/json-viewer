# EXE 模式包移动失败：self 已改名为 .old 后，必须检查并完成回滚。
include("${CMAKE_CURRENT_LIST_DIR}/copy_test_runtime.cmake")
set(work "${CMAKE_CURRENT_LIST_DIR}/../.move_rollback_work")
file(REMOVE_RECURSE "${work}")
file(MAKE_DIRECTORY "${work}")
copy_test_runtime("${work}")
configure_file("${V1}" "${work}/app.exe" COPYONLY)
file(SHA256 "${V1}" expected_hash)

execute_process(
  COMMAND "${work}/app.exe" --test-move-failure
  WORKING_DIRECTORY "${work}"
  RESULT_VARIABLE result
  TIMEOUT 30
)
if(NOT result EQUAL 0)
  message(FATAL_ERROR "move rollback fixture failed with ${result}")
endif()
if(NOT EXISTS "${work}/app.exe" OR EXISTS "${work}/app.exe.old")
  message(FATAL_ERROR "move rollback did not restore exactly one active executable")
endif()
file(SHA256 "${work}/app.exe" actual_hash)
if(NOT actual_hash STREQUAL expected_hash)
  message(FATAL_ERROR "move rollback changed the original executable")
endif()
file(READ "${work}/result.txt" content)
if(NOT content MATCHES "move rollback ok")
  message(FATAL_ERROR "fixture did not observe move rollback. result.txt=\n${content}")
endif()
message(STATUS "move rollback: PASS")
file(REMOVE_RECURSE "${work}")
