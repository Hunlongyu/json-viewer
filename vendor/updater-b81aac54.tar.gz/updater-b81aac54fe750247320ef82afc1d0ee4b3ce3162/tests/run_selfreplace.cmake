# 自替换端到端测试驱动。由 CTest 以 -DV1=... -DV2=... 调用。
# 布置一个工作目录：app.exe(=v1) + app.exe.autmp(=v2)，运行 app.exe，
# 断言它自更新为 v2、.old 被清理、result.txt 记录了 v1→v2 两次运行。

include("${CMAKE_CURRENT_LIST_DIR}/copy_test_runtime.cmake")

set(work "${CMAKE_CURRENT_LIST_DIR}/../.selfreplace_work")
file(REMOVE_RECURSE "${work}")
file(MAKE_DIRECTORY "${work}")
copy_test_runtime("${work}")

configure_file("${V1}" "${work}/app.exe" COPYONLY)
configure_file("${V2}" "${work}/app.exe.autmp" COPYONLY)

execute_process(
  COMMAND "${work}/app.exe"
  WORKING_DIRECTORY "${work}"
  TIMEOUT 30
)

# 轮询等待子进程写出 v2（最多 ~10s）。
set(ok FALSE)
foreach(i RANGE 100)
  if(EXISTS "${work}/result.txt")
    file(READ "${work}/result.txt" content)
    if(content MATCHES "running v2")
      set(ok TRUE)
      break()
    endif()
  endif()
  execute_process(COMMAND "${CMAKE_COMMAND}" -E sleep 0.1)
endforeach()

if(NOT ok)
  message(FATAL_ERROR "self-replace: v2 未在超时内运行。result.txt=\n${content}")
endif()
if(EXISTS "${work}/app.exe.old")
  message(FATAL_ERROR "self-replace: .old 未被清理")
endif()
if(NOT content MATCHES "running v1")
  message(FATAL_ERROR "self-replace: v1 未运行")
endif()

message(STATUS "self-replace: PASS")
file(REMOVE_RECURSE "${work}")
