# ZIP 模式：覆盖后启动失败应恢复旧主程序；主程序为目录应在替换前拒绝。
include("${CMAKE_CURRENT_LIST_DIR}/copy_test_runtime.cmake")
get_filename_component(tar_dir "$ENV{SystemRoot}/System32" ABSOLUTE)
set(tar "${tar_dir}/tar.exe")

function(run_zip_case name argument make_directory expected_text)
  set(work "${CMAKE_CURRENT_LIST_DIR}/../.${name}_work")
  file(REMOVE_RECURSE "${work}")
  file(MAKE_DIRECTORY "${work}/payload")
  copy_test_runtime("${work}")
  configure_file("${V1}" "${work}/app.exe" COPYONLY)
  file(SHA256 "${V1}" expected_hash)
  if(make_directory)
    file(MAKE_DIRECTORY "${work}/payload/app.exe")
    file(WRITE "${work}/payload/app.exe/inside.txt" "not an executable")
  else()
    file(WRITE "${work}/payload/app.exe" "not a valid Windows executable")
  endif()
  execute_process(
    COMMAND "${tar}" --format zip -cf "${work}/app.exe.autmp" -C "${work}/payload" .
    RESULT_VARIABLE archive_result
  )
  if(NOT archive_result EQUAL 0)
    message(FATAL_ERROR "${name}: could not create ZIP (${archive_result})")
  endif()
  execute_process(
    COMMAND "${work}/app.exe" "${argument}"
    WORKING_DIRECTORY "${work}"
    RESULT_VARIABLE result
    TIMEOUT 30
  )
  if(NOT result EQUAL 0)
    message(FATAL_ERROR "${name}: fixture failed with ${result}")
  endif()
  if(NOT EXISTS "${work}/app.exe" OR EXISTS "${work}/app.exe.old")
    message(FATAL_ERROR "${name}: active executable was not restored")
  endif()
  file(SHA256 "${work}/app.exe" actual_hash)
  if(NOT actual_hash STREQUAL expected_hash)
    message(FATAL_ERROR "${name}: original executable hash changed")
  endif()
  file(READ "${work}/result.txt" content)
  if(NOT content MATCHES "${expected_text}")
    message(FATAL_ERROR "${name}: expected result missing. result.txt=\n${content}")
  endif()
  file(REMOVE_RECURSE "${work}")
endfunction()

run_zip_case("zip_launch_rollback" "--test-zip-launch-failure" FALSE "zip launch rollback ok")
run_zip_case("zip_dir_main" "--test-zip-dir-main" TRUE "zip dir-main rejection ok")
message(STATUS "ZIP failure handling: PASS")
