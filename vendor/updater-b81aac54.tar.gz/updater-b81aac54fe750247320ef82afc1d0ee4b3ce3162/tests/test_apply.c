/* 只在 CTest 创建的隔离目录中运行，验证失败的 EXE 更新能保留原程序。 */
#include "au_internal.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

int main(int argc, char** argv) {
    SetErrorMode(SEM_FAILCRITICALERRORS | SEM_NOGPFAULTERRORBOX);
    if (argc != 2) return 2;
    wchar_t* self = au_self_path();
    if (!self) return 3;
    char before[65], after[65];
    if (au_sha256_file(self, before) != AU_OK) { free(self); return 4; }
    au_config_t cfg = {0};
    cfg.owner = "fixture"; cfg.repo = "fixture"; cfg.current_version = "1.0.0";
    cfg.asset_pattern = "app.exe"; cfg.mode = AU_MODE_EXE;
    au_ctx_t* ctx = au_create(&cfg);
    if (!ctx) { free(self); return 5; }
    au_err_t rc = au_apply(ctx, argv[1]);
    int restored = au_sha256_file(self, after) == AU_OK && !strcmp(before, after);
    wchar_t old[MAX_PATH]; swprintf(old, MAX_PATH, L"%ls.old", self);
    int backup_left = au_file_exists(old);
    au_destroy(ctx); free(self);
    printf("apply=%s restored=%d backup_left=%d\n", au_strerror(rc), restored, backup_left);
    return rc == AU_ERR_LAUNCH && restored && !backup_left ? 0 : 1;
}
