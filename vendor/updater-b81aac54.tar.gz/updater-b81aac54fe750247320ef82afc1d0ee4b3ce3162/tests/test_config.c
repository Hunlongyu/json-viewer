/* 配置边界与指针/计数一致性测试。 */
#include "au_internal.h"
#include <stdio.h>
#include <string.h>

static int g_fail = 0;
#define CHECK(cond, ...) do { if (!(cond)) { \
    printf("FAIL %s:%d  ", __FILE__, __LINE__); printf(__VA_ARGS__); printf("\n"); g_fail++; } } while (0)

static au_config_t base_config(void) {
    au_config_t c;
    memset(&c, 0, sizeof c);
    c.owner = "o"; c.repo = "r"; c.current_version = "1.2.3";
    c.asset_pattern = "app.exe"; c.mode = AU_MODE_EXE;
    return c;
}

static void expect_invalid(au_config_t* cfg, const char* name) {
    au_ctx_t* ctx = au_create(cfg);
    CHECK(ctx == NULL, "%s rejected", name);
    au_destroy(ctx);
}

int main(void) {
    au_config_t c = base_config();
    au_ctx_t* ctx = au_create(&c);
    CHECK(ctx != NULL, "minimal valid config accepted");
    if (ctx) {
        CHECK(au_apply(ctx, "") == AU_ERR_ARG, "empty package path rejected before mutation");
        au_wait_for_predecessor(1, NULL, 0);
        au_wait_for_predecessor_w(1, NULL, 0);
    }
    au_destroy(ctx);

    c = base_config(); c.mode = (au_mode_t)99; expect_invalid(&c, "unknown mode");
    c = base_config(); c.channel = (au_channel_t)99; expect_invalid(&c, "unknown channel");
    c = base_config(); c.owner = ""; expect_invalid(&c, "empty owner");
    c = base_config(); c.user_agent = "ok\r\nInjected: yes"; expect_invalid(&c, "UA CRLF");
    c = base_config(); c.token = "secret\nInjected: yes"; expect_invalid(&c, "token CRLF");
    c = base_config(); c.retry_max = 101; expect_invalid(&c, "excessive retry count");
    c = base_config(); c.retry_max = -1; expect_invalid(&c, "negative retry count");
    c = base_config(); c.timeout_ms = -1; expect_invalid(&c, "negative timeout");
    c = base_config(); c.installer_args = "\xF0\x9F"; expect_invalid(&c, "invalid UTF-8");

    c = base_config(); c.mirror_count = 1; expect_invalid(&c, "mirror count without array");
    {
        const char* mirrors[] = { NULL };
        c = base_config(); c.mirrors = mirrors; c.mirror_count = 1;
        expect_invalid(&c, "null mirror entry");
    }
    {
        const char* mirrors[] = { "{url}" };
        c = base_config(); c.mirrors = mirrors;
        expect_invalid(&c, "mirror array without count");
        c.mirror_count = 1;
        ctx = au_create(&c);
        CHECK(ctx != NULL, "valid custom mirror accepted");
        au_destroy(ctx);
    }

    c = base_config(); c.zip_exclude_count = 1; expect_invalid(&c, "exclude count without array");
    {
        const char* excludes[] = { NULL };
        c = base_config(); c.zip_exclude = excludes; c.zip_exclude_count = 1;
        expect_invalid(&c, "null exclude entry");
    }
    {
        const char* excludes[] = { "settings.ini" };
        c = base_config(); c.zip_exclude = excludes;
        expect_invalid(&c, "exclude array without count");
        c.zip_exclude_count = 1;
        ctx = au_create(&c);
        CHECK(ctx != NULL, "valid exclude accepted");
        au_destroy(ctx);
    }

    if (g_fail == 0) printf("test_config: ALL PASS\n");
    else printf("test_config: %d FAILED\n", g_fail);
    return g_fail ? 1 : 0;
}
