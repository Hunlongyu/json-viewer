/* GitHub 响应解析与 release 选择的离线测试。喂内嵌 fixture JSON，不碰网络。 */
#include "au_internal.h"
#include <stdio.h>
#include <string.h>

static int g_fail = 0;
#define CHECK(cond, ...) do { if (!(cond)) { \
    printf("FAIL %s:%d  ", __FILE__, __LINE__); printf(__VA_ARGS__); printf("\n"); g_fail++; } } while (0)

static au_ctx_t* make_ctx(au_channel_t ch) {
    au_config_t cfg; memset(&cfg, 0, sizeof cfg);
    cfg.owner="o"; cfg.repo="r"; cfg.current_version="v1.0.0";
    cfg.asset_pattern="*"; cfg.mode=AU_MODE_EXE; cfg.channel=ch;
    return au_create(&cfg);
}

/* 列表按 created_at 排序，版本号乱序：热修 v1.0.1 排在 v1.1.0 前。
 * 正确行为是取 v1.1.0（版本号最大），而非列表首项 v1.0.1。 */
static const char* FIX_DOWNGRADE =
"[{\"tag_name\":\"v1.0.1\",\"prerelease\":false,\"draft\":false,\"body\":\"hotfix\",\"assets\":[]},"
" {\"tag_name\":\"v1.1.0\",\"prerelease\":false,\"draft\":false,\"body\":\"feature\",\"assets\":[]}]";

/* body 内含字面 "tag_name":，会骗过 strstr 截取方案。真实 tag 在 tag_name 字段。 */
static const char* FIX_TRAP_BODY =
"[{\"tag_name\":\"v2.0.0\",\"prerelease\":false,\"draft\":false,"
"  \"body\":\"see \\\"tag_name\\\": v9.9.9 in old logs\\nline2\",\"assets\":[]}]";

/* draft + prerelease 混合：stable 应取 v1.2.0；beta 应取 v1.3.0-beta.1；draft v9 永不选。 */
static const char* FIX_MIXED =
"[{\"tag_name\":\"v9.9.9\",\"prerelease\":false,\"draft\":true,\"body\":\"draft\",\"assets\":[]},"
" {\"tag_name\":\"v1.3.0-beta.1\",\"prerelease\":true,\"draft\":false,\"body\":\"beta\",\"assets\":[]},"
" {\"tag_name\":\"v1.2.0\",\"prerelease\":false,\"draft\":false,\"body\":\"stable\",\"assets\":[]}]";

/* digest 为 null 的老 release + 正常 asset。 */
static const char* FIX_ASSETS =
"[{\"tag_name\":\"v3.0.0\",\"prerelease\":false,\"draft\":false,\"body\":\"\",\"assets\":["
"  {\"name\":\"hua-v3.0.0-x64.exe\",\"browser_download_url\":\"https://x/e.exe\",\"size\":12345,"
"   \"digest\":\"sha256:abcdef\"},"
"  {\"name\":\"hua-v3.0.0-win-x64.zip\",\"browser_download_url\":\"https://x/z.zip\",\"size\":999,"
"   \"digest\":null}]}]";

static const char* FIX_BAD_SIZES =
"[{\"tag_name\":\"v4.0.0\",\"prerelease\":false,\"draft\":false,\"assets\":["
" {\"name\":\"negative.exe\",\"browser_download_url\":\"https://x/n\",\"size\":-1},"
" {\"name\":\"fraction.exe\",\"browser_download_url\":\"https://x/f\",\"size\":1.5},"
" {\"name\":\"huge.exe\",\"browser_download_url\":\"https://x/h\",\"size\":1e100}]}]";

int main(void) {
    au_ctx_t* ctx = make_ctx(AU_CHANNEL_STABLE);
    au_release_t* r = NULL;

    /* 降级陷阱 */
    CHECK(au_select_best_from_json(ctx, FIX_DOWNGRADE, strlen(FIX_DOWNGRADE), &r) == AU_OK, "downgrade parse");
    CHECK(r && strcmp(r->ver.raw, "v1.1.0") == 0, "picked v1.1.0 not first-in-list (%s)", r?r->ver.raw:"null");
    au_release_free(r); r = NULL;

    /* body 陷阱 */
    CHECK(au_select_best_from_json(ctx, FIX_TRAP_BODY, strlen(FIX_TRAP_BODY), &r) == AU_OK, "trap parse");
    CHECK(r && strcmp(r->ver.raw, "v2.0.0") == 0, "tag from field not body (%s)", r?r->ver.raw:"null");
    /* body 反转义：应含真实换行与引号，不含 \\n 字面 */
    CHECK(r && r->changelog && strstr(r->changelog, "\n") && strchr(r->changelog, '"'), "body unescaped");
    au_release_free(r); r = NULL;

    /* 混合：stable 取 v1.2.0（draft/beta 都排除） */
    CHECK(au_select_best_from_json(ctx, FIX_MIXED, strlen(FIX_MIXED), &r) == AU_OK, "mixed stable parse");
    CHECK(r && strcmp(r->ver.raw, "v1.2.0") == 0, "stable picks v1.2.0 (%s)", r?r->ver.raw:"null");
    au_release_free(r); r = NULL;

    CHECK(au_select_best_from_json(ctx, FIX_BAD_SIZES, strlen(FIX_BAD_SIZES), &r) == AU_OK,
          "out-of-range sizes parse without undefined conversion");
    CHECK(r && r->asset_count == 3, "bad-size fixture has 3 assets");
    if (r && r->asset_count == 3) {
        CHECK(r->assets[0].size == 0, "negative size normalized to zero");
        CHECK(r->assets[1].size == 0, "fractional size normalized to zero");
        CHECK(r->assets[2].size == 0, "oversized size normalized to zero");
    }
    au_release_free(r); r = NULL;
    au_destroy(ctx);

    /* 混合：beta 取 v1.3.0-beta.1（draft 仍排除） */
    ctx = make_ctx(AU_CHANNEL_BETA);
    CHECK(au_select_best_from_json(ctx, FIX_MIXED, strlen(FIX_MIXED), &r) == AU_OK, "mixed beta parse");
    CHECK(r && strcmp(r->ver.raw, "v1.3.0-beta.1") == 0, "beta picks v1.3.0-beta.1 (%s)", r?r->ver.raw:"null");
    au_release_free(r); r = NULL;

    /* asset 解析：digest 剥前缀、null digest 容忍、glob 选择、多重匹配返回 NULL */
    CHECK(au_select_best_from_json(ctx, FIX_ASSETS, strlen(FIX_ASSETS), &r) == AU_OK, "assets parse");
    CHECK(r && r->asset_count == 2, "2 assets");
    const au_asset_t* exe = au_pick_asset(r, "hua-*-x64.exe");
    CHECK(exe && strcmp(exe->sha256, "abcdef") == 0, "digest prefix stripped");
    CHECK(exe && exe->size == 12345, "size parsed");
    const au_asset_t* zip = au_pick_asset(r, "*.zip");
    CHECK(zip && zip->sha256 == NULL, "null digest tolerated");
    CHECK(au_pick_asset(r, "hua-*") == NULL, "multi-match returns NULL");
    CHECK(au_pick_asset(r, "nope-*") == NULL, "no-match returns NULL");
    au_release_free(r); r = NULL;
    au_destroy(ctx);

    if (g_fail == 0) printf("test_gh: ALL PASS\n");
    else             printf("test_gh: %d FAILED\n", g_fail);
    return g_fail ? 1 : 0;
}
