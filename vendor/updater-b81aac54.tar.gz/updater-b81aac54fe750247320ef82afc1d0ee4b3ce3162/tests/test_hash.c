/* SHA-256 对拍：算一个已知内容文件，与 certutil 输出比对。 */
#include "au_internal.h"
#include <stdio.h>
#include <string.h>

static int malformed_digest_rejected(const char* digest) {
    au_config_t cfg;
    au_asset_t asset;
    char path[16];
    memset(&cfg, 0, sizeof cfg);
    cfg.owner="o"; cfg.repo="r"; cfg.current_version="1.0.0";
    cfg.asset_pattern="*"; cfg.mode=AU_MODE_EXE;
    au_ctx_t* ctx = au_create(&cfg);
    memset(&asset, 0, sizeof asset);
    asset.name="ignored.exe"; asset.url="https://127.0.0.1/never-sent"; asset.sha256=(char*)digest;
    au_err_t rc = au_download(ctx, &asset, path, sizeof path);
    au_destroy(ctx);
    return rc == AU_ERR_HASH;
}

int main(void) {
    int bad = 0;
    bad += !au_sha256_hex_valid("ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad");
    bad += !au_sha256_hex_valid("BA7816BF8F01CFEA414140DE5DAE2223B00361A396177A9CB410FF61F20015AD");
    bad += au_sha256_hex_valid("abc");
    bad += au_sha256_hex_valid("ga7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad");
    bad += au_sha256_hex_valid(NULL);
    bad += !malformed_digest_rejected("abc");
    bad += !malformed_digest_rejected("");
    bad += au_sha256_file(NULL, (char[65]){0}) != AU_ERR_ARG;
    bad += au_sha256_file(L"ignored", NULL) != AU_ERR_ARG;
    wchar_t tmp[MAX_PATH]; if (!GetTempPathW(MAX_PATH, tmp)) wcscpy(tmp, L".\\");
    wchar_t path[MAX_PATH];
    _snwprintf(path, MAX_PATH, L"%lsau_hashtest.bin", tmp);
    path[MAX_PATH - 1] = L'\0';
    FILE* f = _wfopen(path, L"wb");
    if (!f) { printf("test_hash: cannot create temp\n"); return 1; }
    /* "abc" 的 SHA-256 是已知常量。 */
    fputs("abc", f);
    fclose(f);

    char hex[65];
    au_err_t e = au_sha256_file(path, hex);
    DeleteFileW(path);

    const char* expect = "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad";
    if (!bad && e == AU_OK && strcmp(hex, expect) == 0) {
        printf("test_hash: ALL PASS\n");
        return 0;
    }
    printf("test_hash: FAILED (got %s)\n", e==AU_OK?hex:au_strerror(e));
    return 1;
}
