/* HTTP 请求头的离线安全测试：token 目标限制与超长配置。 */
#include "au_internal.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <wchar.h>

static int g_fail = 0;
#define CHECK(cond, ...) do { if (!(cond)) { \
    printf("FAIL %s:%d  ", __FILE__, __LINE__); printf(__VA_ARGS__); printf("\n"); g_fail++; } } while (0)

static au_ctx_t* make_ctx(const char* user_agent) {
    au_config_t cfg; memset(&cfg, 0, sizeof cfg);
    cfg.owner="o"; cfg.repo="r"; cfg.current_version="v1.0.0";
    cfg.asset_pattern="*"; cfg.mode=AU_MODE_EXE;
    cfg.user_agent=user_agent; cfg.token="secret-token";
    return au_create(&cfg);
}

static wchar_t* make_headers(au_ctx_t* ctx, const wchar_t* url, int is_api) {
    wchar_t* headers = NULL;
    CHECK(au_http_build_headers(ctx, url, is_api, 1, &headers) == AU_OK, "build headers");
    return headers;
}

static void header_policy(void) {
    au_ctx_t ctx = {0};
    char agent[2101]; memset(agent, 'a', sizeof agent - 1); agent[sizeof agent - 1] = 0;
    ctx.user_agent = agent; ctx.token = "review-dummy-token";
    wchar_t* headers = NULL;
    CHECK(au_http_build_headers(&ctx, L"https://api.github.com/repos/o/r/releases", 1, 1, &headers) == AU_OK,
          "long user agent accepted without truncation");
    CHECK(headers && wcslen(headers) > 2100 && wcsstr(headers, L"Authorization: Bearer review-dummy-token\r\n"),
          "complete headers");
    free(headers); headers = NULL;
    const wchar_t* untrusted[] = {
        L"http://api.github.com/releases", L"https://api.github.com.evil.invalid/releases",
        L"https://github.com:8443/releases", L"https://user@api.github.com/releases",
        L"https://ghfast.top/https://api.github.com/releases", L"http://127.0.0.1/releases"
    };
    for (size_t i = 0; i < sizeof untrusted / sizeof untrusted[0]; i++) {
        CHECK(!au_http_auth_allowed(untrusted[i]), "untrusted origin %zu", i);
        CHECK(au_http_build_headers(&ctx, untrusted[i], 1, 1, &headers) == AU_OK, "anonymous headers %zu", i);
        CHECK(headers && !wcsstr(headers, L"Authorization:"), "token omitted %zu", i);
        free(headers); headers = NULL;
    }
    CHECK(au_http_auth_allowed(L"https://API.GITHUB.COM:443/releases"), "canonical HTTPS origin");
    CHECK(au_http_build_headers(&ctx, L"https://github.com/download", 0, 0, &headers) == AU_OK &&
          headers && !wcsstr(headers, L"Authorization:"), "cross-origin redirect cannot regain token");
    free(headers); headers = NULL;
    ctx.user_agent = "agent\r\nAuthorization: injected";
    CHECK(au_http_build_headers(&ctx, L"https://api.github.com", 1, 1, &headers) == AU_ERR_ARG,
          "reject user-agent header injection");
    ctx.user_agent = "agent"; ctx.token = "token\nOther: injected";
    CHECK(au_http_build_headers(&ctx, L"https://api.github.com", 1, 1, &headers) == AU_ERR_ARG,
          "reject token header injection");
}

static void redirect_policy(void) {
    wchar_t* next = NULL; int keep = 0;
    CHECK(au_http_redirect_url(L"https://api.github.com/a/b", L"/new?x=1#fragment", &next, &keep) == AU_OK &&
          next && !wcscmp(next, L"https://api.github.com/new?x=1") && keep, "root relative redirect");
    free(next); next = NULL;
    CHECK(au_http_redirect_url(L"https://api.github.com/a/b", L"../c?path=../value", &next, &keep) == AU_OK &&
          next && !wcscmp(next, L"https://api.github.com/c?path=../value") && keep, "dot segments preserve query");
    free(next); next = NULL;
    CHECK(au_http_redirect_url(L"https://api.github.com/a/b", L"/a/..", &next, &keep) == AU_OK &&
          next && !wcscmp(next, L"https://api.github.com/"), "parent segment at path end");
    free(next); next = NULL;
    CHECK(au_http_redirect_url(L"https://api.github.com/a/b", L"c?x=1", &next, &keep) == AU_OK &&
          next && !wcscmp(next, L"https://api.github.com/a/c?x=1") && keep, "path relative redirect");
    free(next); next = NULL;
    CHECK(au_http_redirect_url(L"https://api.github.com/a", L"//github.com/b", &next, &keep) == AU_OK &&
          next && !wcscmp(next, L"https://github.com/b") && !keep, "cross-host drops auth");
    free(next); next = NULL;
    CHECK(au_http_redirect_url(L"https://api.github.com/a", L"http://api.github.com/b", &next, &keep) == AU_ERR_HTTP,
          "HTTPS downgrade rejected");
    CHECK(au_http_redirect_url(L"https://api.github.com/a", L"https://u@api.github.com/b", &next, &keep) == AU_ERR_HTTP,
          "redirect userinfo rejected");

}

int main(void) {
    header_policy();
    redirect_policy();
    wchar_t* target = au_http_request_target(
        L"https://api.github.com/repos/o/r/releases?per_page=100");
    CHECK(target && wcscmp(target, L"/repos/o/r/releases?per_page=100") == 0,
          "request target preserves query string");
    free(target);

    au_ctx_t* ctx = make_ctx("HeaderSafetyTest/1.0");
    CHECK(ctx != NULL, "context created");

    wchar_t* h = make_headers(ctx, L"https://api.github.com/", 1);
    CHECK(h && wcsstr(h, L"Authorization: Bearer secret-token\r\n"),
          "token sent to direct GitHub API");
    free(h);

    h = make_headers(ctx, L"https://gh-proxy.com/", 1);
    CHECK(h && !wcsstr(h, L"Authorization:"), "token withheld from API mirror");
    CHECK(h && wcsstr(h, L"Accept: application/vnd.github+json"),
          "mirror still receives required API headers");
    free(h);

    h = make_headers(ctx, L"https://api.github.com/", 0);
    CHECK(h && !wcsstr(h, L"Authorization:"), "token withheld from non-API download");
    free(h);
    au_destroy(ctx);

    ctx = make_ctx("HeaderSafetyTest/1.0");
    char* body = NULL; size_t body_len = 0;
    CHECK(au_http_get_file(ctx, L"https://127.0.0.1/never-sent", NULL, NULL) == AU_ERR_ARG,
          "null file handle rejected before network access");
    CHECK(au_http_get_mem_web(ctx, L"http://127.0.0.1/never-sent", &body, &body_len, NULL)
              == AU_ERR_ARG,
          "plain HTTP rejected before network access");
    free(body);
    au_destroy(ctx);

    /* 旧实现的 2048 字节栈缓冲会在随后追加 API 头时越界。 */
    const size_t ua_len = 8192;
    char* long_ua = (char*)malloc(ua_len + 1);
    CHECK(long_ua != NULL, "long user-agent allocated");
    if (long_ua) {
        memset(long_ua, 'A', ua_len);
        long_ua[ua_len] = '\0';
        ctx = make_ctx(long_ua);
        free(long_ua);  /* 验证 au_create 的深拷贝也参与该路径。 */
        CHECK(ctx != NULL, "long user-agent context created");
        if (ctx) {
            h = make_headers(ctx, L"https://api.github.com/", 1);
            CHECK(h && wcslen(h) > ua_len, "long headers built without truncation/overflow");
            CHECK(h && wcsstr(h, L"Authorization: Bearer secret-token"),
                  "authorization retained after long user-agent");
            free(h);
            au_destroy(ctx);
        }
    }

    if (g_fail == 0) printf("test_http: ALL PASS\n");
    else             printf("test_http: %d FAILED\n", g_fail);
    return g_fail ? 1 : 0;
}
