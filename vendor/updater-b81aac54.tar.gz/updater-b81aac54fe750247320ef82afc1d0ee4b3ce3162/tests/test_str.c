/* glob 与 UTF-8↔UTF-16 单测。 */
#include "au_internal.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int g_fail = 0;
#define CHECK(cond, ...) do { if (!(cond)) { \
    printf("FAIL %s:%d  ", __FILE__, __LINE__); printf(__VA_ARGS__); printf("\n"); g_fail++; } } while (0)

static int roundtrip(const char* s) {
    wchar_t* w = au_utf8_to_wide(s);
    if (!w) return 0;
    char* back = au_wide_to_utf8(w);
    int ok = back && strcmp(s, back) == 0;
    free(w); free(back);
    return ok;
}

static char captured[1024];
static void capture_log(au_log_level_t lv, const char* msg, void* userdata) {
    (void)lv; (void)userdata;
    strncpy(captured, msg ? msg : "", sizeof captured - 1);
    captured[sizeof captured - 1] = '\0';
}

int main(void) {
    /* ---- glob ---- */
    CHECK(au_glob_match("hua-*-x64.exe", "hua-v1.2.3-x64.exe"), "star match");
    CHECK(!au_glob_match("hua-*-x64.exe", "hua-v1.2.3-arm64.exe"), "arch mismatch");
    CHECK(au_glob_match("*.zip", "hua.zip"), "leading star");
    CHECK(au_glob_match("hua-?.?.?-x64.exe", "hua-1.2.3-x64.exe"), "question marks");
    CHECK(au_glob_match("*", "anything"), "bare star");
    CHECK(au_glob_match("exact", "EXACT"), "case-insensitive");
    CHECK(!au_glob_match("hua-*.exe", "hua-1.2.3.zip"), "ext mismatch");
    CHECK(au_glob_match("a*b*c", "axxbyyc"), "multi star");
    CHECK(!au_glob_match("a*b*c", "axxbyy"), "multi star fail");
    CHECK(au_glob_match("hua*setup*.exe", "hua-1.2.3-setup-x64.exe"), "installer pattern");

    /* ---- UTF-8 往返 ---- */
    CHECK(roundtrip("ascii-only"), "ascii");
    CHECK(roundtrip("中文测试"), "chinese");
    CHECK(roundtrip("emoji \xF0\x9F\x9A\x80 rocket"), "emoji surrogate");  /* U+1F680 */
    CHECK(roundtrip(""), "empty");
    CHECK(roundtrip("mix 中 a \xF0\x9F\x8E\x89 b"), "mixed");
    CHECK(au_utf8_to_wide("\xF0\x9F") == NULL, "truncated UTF-8 rejected");
    {
        wchar_t lone_surrogate[] = { (wchar_t)0xD800, L'\0' };
        CHECK(au_wide_to_utf8(lone_surrogate) == NULL, "lone UTF-16 surrogate rejected");
    }

    /* vsnprintf 在无法把非法宽字符编码为当前窄字符集时可返回负数。 */
    au_config_t cfg; memset(&cfg, 0, sizeof cfg);
    cfg.owner="o"; cfg.repo="r"; cfg.current_version="1.0.0";
    cfg.asset_pattern="*"; cfg.mode=AU_MODE_EXE; cfg.on_log=capture_log;
    au_ctx_t* ctx = au_create(&cfg);
    wchar_t invalid_wide[] = { (wchar_t)0xD800, L'\0' };
    captured[0] = '\0';
    au_logf(ctx, AU_LOG_ERROR, "bad wide: %ls", invalid_wide);
    CHECK(strcmp(captured, "log formatting failed") == 0,
          "format failure emits deterministic initialized fallback log");
    au_destroy(ctx);

    if (g_fail == 0) printf("test_str: ALL PASS\n");
    else             printf("test_str: %d FAILED\n", g_fail);
    return g_fail ? 1 : 0;
}
