/* 使用离线传输替身验证分页与下载编排，不放宽生产库的 HTTPS 和直连约束。 */
#include "au_internal.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <wchar.h>

static int failures;
#define CHECK(cond, ...) do { if (!(cond)) { \
    printf("FAIL %s:%d ", __FILE__, __LINE__); printf(__VA_ARGS__); puts(""); failures++; } } while (0)

typedef struct {
    au_err_t result;
    int next_page;
    const char* body;
    int cancel;
} reply_t;

static reply_t replies[8];
static int reply_count, request_count, fallback_count, download_count;
static wchar_t request_urls[8][256], download_url[512];
static au_err_t download_result;
static const char* stable = "[{\"tag_name\":\"v1.5.0\",\"prerelease\":false,\"assets\":[]}]";

static void reset_transport(void) {
    memset(replies, 0, sizeof replies);
    memset(request_urls, 0, sizeof request_urls);
    reply_count = request_count = fallback_count = download_count = 0;
    download_result = AU_OK;
    download_url[0] = L'\0';
}

au_err_t au_http_get_mem(au_ctx_t* ctx, const wchar_t* url,
                         char** out, size_t* len, au_http_meta* meta) {
    *out = NULL; *len = 0;
    CHECK(request_count < reply_count, "unexpected metadata request");
    if (request_count >= reply_count) return AU_ERR_STATE;
    swprintf(request_urls[request_count], 256, L"%ls", url);
    CHECK(wcsstr(url, L"https://api.github.com/repos/fixture/fixture/releases?") == url,
          "metadata uses official HTTPS regardless of asset mirrors");
    const reply_t* reply = &replies[request_count++];
    memset(meta, 0, sizeof *meta);
    meta->has_next_page = reply->next_page;
    if (reply->cancel) au_cancel(ctx);
    if (reply->result != AU_OK) return reply->result;
    *out = au_strdup(reply->body ? reply->body : "");
    if (!*out) return AU_ERR_NOMEM;
    *len = strlen(*out);
    return AU_OK;
}

au_err_t au_fetch_web_fallback(au_ctx_t* ctx, au_release_t** out) {
    (void)ctx;
    fallback_count++;
    *out = NULL;
    return AU_ERR_RATELIMIT;
}

au_err_t au_http_get_file(au_ctx_t* ctx, const wchar_t* url, HANDLE file, au_http_meta* meta) {
    (void)meta;
    download_count++;
    swprintf(download_url, 512, L"%ls", url);
    if (download_result != AU_OK) return download_result;
    DWORD written = 0;
    if (!WriteFile(file, "abc", 3, &written, NULL) || written != 3) return AU_ERR_IO;
    if (ctx->on_progress && ctx->on_progress(3, 3, ctx->userdata)) return AU_ERR_CANCELED;
    return au_is_canceled(ctx) ? AU_ERR_CANCELED : AU_OK;
}

static au_ctx_t* context(void) {
    const char* mirrors[] = {"https://mirror.example/{url}", "{url}"};
    au_config_t cfg = {0};
    cfg.owner = "fixture"; cfg.repo = "fixture"; cfg.current_version = "1.0.0";
    cfg.asset_pattern = "app.exe"; cfg.mode = AU_MODE_EXE;
    cfg.mirrors = mirrors; cfg.mirror_count = 2;
    au_ctx_t* ctx = au_create(&cfg);
    CHECK(ctx != NULL, "context created");
    return ctx;
}

static void pagination(void) {
    char page[16000]; size_t used = 0;
    page[used++] = '[';
    for (int i = 0; i < 100; i++)
        used += (size_t)snprintf(page + used, sizeof page - used,
            "%s{\"tag_name\":\"v2.0.0-beta.%d\",\"prerelease\":true,\"assets\":[]}", i ? "," : "", i);
    strcpy(page + used, "]");
    reset_transport(); reply_count = 2;
    replies[0] = (reply_t){AU_OK, 0, page, 0};
    replies[1] = (reply_t){AU_OK, 0, stable, 0};
    au_ctx_t* ctx = context(); au_release_t* rel = NULL;
    CHECK(au_fetch_latest(ctx, &rel) == AU_OK && rel && !strcmp(rel->ver.raw, "v1.5.0"),
          "stable after full page of prereleases without Link header");
    CHECK(request_count == 2 && wcsstr(request_urls[0], L"per_page=100&page=1") &&
          wcsstr(request_urls[1], L"per_page=100&page=2"), "page number advances");
    au_release_free(rel); au_destroy(ctx);

    reset_transport(); reply_count = 2;
    replies[0] = (reply_t){AU_OK, 1, "[{\"tag_name\":\"v9.0.0\",\"assets\":[]}]", 0};
    replies[1] = (reply_t){AU_OK, 0, stable, 0};
    ctx = context(); rel = NULL;
    CHECK(au_fetch_latest(ctx, &rel) == AU_OK && rel && !strcmp(rel->ver.raw, "v9.0.0"),
          "maximum version across pages");
    CHECK(request_count == 2, "Link advances even a short page");
    au_release_free(rel); au_destroy(ctx);

    reset_transport(); reply_count = 2;
    replies[0] = (reply_t){AU_OK, 1, stable, 0};
    replies[1] = (reply_t){AU_OK, 0, "invalid json", 0};
    ctx = context(); rel = NULL;
    CHECK(au_fetch_latest(ctx, &rel) == AU_ERR_PARSE && !rel, "later parse failure discards partial result");
    au_release_free(rel); au_destroy(ctx);

    reset_transport(); reply_count = 2;
    replies[0] = (reply_t){AU_OK, 1, stable, 0};
    replies[1] = (reply_t){AU_ERR_RATELIMIT, 0, NULL, 0};
    ctx = context(); rel = NULL;
    CHECK(au_fetch_latest(ctx, &rel) == AU_ERR_RATELIMIT && !rel && !fallback_count,
          "later rate limit does not replace partial history with latest");
    au_release_free(rel); au_destroy(ctx);

    reset_transport(); reply_count = 1;
    replies[0] = (reply_t){AU_ERR_RATELIMIT, 0, NULL, 0};
    ctx = context(); rel = NULL;
    CHECK(au_fetch_latest(ctx, &rel) == AU_ERR_RATELIMIT && fallback_count == 1,
          "first-page rate limit can use web fallback");
    au_destroy(ctx);
}

typedef struct { au_ctx_t* ctx; int canceled; } progress_t;
static DWORD WINAPI cancel_worker(void* ctx) { au_cancel((au_ctx_t*)ctx); return 0; }
static int cancel_once(uint64_t total, uint64_t done, void* data) {
    (void)total; (void)done;
    progress_t* progress = (progress_t*)data;
    if (!progress->canceled) {
        HANDLE worker = CreateThread(NULL, 0, cancel_worker, progress->ctx, 0, NULL);
        CHECK(worker != NULL, "cancel worker started");
        if (worker) { WaitForSingleObject(worker, INFINITE); CloseHandle(worker); }
        progress->canceled = 1;
    }
    return 0;
}

static void remove_download(const char* path) {
    wchar_t* wide = au_utf8_to_wide(path);
    CHECK(wide && DeleteFileW(wide), "remove isolated test download");
    free(wide);
}

static void downloads_and_cancel(void) {
    reset_transport();
    au_ctx_t* ctx = context();
    progress_t progress = {ctx, 0};
    ctx->on_progress = cancel_once; ctx->userdata = &progress;
    char path[4096];
    au_asset_t asset = {"app.exe", "https://github.com/fixture/fixture/download.bin",
        "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad", 3};
    CHECK(au_download(ctx, &asset, path, sizeof path) == AU_ERR_CANCELED,
          "cross-thread cancel during transfer");
    CHECK(au_download(ctx, &asset, path, sizeof path) == AU_ERR_CANCELED && download_count == 1,
          "cancellation is retained without additional requests");
    au_reset_cancel(ctx);
    au_err_t rc = au_download(ctx, &asset, path, sizeof path);
    CHECK(rc == AU_OK && download_count == 2, "same context succeeds after reset");
    CHECK(wcsstr(download_url, L"https://mirror.example/") == download_url,
          "verified asset may use configured mirror");
    if (rc == AU_OK) remove_download(path);

    asset.sha256 = NULL;
    rc = au_download(ctx, &asset, path, sizeof path);
    CHECK(rc == AU_OK && wcscmp(download_url, L"https://github.com/fixture/fixture/download.bin") == 0,
          "missing digest bypasses mirrors");
    if (rc == AU_OK) remove_download(path);
    asset.sha256 = "invalid";
    int before = download_count;
    CHECK(au_download(ctx, &asset, path, sizeof path) == AU_ERR_HASH && download_count == before,
          "malformed digest never reaches transport");
    asset.sha256 = "ba7816bf8f01cfea414140de5dae2223b00361a396177a9cb410ff61f20015ad";
    download_result = AU_ERR_ARG;
    CHECK(au_download(ctx, &asset, path, sizeof path) == AU_ERR_ARG && download_count == before + 1,
          "invalid request is not retried on other mirrors");
    au_destroy(ctx);

    reset_transport(); reply_count = 2;
    replies[0] = (reply_t){AU_OK, 0, stable, 1};
    replies[1] = (reply_t){AU_OK, 0, stable, 0};
    ctx = context(); au_release_t* rel = NULL;
    CHECK(au_fetch_latest(ctx, &rel) == AU_ERR_CANCELED && !rel && request_count == 1,
          "canceled fetch does not return a result or retry");
    au_reset_cancel(ctx);
    CHECK(au_fetch_latest(ctx, &rel) == AU_OK && rel && request_count == 2, "fetch after reset");
    au_release_free(rel); au_destroy(ctx);
    au_reset_cancel(NULL);
}

int main(void) {
    pagination();
    downloads_and_cancel();
    printf("test_update_flow: %s\n", failures ? "FAILED" : "ALL PASS");
    return failures ? 1 : 0;
}
