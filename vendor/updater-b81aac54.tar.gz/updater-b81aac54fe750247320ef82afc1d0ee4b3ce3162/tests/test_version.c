/* 版本解析与比较单测。纯逻辑，无网络无 IO。 */
#include "win_autoupdate.h"
#include <stdio.h>
#include <string.h>

static int g_fail = 0;
#define CHECK(cond, ...) do { if (!(cond)) { \
    printf("FAIL %s:%d  ", __FILE__, __LINE__); printf(__VA_ARGS__); printf("\n"); g_fail++; } } while (0)

static int cmp(const char* a, const char* b) {
    au_version_t va, vb;
    if (au_version_parse(a, &va) != AU_OK) { printf("parse fail: %s\n", a); g_fail++; return 0; }
    if (au_version_parse(b, &vb) != AU_OK) { printf("parse fail: %s\n", b); g_fail++; return 0; }
    return au_version_cmp(&va, &vb);
}

int main(void) {
    /* ---- 解析 ---- */
    au_version_t v;
    CHECK(au_version_parse("v1.2.3", &v) == AU_OK && v.major==1 && v.minor==2 && v.patch==3
          && v.prerelease[0]=='\0', "v1.2.3");
    CHECK(au_version_parse("1.2.3", &v) == AU_OK && v.major==1, "1.2.3 no-v");
    CHECK(au_version_parse("v1.2.3-beta.1", &v) == AU_OK && strcmp(v.prerelease,"beta.1")==0, "beta");
    CHECK(au_version_parse("v1.2.3+build.5", &v) == AU_OK && v.prerelease[0]=='\0', "+build");
    CHECK(strcmp(v.raw, "v1.2.3+build.5")==0, "raw preserved");

    /* ---- 畸形输入：必须返回错误且不崩溃 ---- */
    CHECK(au_version_parse("", &v) == AU_ERR_ARG, "empty");
    CHECK(au_version_parse("abc", &v) == AU_ERR_ARG, "abc");
    const char* invalid[] = {
        "1.2", "1.2.3.4", "-1.2.3", "+1.2.3", "01.2.3", "1.02.3", "1.2.03",
        "1.2.3-", "1.2.3-alpha..1", "1.2.3-01", "1.2.3+", "1.2.3+a..b",
        "1.2.3_alpha", "2147483648.0.0"
    };
    for (size_t i = 0; i < sizeof invalid / sizeof invalid[0]; i++)
        CHECK(au_version_parse(invalid[i], &v) == AU_ERR_ARG, "invalid rejected: %s", invalid[i]);
    char longtag[80]; memset(longtag, 'v', 79); longtag[79]='\0';
    CHECK(au_version_parse(longtag, &v) == AU_ERR_ARG, "overlong");
    CHECK(au_version_parse(NULL, &v) == AU_ERR_ARG, "null");
    CHECK(au_version_parse("2147483648.0.0", &v) == AU_ERR_ARG, "major overflow rejected");
    CHECK(au_version_parse("1.999999999999999999999.0", &v) == AU_ERR_ARG, "minor overflow rejected");

    /* ---- 基本比较 ---- */
    CHECK(cmp("v1.0.0", "v1.0.1") < 0, "1.0.0 < 1.0.1");
    CHECK(cmp("v1.1.0", "v1.0.9") > 0, "1.1.0 > 1.0.9");
    CHECK(cmp("v2.0.0", "v1.9.9") > 0, "2.0.0 > 1.9.9");
    CHECK(cmp("v1.2.3", "v1.2.3") == 0, "equal");
    CHECK(cmp("v1.0.0+a", "v1.0.0+b") == 0, "+build ignored");
    CHECK(cmp("1.0.0-999999999999999999999999999998",
              "1.0.0-999999999999999999999999999999") < 0,
          "huge numeric prerelease compared without integer overflow");
    CHECK(cmp("1.0.0-99999999999999999999999999999",
              "1.0.0-100000000000000000000000000000") < 0,
          "numeric prerelease length determines magnitude");

    /* ---- semver 2.0 §11 黄金序列，逐对严格递增 ---- */
    const char* seq[] = {
        "1.0.0-alpha", "1.0.0-alpha.1", "1.0.0-alpha.beta", "1.0.0-beta",
        "1.0.0-beta.2", "1.0.0-beta.11", "1.0.0-rc.1", "1.0.0"
    };
    int n = (int)(sizeof seq / sizeof seq[0]);
    for (int i = 0; i + 1 < n; i++)
        CHECK(cmp(seq[i], seq[i+1]) < 0, "%s < %s", seq[i], seq[i+1]);
    /* 反向应全为 > */
    for (int i = 0; i + 1 < n; i++)
        CHECK(cmp(seq[i+1], seq[i]) > 0, "%s > %s", seq[i+1], seq[i]);

    /* ---- 预发布版 < 同号正式版（升级决策的关键） ---- */
    CHECK(cmp("v1.1.0-beta.2", "v1.1.0") < 0, "beta < release");
    CHECK(cmp("v1.2.0-beta.3", "v1.1.0") > 0, "1.2.0-beta.3 > 1.1.0 (降级检测)");

    /* 数字预发布段没有 int/long 的范围限制，也必须保留逐段优先级。 */
    CHECK(cmp("1.0.0-beta.202610131200", "1.0.0-beta.202610131201") < 0, "timestamp order");
    CHECK(cmp("1.0.0-beta.202610131201", "1.0.0-beta.202610131200") > 0, "timestamp reverse");
    CHECK(cmp("1.0.0-99999999999999999999", "1.0.0-100000000000000000000") < 0, "digit count");
    CHECK(cmp("1.0.0-202610131200.1", "1.0.0-202610131200.2") < 0, "suffix after large id");
    CHECK(cmp("1.0.0-202610131200", "1.0.0-202610131200.1") < 0, "additional identifier");
    CHECK(cmp("1.0.0-99999999999999999999", "1.0.0-alpha") < 0, "numeric before text");
    CHECK(au_version_parse("1.0.0-000202610131200", &v) == AU_ERR_ARG, "leading zeros rejected");

    if (g_fail == 0) printf("test_version: ALL PASS\n");
    else             printf("test_version: %d FAILED\n", g_fail);
    return g_fail ? 1 : 0;
}
