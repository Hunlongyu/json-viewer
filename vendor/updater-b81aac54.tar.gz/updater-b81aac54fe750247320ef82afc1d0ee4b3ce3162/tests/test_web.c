/* 限流兜底纯函数的离线测试：Location→tag 截取、checksums.txt 查表。不碰网络。 */
#include "au_internal.h"
#include <stdio.h>
#include <string.h>

static int g_fail = 0;
#define CHECK(cond, ...) do { if (!(cond)) { \
    printf("FAIL %s:%d  ", __FILE__, __LINE__); printf(__VA_ARGS__); printf("\n"); g_fail++; } } while (0)

/* 恰好 64 位的十六进制常量：用 8 段 × 8 字符相邻拼接，个数一望便知（避免手数出错）。 */
#define H0 "00000000" "00000000" "00000000" "00000000" "00000000" "00000000" "00000000" "00000000"
#define H1 "11111111" "11111111" "11111111" "11111111" "11111111" "11111111" "11111111" "11111111"
#define H2 "22222222" "22222222" "22222222" "22222222" "22222222" "22222222" "22222222" "22222222"
#define H3 "33333333" "33333333" "33333333" "33333333" "33333333" "33333333" "33333333" "33333333"
#define HA_UP "AAAAAAAA" "AAAAAAAA" "AAAAAAAA" "AAAAAAAA" "AAAAAAAA" "AAAAAAAA" "AAAAAAAA" "AAAAAAAA"
#define HA_LO "aaaaaaaa" "aaaaaaaa" "aaaaaaaa" "aaaaaaaa" "aaaaaaaa" "aaaaaaaa" "aaaaaaaa" "aaaaaaaa"

static void test_tag_from_location(void) {
    char t[128];

    CHECK(au_web_tag_from_location(
        "https://github.com/Hunlongyu/hua/releases/tag/v1.0.11", t, sizeof t)
        && strcmp(t, "v1.0.11") == 0, "basic tag (%s)", t);

    CHECK(au_web_tag_from_location(
        "https://github.com/o/r/releases/tag/v2.0.0/", t, sizeof t)
        && strcmp(t, "v2.0.0") == 0, "trailing slash (%s)", t);

    CHECK(au_web_tag_from_location(
        "https://github.com/o/r/releases/tag/v3.1.4?foo=bar", t, sizeof t)
        && strcmp(t, "v3.1.4") == 0, "with query (%s)", t);
    CHECK(au_web_tag_from_location(
        "https://github.com/o/r/releases/tag/v3.1.4#notes", t, sizeof t)
        && strcmp(t, "v3.1.4") == 0, "with fragment (%s)", t);

    /* 预发布 tag（含连字符）应完整保留 */
    CHECK(au_web_tag_from_location(
        "https://github.com/o/r/releases/tag/v1.2.0-beta.1", t, sizeof t)
        && strcmp(t, "v1.2.0-beta.1") == 0, "prerelease tag (%s)", t);

    CHECK(au_web_tag_from_location("https://github.com/o/r/releases", t, sizeof t) == 0,
          "no tag segment → 0");
    CHECK(au_web_tag_from_location("https://github.com/o/r/releases/tag/", t, sizeof t) == 0,
          "empty tag → 0");
    CHECK(au_web_tag_from_location(
        "https://github.com/o/r/releases/tag/v1.0.0", t, 4) == 0, "too long → 0");
    CHECK(au_web_tag_from_location(NULL, t, sizeof t) == 0, "NULL loc → 0");
}

static void test_checksum_for(void) {
    char h[65];

    /* coreutils 文本模式（两空格）。含无关注释行与其它架构行，须精确命中。 */
    const char* CKS =
        "# hua checksums\n"
        H0 "  hua-x86.exe\n"
        H1 "  hua-x64.exe\n"
        H2 "  hua-arm64.exe\n";
    CHECK(au_web_checksum_for(CKS, "hua-x64.exe", h) && strcmp(h, H1) == 0, "x64 hash (%s)", h);
    CHECK(au_web_checksum_for(CKS, "hua-arm64.exe", h) && strcmp(h, H2) == 0, "arm64 hash (%s)", h);
    CHECK(au_web_checksum_for(CKS, "hua-x86.exe", h) && strcmp(h, H0) == 0, "x86 hash (%s)", h);

    /* sha256sum 二进制模式：名字前带 '*'；大写 hex 应被规整为小写。 */
    const char* CKS_BIN = HA_UP " *hua-x64.exe\n";
    CHECK(au_web_checksum_for(CKS_BIN, "hua-x64.exe", h) && strcmp(h, HA_LO) == 0,
          "binary marker + lowercased (%s)", h);

    /* 带路径的条目按 basename 匹配。 */
    const char* CKS_PATH = H3 "  dist/hua-x64.exe\n";
    CHECK(au_web_checksum_for(CKS_PATH, "hua-x64.exe", h) && strcmp(h, H3) == 0,
          "basename match across path");

    /* 不存在的文件 → 0 */
    CHECK(au_web_checksum_for(CKS, "hua-nope.exe", h) == 0, "missing entry → 0");
    /* 非 64 位 hex 的行不认（防把普通文本当哈希） */
    CHECK(au_web_checksum_for("deadbeef  hua-x64.exe\n", "hua-x64.exe", h) == 0, "short hex → 0");
    /* NULL 安全 */
    CHECK(au_web_checksum_for(NULL, "x", h) == 0, "NULL body → 0");
}

int main(void) {
    test_tag_from_location();
    test_checksum_for();
    if (g_fail == 0) printf("test_web: ALL PASS\n");
    else             printf("test_web: %d FAILED\n", g_fail);
    return g_fail ? 1 : 0;
}
