/* ZIP 解压 + zip_exclude 覆盖保护。用真实系统 tar.exe。 */
#include "au_internal.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static int g_fail = 0;
#define CHECK(cond, ...) do { if (!(cond)) { \
    printf("FAIL %s:%d  ", __FILE__, __LINE__); printf(__VA_ARGS__); printf("\n"); g_fail++; } } while (0)

static void write_file(const wchar_t* path, const char* content) {
    FILE* f = _wfopen(path, L"wb");
    if (f) { fputs(content, f); fclose(f); }
}
static int read_first_line_eq(const wchar_t* path, const char* expect) {
    FILE* f = _wfopen(path, L"rb");
    if (!f) return 0;
    char buf[256] = {0};
    size_t n = fread(buf, 1, sizeof buf - 1, f);
    fclose(f);
    buf[n] = 0;
    return strncmp(buf, expect, strlen(expect)) == 0;
}

#ifndef SYMBOLIC_LINK_FLAG_ALLOW_UNPRIVILEGED_CREATE
#define SYMBOLIC_LINK_FLAG_ALLOW_UNPRIVILEGED_CREATE 0x2
#endif

/* 优先创建目录符号链接；系统未开放非特权 symlink 时退到无需管理员权限的 junction。 */
static int create_dir_link(const wchar_t* link, const wchar_t* target) {
    if (CreateSymbolicLinkW(link, target,
                            SYMBOLIC_LINK_FLAG_DIRECTORY |
                            SYMBOLIC_LINK_FLAG_ALLOW_UNPRIVILEGED_CREATE))
        return 1;

    wchar_t sys[MAX_PATH], cmdexe[MAX_PATH], cmdline[MAX_PATH * 3];
    if (!GetSystemDirectoryW(sys, MAX_PATH)) return 0;
    _snwprintf(cmdexe, MAX_PATH, L"%ls\\cmd.exe", sys); cmdexe[MAX_PATH-1] = L'\0';
    _snwprintf(cmdline, MAX_PATH * 3, L"\"%ls\" /d /c mklink /J \"%ls\" \"%ls\"",
               cmdexe, link, target);
    cmdline[MAX_PATH * 3 - 1] = L'\0';

    STARTUPINFOW si; memset(&si, 0, sizeof si); si.cb = sizeof si;
    PROCESS_INFORMATION pi; memset(&pi, 0, sizeof pi);
    if (!CreateProcessW(cmdexe, cmdline, NULL, NULL, FALSE, CREATE_NO_WINDOW,
                        NULL, NULL, &si, &pi))
        return 0;
    WaitForSingleObject(pi.hProcess, 10000);
    DWORD code = 1;
    GetExitCodeProcess(pi.hProcess, &code);
    CloseHandle(pi.hProcess); CloseHandle(pi.hThread);
    return code == 0;
}

int main(void) {
    CHECK(!au_file_exists(NULL) && !au_regular_file_exists(NULL), "null paths are not files");
    /* 用临时工作目录。 */
    wchar_t tmp[MAX_PATH]; if (!GetTempPathW(MAX_PATH, tmp)) wcscpy(tmp, L".\\");
    wchar_t base[MAX_PATH];
    _snwprintf(base, MAX_PATH, L"%lsau_ziptest_%lu", tmp, GetCurrentProcessId());
    au_rmtree(base);
    CreateDirectoryW(base, NULL);

    au_config_t cfg; memset(&cfg, 0, sizeof cfg);
    cfg.owner="o"; cfg.repo="r"; cfg.current_version="v1.0.0";
    cfg.asset_pattern="*"; cfg.mode=AU_MODE_ZIP;
    const char* excl[] = { "hua.ini" };
    cfg.zip_exclude = excl; cfg.zip_exclude_count = 1;
    au_ctx_t* ctx = au_create(&cfg);

    /* 1) 造一个"新版解压产物"目录：含 app.exe(新) 与 hua.ini(默认配置) */
    wchar_t src[MAX_PATH]; _snwprintf(src, MAX_PATH, L"%ls\\src", base);
    CreateDirectoryW(src, NULL);
    wchar_t p[MAX_PATH];
    _snwprintf(p, MAX_PATH, L"%ls\\app.exe", src); write_file(p, "NEW-EXE-BYTES");
    _snwprintf(p, MAX_PATH, L"%ls\\hua.ini", src); write_file(p, "default-config");

    /* 2) 造"安装目录"：已有用户改过的 hua.ini */
    wchar_t dst[MAX_PATH]; _snwprintf(dst, MAX_PATH, L"%ls\\install", base);
    CreateDirectoryW(dst, NULL);
    _snwprintf(p, MAX_PATH, L"%ls\\hua.ini", dst); write_file(p, "USER-CONFIG");

    /* 3) 覆盖复制，排除 hua.ini */
    CHECK(au_copy_tree(ctx, src, dst) == AU_OK, "copy_tree ok");
    _snwprintf(p, MAX_PATH, L"%ls\\app.exe", dst);
    CHECK(au_file_exists(p), "app.exe copied");
    CHECK(au_regular_file_exists(p), "copied app.exe is a regular file");
    CHECK(!au_regular_file_exists(dst), "directory is not accepted as a regular file");
    CHECK(read_first_line_eq(p, "NEW-EXE-BYTES"), "app.exe is new version");
    _snwprintf(p, MAX_PATH, L"%ls\\hua.ini", dst);
    CHECK(read_first_line_eq(p, "USER-CONFIG"), "user hua.ini PRESERVED (not overwritten)");

    /* 4) 若安装目录没有该配置，则应正常写入默认（排除只在已存在时跳过） */
    wchar_t dst2[MAX_PATH]; _snwprintf(dst2, MAX_PATH, L"%ls\\install2", base);
    CreateDirectoryW(dst2, NULL);
    CHECK(au_copy_tree(ctx, src, dst2) == AU_OK, "copy_tree2 ok");
    _snwprintf(p, MAX_PATH, L"%ls\\hua.ini", dst2);
    CHECK(au_file_exists(p) && read_first_line_eq(p, "default-config"), "default config written when absent");

    /* 5) 不存在的源目录是错误，不能被误判为空目录并返回成功。 */
    wchar_t missing[MAX_PATH], missing_dst[MAX_PATH];
    _snwprintf(missing, MAX_PATH, L"%ls\\missing", base);
    _snwprintf(missing_dst, MAX_PATH, L"%ls\\missing-dst", base);
    CHECK(au_copy_tree(ctx, missing, missing_dst) == AU_ERR_REPLACE,
          "missing source directory reported as replace error");

    /* 6) 清理目录链接时只删除链接本身，不能递归进入目标。 */
    wchar_t target[MAX_PATH], link[MAX_PATH], keep[MAX_PATH], link_copy[MAX_PATH], escaped[MAX_PATH];
    _snwprintf(target, MAX_PATH, L"%ls\\junction-target", base);
    _snwprintf(link, MAX_PATH, L"%ls\\junction-link", base);
    _snwprintf(keep, MAX_PATH, L"%ls\\keep.txt", target);
    _snwprintf(link_copy, MAX_PATH, L"%ls\\junction-copy", base);
    _snwprintf(escaped, MAX_PATH, L"%ls\\app.exe", target);
    CreateDirectoryW(target, NULL);
    write_file(keep, "KEEP-ME");
    int linked = create_dir_link(link, target);
    CHECK(linked, "directory link/junction created for cleanup test");
    if (linked) {
        DWORD attrs = GetFileAttributesW(link);
        CHECK(attrs != INVALID_FILE_ATTRIBUTES && (attrs & FILE_ATTRIBUTE_REPARSE_POINT),
              "cleanup test path is a reparse point");
        CHECK(au_copy_tree(ctx, link, link_copy) == AU_ERR_REPLACE,
              "reparse source rejected by tree copy");
        CHECK(au_copy_tree(ctx, src, link) == AU_ERR_REPLACE,
              "reparse destination rejected by tree copy");
        CHECK(!au_file_exists(escaped), "tree copy did not escape through destination junction");
        au_rmtree(link);
        CHECK(!au_file_exists(link), "directory link removed");
        CHECK(au_file_exists(keep) && read_first_line_eq(keep, "KEEP-ME"),
              "reparse target contents preserved");
    }
    au_rmtree(target);

    /* 7) 目标树内的子重解析点必须拒绝，不能把文件覆盖到安装目录外。 */
    CreateDirectoryW(target, NULL);
    write_file(keep, "KEEP-ME");
    wchar_t src_nested[MAX_PATH], nested_file[MAX_PATH], child_dst[MAX_PATH], dst_nested[MAX_PATH];
    _snwprintf(src_nested, MAX_PATH, L"%ls\\nested", src);
    src_nested[MAX_PATH-1]=L'\0';
    _snwprintf(nested_file, MAX_PATH, L"%ls\\payload.txt", src_nested);
    _snwprintf(child_dst, MAX_PATH, L"%ls\\child-copy", base);
    child_dst[MAX_PATH-1]=L'\0';
    _snwprintf(dst_nested, MAX_PATH, L"%ls\\nested", child_dst);
    nested_file[MAX_PATH-1]=L'\0'; dst_nested[MAX_PATH-1]=L'\0';
    CreateDirectoryW(src_nested, NULL); write_file(nested_file, "PAYLOAD");
    CreateDirectoryW(child_dst, NULL);
    linked = create_dir_link(dst_nested, target);
    CHECK(linked, "nested destination link/junction created");
    if (linked) {
        CHECK(au_copy_tree(ctx, src, child_dst) == AU_ERR_REPLACE,
              "nested destination reparse point rejected");
        _snwprintf(p, MAX_PATH, L"%ls\\payload.txt", target);
        p[MAX_PATH-1]=L'\0';
        CHECK(!au_file_exists(p), "copy did not escape through nested destination link");
        CHECK(au_rmtree(dst_nested) == AU_OK, "nested destination link removed safely");
    }
    CHECK(au_rmtree(child_dst) == AU_OK, "nested destination cleanup succeeds");

    /* 8) 包内的子重解析点也必须拒绝，不能跟随到包外。 */
    wchar_t child_link[MAX_PATH];
    _snwprintf(child_link, MAX_PATH, L"%ls\\linked-dir", src);
    _snwprintf(child_dst, MAX_PATH, L"%ls\\child-copy", base);
    linked = create_dir_link(child_link, target);
    CHECK(linked, "child directory link/junction created");
    if (linked) {
        CHECK(au_copy_tree(ctx, src, child_dst) == AU_ERR_REPLACE,
              "child reparse point rejected by tree copy");
        CHECK(au_rmtree(child_link) == AU_OK, "child reparse point removed safely");
        CHECK(au_file_exists(keep), "child reparse target preserved");
    }
    CHECK(au_rmtree(target) == AU_OK, "child target cleanup succeeds");

    /* 9) 真实 tar.exe 解压往返：把 src 打成 zip 再解开 */
    wchar_t zip[MAX_PATH], out[MAX_PATH];
    _snwprintf(zip, MAX_PATH, L"%ls\\pkg.zip", base);
    _snwprintf(out, MAX_PATH, L"%ls\\extracted", base);
    /* 用 tar.exe 造 zip（bsdtar 支持 -a --format zip） */
    wchar_t sysdir[MAX_PATH]; GetSystemDirectoryW(sysdir, MAX_PATH);
    wchar_t mkcmd[MAX_PATH*3];
    /* 整条命令再包一层引号：cmd.exe /c 会剥掉最外层引号。 */
    _snwprintf(mkcmd, MAX_PATH*3, L"\"\"%ls\\tar.exe\" -a -cf \"%ls\" -C \"%ls\" .\"", sysdir, zip, src);
    mkcmd[MAX_PATH*3-1] = L'\0';
    _wsystem(mkcmd);
    CHECK(au_file_exists(zip), "zip created by tar");
    CHECK(au_extract_zip(ctx, zip, out) == AU_OK, "extract ok");
    CHECK(au_extract_zip(ctx, zip, out) == AU_ERR_EXTRACT,
          "extract refuses a stale/non-fresh destination");
    _snwprintf(p, MAX_PATH, L"%ls\\app.exe", out);
    CHECK(au_file_exists(p), "extracted app.exe present");

    /* 10) 删除错误必须向上传播；关闭占用句柄后应可完整清理。 */
    wchar_t locked_dir[MAX_PATH], locked_file[MAX_PATH];
    _snwprintf(locked_dir, MAX_PATH, L"%ls\\locked", base);
    locked_dir[MAX_PATH-1] = L'\0';
    _snwprintf(locked_file, MAX_PATH, L"%ls\\held.bin", locked_dir);
    locked_file[MAX_PATH-1] = L'\0';
    CreateDirectoryW(locked_dir, NULL);
    write_file(locked_file, "held");
    HANDLE held = CreateFileW(locked_file, GENERIC_READ, 0, NULL, OPEN_EXISTING, 0, NULL);
    CHECK(held != INVALID_HANDLE_VALUE, "exclusive file handle opened");
    if (held != INVALID_HANDLE_VALUE) {
        CHECK(au_rmtree(locked_dir) == AU_ERR_IO, "rmtree reports locked-file failure");
        CloseHandle(held);
        CHECK(au_rmtree(locked_dir) == AU_OK, "rmtree succeeds after handle closes");
    }

    au_destroy(ctx);
    au_rmtree(base);

    if (g_fail == 0) printf("test_zip: ALL PASS\n");
    else             printf("test_zip: %d FAILED\n", g_fail);
    return g_fail ? 1 : 0;
}
